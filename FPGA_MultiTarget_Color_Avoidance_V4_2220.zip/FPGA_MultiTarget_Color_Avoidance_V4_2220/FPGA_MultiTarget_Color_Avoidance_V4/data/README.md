# Data

- `cnn_weights/`：当前 8 个 INT8/INT32 `.mem` 权重文件。
- `test_images/`：待补充的测试图像。
- `reference_results/`：人工标注和参考识别结果。
- `performance/`：资源、时序和测试原始数据。

不要在此目录放置摄像头采集缓存或与提交版本无关的旧权重。
