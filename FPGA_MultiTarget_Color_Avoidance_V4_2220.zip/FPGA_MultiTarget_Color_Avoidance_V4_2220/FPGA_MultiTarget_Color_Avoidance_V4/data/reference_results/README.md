# Reference Results

建议为 `test_images/` 中的每张图片记录：

```text
image_file,car_count,block_count,destination_count,expected_note
```

如果进行了 CNN 离线训练集或验证集测试，请在这里保存原始预测文件，不要只保留汇总百分比。
