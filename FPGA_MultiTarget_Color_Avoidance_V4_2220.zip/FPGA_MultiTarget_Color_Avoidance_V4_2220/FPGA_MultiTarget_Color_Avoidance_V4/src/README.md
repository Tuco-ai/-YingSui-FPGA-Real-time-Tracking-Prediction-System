# Source Layout

| Directory | Contents |
| --- | --- |
| `top/` | FPGA 顶层和模块连接 |
| `color_detect/` | RGB 阈值、连通域、16 槽候选排序 |
| `cnn_accel/` | ROI 缓存、16 路 CNN 分类、框和标签 |
| `traj_prediction/` | 绿色终点选择、A* 搜索和路径显示 |
| `trajectory/` | 30 秒轨迹记录、线段绘制、位图和显示 |
| `driver/` | 摄像头、DDR3、视频处理和 HDMI 驱动 |
| `interaction/` | 按键消抖、UART 和上位机控制协议 |
| `display/` | OSD 文字和字库 |
| `common/` | 复位同步 |
| `constraints/` | 引脚和时钟约束 |
| `ip/` | Vivado IP 配置文件 |

当前 A* 使用 64x48、16x16 像素栅格。源码路径与 `board/vivado_project/` 中实际参与构建的文件一致。
