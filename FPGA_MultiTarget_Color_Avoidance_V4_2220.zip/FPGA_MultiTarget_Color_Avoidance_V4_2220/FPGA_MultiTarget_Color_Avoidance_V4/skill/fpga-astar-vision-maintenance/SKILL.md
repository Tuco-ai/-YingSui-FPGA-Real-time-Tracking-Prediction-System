---
name: fpga-astar-vision-maintenance
description: "用于维护和验证达芬奇Pro FPGA颜色识别、CNN分类、A*路径、HDMI叠加、轨迹记录及CH340上位机工程。"
---

# FPGA A* 视觉工程维护

当任务涉及本项目的 RGB 目标检测、16 路 CNN、A* 路径、Snapshot/Live 模式、轨迹记录、HDMI OSD、串口协议、上位机或比赛提交包时使用本技能。

## 当前设计事实

- FPGA：`xc7a200tfbg484-2`。
- 摄像头：OV5640，1024×768 RGB565。
- 检测使用 RGB 阈值，不使用 HSV。
- 连通域内部最多保留 32 个组件，向下游输出最多 16 个候选 ROI。
- CNN CAR 选择路径起点，绿色目标选择终点。
- 其他有效 ROI 都进入障碍图，不要求对应 CNN 类别为 BLOCK。
- 当前 A* 使用 64×48 栅格，每格 16×16 像素，八邻域搜索，禁止斜穿障碍角。
- 路径只在 All 模式显示。
- Snapshot 在目标移动后保持；Live 随新帧重新规划。
- 路径只用于视觉展示，不驱动实体小车。
- KEY0、KEY1 和 CH340 上位机必须可以同时使用。

## 先检查提交包

在提交包根目录运行：

```powershell
python .\skill\fpga-astar-vision-maintenance\scripts\check_package.py
```

该脚本检查关键文件、英文路径、XPR 引用、当前位流哈希、Python 语法和上位机协议。它不能替代 Vivado 综合或实板测试。

修改 RTL 前阅读 [references/project-architecture.md](references/project-architecture.md)。重新构建或交付前阅读 [references/verification.md](references/verification.md) 和 [references/release-checklist.md](references/release-checklist.md)。

## 维护两套源码视图

- `src/`：按功能整理、便于评审核对的源码。
- `board/vivado_project/`：用于实际打开的完整 Vivado 工程。
- 两处的可综合源码内容必须一致。
- 不要重新接入旧版 `path_planner`、`path_manager`、`simple_path_draw`、HSV 检测或单目标旧覆盖模块。

## 保留 Vivado 运行目录

提交工程必须同时保留：

```text
prj/ov5640_hdmi_median_filter.runs/synth_1/
prj/ov5640_hdmi_median_filter.runs/impl_1/
```

这两个目录提供综合检查点、布线检查点、完成标记、时序/资源/DRC 报告和工程位流。只保留 XPR 和 `.srcs` 时，工程可以打开，但 Vivado 可能把运行显示为 `NoStart`。

更新提交包时：

1. 复制或重新生成与当前 RTL 对应的 `synth_1` 和 `impl_1`。
2. 确认 `__synthesis_is_complete__` 存在。
3. 确认综合 DCP 和布线后 DCP 存在。
4. 确认运行目录中的位流 SHA-256 与提交位流一致。
5. 删除无关的旧运行定义，例如 `synth_1_copy_*`。

## 修改流程

1. 从顶层追踪到实际受影响的模块。
2. 先检查当前文件、XPR 注册和测试覆盖。
3. 保持模块名、接口和已验证功能不变，只做必要修改。
4. RTL、Python 协议和文档中的命令定义必须同步。
5. 先运行模块仿真和上位机协议测试，再执行 Vivado 构建。
6. 报告时区分仿真、综合实现和实板结果。

## 路径功能检查

- All 模式未发出路径命令时只显示目标框。
- Snapshot 完成后冻结。
- Snapshot 在目标移动或暂时丢失后仍保留。
- 再次 Snapshot 使用新画面覆盖旧路径。
- Live 根据新帧更新。
- Clear 只清除 Snapshot 路径并回到 Off。
- 离开 All 后路径消失并复位路径模式。
- 规划完成后的路径只在 `frame_pulse` 边界提交。
- 等待提交期间不得启动下一次规划覆盖构建缓冲。
- 无 CNN CAR 或无绿色目标时不生成错误路径。

## 上位机和协议检查

- 串口：115200 8N1，无流控。
- 命令帧：`A5 5A CMD ARG CRC8`。
- 状态帧：`A5 5A 90 STATE MODE TIME FLAGS PATH_MODE CRC8`。
- 路径命令：`0x20` Snapshot，`0x21` Clear，`0x22` Live。
- 上位机以 FPGA 回传状态为准。
- 外观修改不得顺带改变协议。
