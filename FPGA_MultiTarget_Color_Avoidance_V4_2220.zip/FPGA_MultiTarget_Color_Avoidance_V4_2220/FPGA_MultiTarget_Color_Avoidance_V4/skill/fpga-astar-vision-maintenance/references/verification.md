# Verification and Release

## Package check

```powershell
python .\skill\fpga-astar-vision-maintenance\scripts\check_package.py
```

This verifies file inventory, English names, XPR references, Python syntax, host protocol, and bitstream hash.

## RTL simulation

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\sim\scripts\run_iverilog_tests.ps1
```

Inspect `sim/results/` for pass/fail evidence.

## Vivado build

```powershell
cd build
.\run_build.bat
```

The script runs synthesis, implementation, timing, DRC, bus skew, and bitstream generation.

Release checks:

- synthesis and implementation are 100%;
- zero implementation errors;
- WNS and WHS are non-negative;
- generated bitstream is newer than modified RTL;
- resource values match the report copied into the package;
- bitstream SHA-256 is recorded;
- all XPR references resolve after moving the package to a new path.

## Board checks

1. Program `build/bitstream/fpga_vision_route_fix.bit`.
2. Confirm camera image and OSD.
3. Confirm All-mode boxes, CAR/BLOCK and destination labels.
4. Confirm Snapshot freeze, replacement and clear.
5. Confirm Live mode does not show a missing path segment during bank updates.
6. Confirm KEY0/KEY1 and CH340 control remain compatible.
7. Save screenshots and test notes under `board/captures/` and `board/test_data/`.

Do not describe implementation or simulation as board verification.
