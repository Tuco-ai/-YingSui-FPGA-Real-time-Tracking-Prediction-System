# Project Architecture

## Active source path

```text
OV5640
  -> camera capture and DDR3 frame buffer
  -> multi_object_overlay_v2
     -> RGB threshold and connected-component tracking
     -> 16 candidate ROIs
     -> cnn_frame_roi_loader
     -> cnn_camera_classifier
     -> cnn_class_overlay
  -> goal_box_selector and CNN CAR selection
  -> astar_path_overlay
     -> 64x48 obstacle grid
     -> astar_grid_planner
     -> HDMI route overlay
  -> trajectory and OSD
  -> HDMI output
```

## Key files

| Function | File |
| --- | --- |
| Top connection and overlay order | `src/top/ov5640_hdmi_median_filter.v` |
| RGB threshold and component tracker | `src/color_detect/multi_object_overlay_v2.v` |
| Frame-level ROI sample cache | `src/cnn_accel/cnn_frame_roi_loader.sv` |
| 16 classifier lanes | `src/cnn_accel/cnn_camera_classifier.sv` |
| INT8 CNN arithmetic | `src/cnn_accel/tiny_object_cnn_int8.sv` |
| Box and label rendering | `src/cnn_accel/cnn_class_overlay.sv` |
| Green destination selection | `src/traj_prediction/goal_box_selector.v` |
| Path modes and obstacle map | `src/traj_prediction/astar_path_overlay.sv` |
| A* search and backtracking | `src/traj_prediction/astar_grid_planner.sv` |
| UART bridge | `src/interaction/host_control_link.sv` |
| Host application | `board/host_gui/host_gui.py` |

## Color logic

Current class masks:

```text
Blue:  B >= R + 20 and B >= G + 12
Red:   R >= G + 20 and 2R >= 3B
Pink:  R >= G + 20 and B >= G + 12 and 3B >= 2R
Green: max >= 40 and G >= R + 8 and G >= B + 14
```

Minimum area is 300 pixels, minimum run is 3 pixels, and minimum side is 8 pixels.

## CNN

- Input 32x32 INT8.
- Conv1 3x3, 8 channels.
- Conv2 3x3, 16 channels.
- FC outputs CAR, BLOCK, OTHER scores.
- INT32 accumulation and INT64 requantization intermediate.
- 16 independent classifier instances.

## A*

- 64x48 cells, each 16x16 pixels.
- Eight-neighbor movement.
- Straight cost 1000 and diagonal cost 1414.
- Octile heuristic.
- Diagonal movement requires both adjacent orthogonal cells to be free.
- Obstacle clearance equals half the shorter car-box side.
- Path arms use six-bit encoding of legal direction combinations.

## UART

```text
Command: A5 5A CMD ARG CRC8
Status:  A5 5A 90 STATE MODE TIME FLAGS PATH_MODE CRC8
```

Path commands:

```text
0x20 Snapshot
0x21 Clear Snapshot
0x22 Live
```

CRC8 uses polynomial `0x07`.

## Known boundaries

- The current implementation waits for `frame_pulse` before committing a completed path buffer.
- Board verification should confirm that Snapshot and Live updates do not produce a partial path.
- RGB thresholds are sensitive to lighting and adjacent same-color objects.
- Only 16 candidate ROIs reach CNN and A*.
- The route does not drive physical motors.
