#!/usr/bin/env python3
"""Check package structure and reproducibility without launching Vivado."""

from __future__ import annotations

import hashlib
import csv
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = SKILL_ROOT.parents[1]
XPR = PACKAGE_ROOT / "board/vivado_project/prj/ov5640_hdmi_median_filter.xpr"
BITSTREAM = PACKAGE_ROOT / "build/bitstream/fpga_vision_route_fix.bit"
EXPECTED_SHA256 = "58DC7FD748019EF113D13F024328F917EEFEDF05F8F8A4498BBD5311AD5DEDB0"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def resolve_xpr_path(raw: str) -> Path:
    prj = XPR.parent
    replacements = {
        "$PSRCDIR": prj / "ov5640_hdmi_median_filter.srcs",
        "$PPRDIR": prj,
        "$PRUNDIR": prj / "ov5640_hdmi_median_filter.runs",
        "$PGENDIR": prj / "ov5640_hdmi_median_filter.gen",
    }
    for prefix, root in replacements.items():
        if raw.startswith(prefix):
            return root / raw[len(prefix):].lstrip("/\\")
    return Path(raw)


def main() -> int:
    errors: list[str] = []
    required = [
        "README.md",
        "src/top/ov5640_hdmi_median_filter.v",
        "src/color_detect/multi_object_overlay_v2.v",
        "src/traj_prediction/astar_path_overlay.sv",
        "src/traj_prediction/astar_grid_planner.sv",
        "board/vivado_project/prj/ov5640_hdmi_median_filter.xpr",
        "build/tcl/build_submission.tcl",
        "build/bitstream/fpga_vision_route_fix.bit",
        "report/design_report.md",
        "skill/llm_collaboration_log.md",
    ]
    for relative in required:
        if not (PACKAGE_ROOT / relative).exists():
            errors.append(f"Missing required file: {relative}")

    manifest = PACKAGE_ROOT / "FILE_MANIFEST.csv"
    if manifest.exists():
        with manifest.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        missing_rows = [row["RelativePath"] for row in rows if not (PACKAGE_ROOT / row["RelativePath"]).exists()]
        print(f"MANIFEST_FILES={len(rows)} MISSING={len(missing_rows)}")
        errors.extend(f"Manifest target missing: {item}" for item in missing_rows)
    else:
        errors.append("Missing required file: FILE_MANIFEST.csv")

    for path in PACKAGE_ROOT.rglob("*"):
        relative = path.relative_to(PACKAGE_ROOT).as_posix()
        if any(ord(character) > 127 for character in relative):
            errors.append(f"Non-English path: {relative}")

    if XPR.exists():
        project = ET.parse(XPR).getroot()
        references = project.findall(".//File")
        missing = [str(resolve_xpr_path(node.get("Path", ""))) for node in references if not resolve_xpr_path(node.get("Path", "")).exists()]
        print(f"XPR_REFERENCES={len(references)} MISSING={len(missing)}")
        if missing:
            errors.extend(f"Missing XPR target: {item}" for item in missing)

    if BITSTREAM.exists():
        actual = sha256(BITSTREAM)
        print(f"BITSTREAM_SHA256={actual}")
        if actual != EXPECTED_SHA256:
            errors.append("Bitstream hash differs from the release record")

    host_dir = PACKAGE_ROOT / "board/host_gui"
    for name in ("host_gui.py", "protocol.py"):
        path = host_dir / name
        if path.exists():
            try:
                compile(path.read_text(encoding="utf-8"), str(path), "exec")
            except (OSError, UnicodeError, SyntaxError) as exc:
                errors.append(f"Python syntax failure in {name}: {exc}")

    protocol_test = host_dir / "protocol_test.py"
    if protocol_test.exists():
        result = subprocess.run(
            [sys.executable, "-B", "protocol_test.py"],
            cwd=host_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode:
            errors.append((result.stdout + result.stderr).strip())
        else:
            print("HOST_PROTOCOL_TESTS=PASS")

    if errors:
        print("FAIL")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS package files, XPR references, English paths, Python protocol and bitstream")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
