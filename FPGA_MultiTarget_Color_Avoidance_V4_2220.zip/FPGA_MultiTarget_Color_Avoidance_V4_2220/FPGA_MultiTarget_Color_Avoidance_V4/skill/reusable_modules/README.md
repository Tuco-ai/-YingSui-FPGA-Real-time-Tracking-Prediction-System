# 可复用模块

| 模块 | 用途 | 复用条件 |
| --- | --- | --- |
| `multi_object_overlay_v2.v` | RGB 阈值与多目标连通域 | 场景颜色鲜明，目标之间保持间距 |
| `cnn_frame_roi_loader.sv` | 从整帧缓存生成多个 ROI | 需要同一帧内的多目标分类 |
| `cnn_camera_classifier.sv` | 多路 CNN 调度与结果稳定 | 已有量化 CNN 权重 |
| `astar_grid_planner.sv` | 通用栅格 A* 搜索 | 输入起点、终点和障碍读接口 |
| `astar_path_overlay.sv` | 障碍映射、路径模式和 HDMI 叠加 | 固定分辨率视频链路 |
| `traj_ctrl.v` | 30 秒记录状态机 | 时钟频率可配置为 65 MHz 时可直接使用 |
| `host_control_link.sv` | UART 命令解析和状态回传 | 保持当前命令表或同步修改上位机 |
| `key_debounce.v` | 按键消抖与长短按 | 低有效按键输入 |

复用前应确认分辨率、时钟、颜色阈值、目标槽位和通信协议，不要直接假定与其他工程相同。
