# Third-Party Notices

本项目包含或调用了以下第三方内容：

- 正点原子达芬奇Pro摄像头、DDR3、HDMI 示例驱动的衍生代码；
- AMD/Xilinx Vivado IP，包括时钟、FIFO、MIG 和块 RAM 配置；
- Python 上位机附带 pyserial 3.5。

提交前请根据赛事要求补充准确的许可证文本、版本号和修改范围。源工程中的公司及作者注释应保留。
