# Simulation Result Summary

运行日期：2026-11-02

运行器：Icarus Verilog

| Testbench | 结果 |
| --- | --- |
| `tb_astar_grid_planner` | PASS，正常、有障碍、无路和起终点重合用例 |
| `tb_astar_path_overlay` | PASS，路径显示、Snapshot、Live、清除和帧边界缓冲切换 |
| `tb_cnn_car_pick` | PASS，CNN CAR 与槽位优先 |
| `tb_eight_color_tracker` | PASS，16 框和多颜色候选 |
| `tb_eight_box_draw` | PASS，矩形框与 destination 标签 |
| `tb_goal_box_selector_16` | PASS，绿色终点的 CNN BLOCK 条件 |
| `tb_video_pipeline_alignment` | PASS，视频和 OSD 对齐 |
| `tb_host_control_link` | PASS，UART 命令、ACK 和状态协议 |
| `tb_host_traj_integration` | PASS，上位机与轨迹状态机联测 |
| `tb_traj_ctrl` | PASS，记录、暂停、继续和清空 |
| `tb_traj_manager` | PASS，连线与清空请求 |
| `tb_line_drawer` | PASS，水平线段绘制 |
| `tb_bitmap_display` | PASS，轨迹位图读取 |
| `tb_key_debounce` | PASS，短按和长按判定 |

完整输出位于同目录各 `.log` 文件。
