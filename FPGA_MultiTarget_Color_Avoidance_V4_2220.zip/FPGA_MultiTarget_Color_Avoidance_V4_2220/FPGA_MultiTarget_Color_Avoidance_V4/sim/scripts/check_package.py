#!/usr/bin/env python3
"""Validate the competition package without launching Vivado."""

from __future__ import annotations

import hashlib
import csv
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
XPR = ROOT / "board/vivado_project/prj/ov5640_hdmi_median_filter.xpr"
BIT = ROOT / "build/bitstream/fpga_vision_route_fix.bit"
EXPECTED_SHA256 = "58DC7FD748019EF113D13F024328F917EEFEDF05F8F8A4498BBD5311AD5DEDB0"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def resolve(raw: str) -> Path:
    prj = XPR.parent
    replacements = {
        "$PSRCDIR": prj / "ov5640_hdmi_median_filter.srcs",
        "$PPRDIR": prj,
        "$PRUNDIR": prj / "ov5640_hdmi_median_filter.runs",
        "$PGENDIR": prj / "ov5640_hdmi_median_filter.gen",
    }
    for prefix, base in replacements.items():
        if raw.startswith(prefix):
            return base / raw[len(prefix):].lstrip("/\\")
    return Path(raw)


def main() -> int:
    errors: list[str] = []
    required = (
        "README.md",
        "src/top/ov5640_hdmi_median_filter.v",
        "src/color_detect/multi_object_overlay_v2.v",
        "src/cnn_accel/tiny_object_cnn_int8.sv",
        "src/traj_prediction/astar_grid_planner.sv",
        "src/traj_prediction/astar_path_overlay.sv",
        "board/vivado_project/prj/ov5640_hdmi_median_filter.xpr",
        "board/host_gui/host_gui.py",
        "board/host_gui/protocol.py",
        "build/tcl/build_submission.tcl",
        "build/bitstream/fpga_vision_route_fix.bit",
        "report/design_report.md",
        "skill/llm_collaboration_log.md",
    )
    for relative in required:
        if not (ROOT / relative).exists():
            errors.append(f"missing: {relative}")

    manifest = ROOT / "FILE_MANIFEST.csv"
    if manifest.exists():
        with manifest.open(encoding="utf-8-sig", newline="") as stream:
            rows = list(csv.DictReader(stream))
        missing_rows = [row["RelativePath"] for row in rows if not (ROOT / row["RelativePath"]).exists()]
        print(f"MANIFEST_FILES={len(rows)} MISSING={len(missing_rows)}")
        errors.extend(f"manifest path missing: {item}" for item in missing_rows)
    else:
        errors.append("missing: FILE_MANIFEST.csv")

    if XPR.exists():
        try:
            project = ET.parse(XPR).getroot()
            files = project.findall(".//File")
            missing = [str(resolve(node.get("Path", ""))) for node in files if not resolve(node.get("Path", "")).exists()]
            if missing:
                errors.extend(f"XPR missing file: {item}" for item in missing)
            print(f"XPR_REFERENCES={len(files)} MISSING={len(missing)}")
        except ET.ParseError as exc:
            errors.append(f"XPR parse error: {exc}")

    if BIT.exists():
        found = sha256(BIT)
        print(f"BITSTREAM_SHA256={found}")
        if found != EXPECTED_SHA256:
            errors.append("bitstream SHA-256 differs from the recorded release")

    host_dir = ROOT / "board/host_gui"
    for script in ("host_gui.py", "protocol.py"):
        path = host_dir / script
        if path.exists():
            try:
                compile(path.read_text(encoding="utf-8"), str(path), "exec")
            except (OSError, UnicodeError, SyntaxError) as exc:
                errors.append(f"Python syntax error in {script}: {exc}")

    protocol_test = host_dir / "protocol_test.py"
    if protocol_test.exists():
        result = subprocess.run(
            [sys.executable, "-B", "protocol_test.py"],
            cwd=host_dir,
            capture_output=True,
            text=True,
        )
        if result.returncode:
            errors.append((result.stdout + result.stderr).strip())
        else:
            print("HOST_PROTOCOL_TESTS=PASS")

    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT).as_posix()
        if any(ord(character) > 127 for character in relative):
            errors.append(f"non-English path: {relative}")

    if errors:
        print("FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS package structure, XPR references, Python syntax, protocol and manifest")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
