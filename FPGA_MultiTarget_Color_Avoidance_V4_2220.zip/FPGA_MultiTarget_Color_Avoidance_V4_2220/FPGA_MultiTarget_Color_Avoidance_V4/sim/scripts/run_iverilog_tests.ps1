param(
    [string]$Iverilog = "",
    [string]$Vvp = ""
)

$ErrorActionPreference = "Stop"
$packageRoot = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$unit = Join-Path $packageRoot "sim\unit"
$src = Join-Path $packageRoot "src"
$results = Join-Path $packageRoot "sim\results"
New-Item -ItemType Directory -Force -Path $results | Out-Null
$ErrorActionPreference = "Continue"

if (-not $Iverilog) {
    $command = Get-Command iverilog -ErrorAction SilentlyContinue
    if ($command) {
        $Iverilog = $command.Source
    } elseif (Test-Path "D:\iverilog\bin\iverilog.exe") {
        $Iverilog = "D:\iverilog\bin\iverilog.exe"
    } else {
        throw "iverilog not found. Pass -Iverilog <path>."
    }
}
if (-not $Vvp) {
    $candidate = Join-Path (Split-Path $Iverilog) "vvp.exe"
    if (Test-Path $candidate) {
        $Vvp = $candidate
    } else {
        $command = Get-Command vvp -ErrorAction SilentlyContinue
        if (-not $command) { throw "vvp not found. Pass -Vvp <path>." }
        $Vvp = $command.Source
    }
}

$s = @{
    color = Join-Path $src "color_detect\multi_object_overlay_v2.v"
    reset = Join-Path $src "common\reset_release_sync.v"
    overlay = Join-Path $src "cnn_accel\cnn_class_overlay.sv"
    planner = Join-Path $src "traj_prediction\astar_grid_planner.sv"
    astar = Join-Path $src "traj_prediction\astar_path_overlay.sv"
    goal = Join-Path $src "traj_prediction\goal_box_selector.v"
    video = Join-Path $src "driver\video_driver.v"
    uart_rx = Join-Path $src "interaction\uart_rx.v"
    uart_tx = Join-Path $src "interaction\uart_tx.v"
    host = Join-Path $src "interaction\host_control_link.sv"
    key = Join-Path $src "interaction\key_debounce.v"
    traj_ctrl = Join-Path $src "trajectory\traj_ctrl.v"
    traj_manager = Join-Path $src "trajectory\traj_manager.v"
    line = Join-Path $src "trajectory\line_drawer.v"
    bitmap = Join-Path $src "trajectory\traj_bitmap.v"
    display = Join-Path $src "trajectory\traj_display.v"
}

$tests = @(
    @{ Name = "tb_astar_grid_planner"; Files = @((Join-Path $unit "tb_astar_grid_planner.sv"), $s.planner) },
    @{ Name = "tb_astar_path_overlay"; Files = @((Join-Path $unit "tb_astar_path_overlay.sv"), $s.planner, $s.astar) },
    @{ Name = "tb_cnn_car_pick"; Files = @((Join-Path $unit "tb_cnn_car_pick.sv"), $s.color, $s.reset) },
    @{ Name = "tb_eight_color_tracker"; Files = @((Join-Path $unit "tb_eight_color_tracker.sv"), $s.color, $s.reset) },
    @{ Name = "tb_eight_box_draw"; Files = @((Join-Path $unit "tb_eight_box_draw.sv"), $s.overlay) },
    @{ Name = "tb_goal_box_selector_16"; Files = @((Join-Path $unit "tb_goal_box_selector_16.sv"), $s.goal) },
    @{ Name = "tb_video_pipeline_alignment"; Files = @((Join-Path $unit "tb_video_pipeline_alignment.sv"), $s.video) },
    @{ Name = "tb_host_control_link"; Files = @((Join-Path $unit "tb_host_control_link.sv"), $s.uart_rx, $s.uart_tx, $s.host) },
    @{ Name = "tb_host_traj_integration"; Files = @((Join-Path $unit "tb_host_traj_integration.sv"), $s.uart_rx, $s.uart_tx, $s.host, $s.traj_ctrl) },
    @{ Name = "tb_traj_ctrl"; Files = @((Join-Path $unit "tb_traj_ctrl.v"), $s.traj_ctrl) },
    @{ Name = "tb_traj_manager"; Files = @((Join-Path $unit "tb_traj_manager.v"), $s.traj_manager) },
    @{ Name = "tb_line_drawer"; Files = @((Join-Path $unit "tb_line_drawer.v"), $s.line) },
    @{ Name = "tb_bitmap_display"; Files = @((Join-Path $unit "tb_bitmap_display.v"), $s.bitmap, $s.display) },
    @{ Name = "tb_key_debounce"; Files = @((Join-Path $unit "tb_key_debounce.v"), $s.key) }
)

$failed = @()
foreach ($test in $tests) {
    $vvpFile = Join-Path $env:TEMP "$($test.Name)_submission.vvp"
    $logFile = Join-Path $results "$($test.Name).log"
    "COMMAND: $Iverilog -g2012 -s $($test.Name) -o $vvpFile $($test.Files -join ' ')" |
        Set-Content -LiteralPath $logFile -Encoding utf8
    & $Iverilog -g2012 -s $test.Name -o $vvpFile @($test.Files) 2>&1 |
        Tee-Object -FilePath $logFile -Append
    if ($LASTEXITCODE -ne 0) {
        $failed += $test.Name
        continue
    }
    & $Vvp $vvpFile 2>&1 | Tee-Object -FilePath $logFile -Append
    if ($LASTEXITCODE -ne 0) {
        $failed += $test.Name
    }
}

if ($failed.Count) {
    throw "Failed tests: $($failed -join ', ')"
}
Write-Host "All simulation tests passed. Logs: $results"
