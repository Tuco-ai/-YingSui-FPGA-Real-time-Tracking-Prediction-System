# Simulation

- `unit/`：当前主要模块级 testbench。
- `system/`：摄像头采集和视频处理系统仿真模型。
- `scripts/run_iverilog_tests.ps1`：批量运行 Icarus Verilog 测试。
- `results/`：运行日志和结果记录。
- `assets/`：波形截图和补充说明。

验证重点是颜色连通域、CNN 起点、绿色终点、A*、路径模式、UART、轨迹和视频时序对齐。
