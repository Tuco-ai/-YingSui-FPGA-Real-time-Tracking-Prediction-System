`timescale 1ns/1ps
module tb_key_debounce;

    reg clk, rst_n, key_in;
    wire key_short_pulse, key_long_pulse;

    key_debounce #(
        .CLK_FREQ      (1000),   // 1kHz，方便算
        .DEBOUNCE_MS   (5),      // 消抖 = 5 周期
        .LONG_PRESS_MS (50)      // 长按 = 50 周期
    ) dut (
        .clk(clk), .rst_n(rst_n), .key_in(key_in),
        .key_short_pulse(key_short_pulse),
        .key_long_pulse (key_long_pulse)
    );

    initial clk = 0;
    always #5 clk = ~clk;          // 10ns 周期

    initial begin
        rst_n = 1'b0; key_in = 1'b1;
        #100 rst_n = 1'b1;
        #100;

        // ---- 测试1：短按（带抖动）----
        key_in = 1'b0; #8;
        key_in = 1'b1; #6;
        key_in = 1'b0; #8;
        key_in = 1'b1; #6;
        key_in = 1'b0;              // 稳定按下
        #200;                       // 按住 20 周期 < 50 周期 → 应是短按
        key_in = 1'b1; #8;          // 松开抖动
        key_in = 1'b0; #6;
        key_in = 1'b1;              // 稳定松开
        #200;

        // ---- 测试2：长按 ----
        key_in = 1'b0;              // 稳定按下
        #800;                       // 按住 80 周期 > 50 周期 → 满 50 周期应出 long
        key_in = 1'b1;              // 松开
        #300;

        $finish;
    end

    initial $monitor("t=%0t key=%b short=%b long=%b",
                     $time, key_in, key_short_pulse, key_long_pulse);

endmodule
