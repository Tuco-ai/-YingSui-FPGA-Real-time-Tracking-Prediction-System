# Board Operation

1. 使用 Vivado Hardware Manager 或打包的烧录脚本下载 `build/bitstream/fpga_vision_route_fix.bit`。
2. 连接 OV5640、HDMI 显示器和 CH340 USB 串口。
3. 上电后确认 HDMI 出现摄像头画面、目标框和左上角 OSD。
4. 进入 `host_gui/`，双击 `launch_host_gui.bat`。
5. 选择 CH340 对应 COM 口并点击连接。
6. 测试 Blue、Red、Green、All 模式。
7. 在 All 模式测试 Snapshot、Live 和清除路径。
8. 测试 KEY0 轨迹记录和 KEY1 颜色切换。
9. 将照片、视频帧和测试数据放入 `captures/` 与 `test_data/`。

当前实现未提供实体小车控制接口。
