set script_dir [file normalize [file dirname [info script]]]
set package_root [file normalize [file join $script_dir .. ..]]
set bit_file [file join $package_root build bitstream fpga_vision_route_fix.bit]

open_hw_manager
connect_hw_server
open_hw_target
set device [lindex [get_hw_devices xc7a200t*] 0]
if {$device eq ""} {
    error "Target xc7a200t device not found"
}
current_hw_device $device
refresh_hw_device -update_hw_probes false $device
set_property PROGRAM.FILE $bit_file $device
program_hw_devices $device
refresh_hw_device $device
close_hw_manager
