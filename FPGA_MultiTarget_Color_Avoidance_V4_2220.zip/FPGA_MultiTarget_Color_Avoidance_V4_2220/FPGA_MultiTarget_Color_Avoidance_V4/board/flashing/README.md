# Flashing

可直接使用 Vivado Hardware Manager 烧录：

```text
build/bitstream/fpga_vision_route_fix.bit
```

也可以在设置好 `VIVADO_BIN` 后运行：

```powershell
.\program_bitstream.tcl
```

烧录后确认 JTAG 目标为 `xc7a200tfbg484-2`。
