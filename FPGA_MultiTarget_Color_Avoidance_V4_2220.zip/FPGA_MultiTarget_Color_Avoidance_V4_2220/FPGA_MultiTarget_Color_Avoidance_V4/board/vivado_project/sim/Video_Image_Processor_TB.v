//****************************************Copyright (c)***********************************//
//ԭ�Ӹ����߽�ѧƽ̨��www.yuanzige.com
//����֧�֣�http://www.openedv.com/forum.php
//�Ա����̣�https://zhengdianyuanzi.tmall.com
//��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡZYNQ & FPGA & STM32 & LINUX���ϡ�
//��Ȩ���У�����ؾ���
//Copyright(C) ����ԭ�� 2023-2033
//All rights reserved                                  
//----------------------------------------------------------------------------------------
// File name:           Video_Image_Processor_TB
// Created by:          ����ԭ��
// Created date:        2025��11��5��10:40:02
// Version:             V1.0
// Descriptions:        ��Ƶͼ��������TB
//
//----------------------------------------------------------------------------------------
//****************************************************************************************//

`timescale 1ns/1ns
module Video_Image_Processor_TB;

//------------------------------------------
//Generate 24MHz driver clock
reg clk; 
localparam PERIOD2 = 41;        //24MHz
initial 
begin
    clk = 0;
    forever #(PERIOD2/2)
    clk = ~clk;
end

//------------------------------------------
//Generate global reset
reg rst_n;
task task_reset;
begin
    rst_n = 0;
    repeat(20) @(negedge clk);
    rst_n = 1;
end
endtask
wire    clk_cmos = clk;     //24MHz
wire    sys_rst_n = rst_n;

//-----------------------------------------
//CMOS Camera interface and data output simulation
wire            cmos_xclk;              //24MHz drive clock
wire            cmos_pclk;              //24MHz CMOS Pixel clock input
wire            cmos_vsync;             //L: vaild, H: invalid
wire            cmos_href;              //H: vaild, L: invalid
wire    [7:0]   cmos_data;              //8 bits cmos data input

Video_Image_Simulate_CMOS
#(
    .CMOS_VSYNC_VALID   (1'b1),     //VSYNC = 1
    .IMG_HDISP          (10'd32),   //(10'd640),    //640*480
    .IMG_VDISP          (10'd4)     //(10'd480)
)
u_Video_Image_Simulate_CMOS
(
    //global reset
    .rst_n              (sys_rst_n),

    //CMOS Camera interface and data output simulation
    .cmos_xclk          (clk_cmos),         //25MHz cmos clock
    .cmos_pclk          (cmos_pclk),        //25MHz when rgb output
    .cmos_vsync         (cmos_vsync),       //L: vaild, H: invalid
    .cmos_href          (cmos_href),        //H: vaild, L: invalid
    .cmos_data          (cmos_data)         //8 bits cmos data input
);

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------

//cmos video image capture
wire          cmos_init_done = 1'b1;  //cmos camera init done
wire          cmos_frame_vsync;       //cmos frame data vsync valid signal
wire          cmos_frame_href;        //cmos frame data href vaild  signal
wire  [15:0]  cmos_frame_data;        //cmos frame data output: {cmos_data[7:0]<<8, cmos_data[7:0]}
wire          cmos_frame_clken;       //cmos frame data output/capture enable clock
wire  [7:0]   cmos_fps_rate;          //cmos image output rate

CMOS_Capture_RGB565 
#(
    .CMOS_FRAME_WAITCNT     (4'd1)    //Wait n fps for steady(OmniVision need 10 Frame)
)
u_CMOS_Capture_RGB565
(
    //global clock
    .clk_cmos               (clk_cmos),         //24MHz CMOS Driver clock input
    .rst_n                  (sys_rst_n & cmos_init_done),   //global reset

    //CMOS Sensor Interface
    .cmos_pclk              (cmos_pclk),        //24MHz CMOS Pixel clock input
    .cmos_xclk              (cmos_xclk),        //24MHz drive clock
    .cmos_data              (cmos_data),        //8 bits cmos data input
    .cmos_vsync             (cmos_vsync),       //L: vaild, H: invalid
    .cmos_href              (cmos_href),        //H: vaild, L: invalid

    //CMOS SYNC Data output
    .cmos_frame_vsync       (cmos_frame_vsync), //cmos frame data vsync valid signal
    .cmos_frame_href        (cmos_frame_href),  //cmos frame data href vaild  signal
    .cmos_frame_data        (cmos_frame_data),  //cmos frame RGB output: {{R[4:0],G[5:3]}, {G2:0}, B[4:0]}
    .cmos_frame_clken       (cmos_frame_clken), //cmos frame data output/capture enable clock

    //user interface
    .cmos_fps_rate          (cmos_fps_rate)     //cmos image output rate
);

//----------------------------------------------------
//Video Image processor module.
//Image data prepred to be processd
wire            pre_frame_vsync =   cmos_frame_vsync;   //Prepared Image data vsync valid signal
wire            pre_frame_href  =   cmos_frame_href;    //Prepared Image data href vaild  signal
wire            pre_frame_clken =   cmos_frame_clken;   //Prepared Image data output/capture enable clock
wire    [15:0]  pre_img_y       =   cmos_frame_data;    //Prepared Image brightness output
wire            post_frame_vsync;   //Processed Image data vsync valid signal
wire            post_frame_href;    //Processed Image data href vaild  signal
wire            post_frame_clken;   //Processed Image data output/capture enable clock
wire    [7:0]   post_img_y;         //Processed Image brightness output

vip u_vip(
    //module clock
    .clk              (cmos_pclk),           // ʱ���ź�
    .rst_n            (sys_rst_n    ),       // ��λ�źţ�����Ч��
    //ͼ����ǰ�����ݽӿ�
    .pre_frame_vsync  (pre_frame_vsync   ),
    .pre_frame_href   (pre_frame_href   ),
    .pre_frame_de     (pre_frame_clken   ),
    .pre_rgb          (pre_img_y),

    //ͼ����������ݽӿ�
    .post_frame_vsync (post_frame_vsync ),   // ��ͬ���ź�
    .post_frame_href  (post_frame_href),     // ��ͬ���ź�
    .post_frame_de    (post_frame_clken ),   // ��������ʹ��
    .post_rgb         (post_img_y)           // RGB565��ɫ����
);

//---------------------------------------------
//testbench of the RTL
task task_sysinit;
begin
end
endtask

//----------------------------------------------
initial
begin
    task_sysinit;
    task_reset;
end

endmodule