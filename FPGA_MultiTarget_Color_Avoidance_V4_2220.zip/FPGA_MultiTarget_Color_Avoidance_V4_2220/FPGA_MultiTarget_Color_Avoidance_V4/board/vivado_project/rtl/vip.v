// Original base: Copyright(C) ALIENTEK 2023-2033. All rights reserved.
// Keep the camera RGB565 samples unchanged. Auxiliary Y/Cb/Cr and all
// controls describe the same pixel, with exactly four input-clock stages.
`default_nettype none
module vip(
 input wire clk,rst_n,pre_frame_vsync,pre_frame_href,pre_frame_de,
 input wire [15:0] pre_rgb,
 output wire post_frame_vsync,post_frame_href,post_frame_de,
 output wire [15:0] post_rgb,
 output wire [7:0] post_gray,post_cb,post_cr
);
 wire cv,ch,cd;wire [7:0] y,cb,cr;
 reg [15:0] rgb_delay[0:2];
 reg [15:0] rgb_out_r;
 reg [7:0] gray_out_r,cb_out_r,cr_out_r;
 reg vsync_out_r,href_out_r,de_out_r;
 integer i;
 rgb2ycbcr convert(
  .clk(clk),.rst_n(rst_n),.pre_frame_vsync(pre_frame_vsync),.pre_frame_href(pre_frame_href),.pre_frame_de(pre_frame_de),
  .img_red(pre_rgb[15:11]),.img_green(pre_rgb[10:5]),.img_blue(pre_rgb[4:0]),
  .post_frame_vsync(cv),.post_frame_href(ch),.post_frame_de(cd),.img_y(y),.img_cb(cb),.img_cr(cr)
 );
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   for(i=0;i<3;i=i+1)rgb_delay[i]<=0;
   rgb_out_r<=0;gray_out_r<=0;cb_out_r<=0;cr_out_r<=0;
   vsync_out_r<=0;href_out_r<=0;de_out_r<=0;
  end else begin
   rgb_delay[0]<=pre_rgb;rgb_delay[1]<=rgb_delay[0];rgb_delay[2]<=rgb_delay[1];
   rgb_out_r<=rgb_delay[2];gray_out_r<=y;cb_out_r<=cb;cr_out_r<=cr;
   vsync_out_r<=cv;href_out_r<=ch;de_out_r<=cd;
  end
 end
 assign post_rgb=rgb_out_r;
 assign post_gray=gray_out_r;assign post_cb=cb_out_r;assign post_cr=cr_out_r;
 assign post_frame_vsync=vsync_out_r;assign post_frame_href=href_out_r;assign post_frame_de=de_out_r;
endmodule
`default_nettype wire
