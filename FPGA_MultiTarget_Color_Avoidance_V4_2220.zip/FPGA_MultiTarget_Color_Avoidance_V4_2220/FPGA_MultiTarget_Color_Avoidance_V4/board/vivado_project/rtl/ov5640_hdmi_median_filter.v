//****************************************Copyright (c)***********************************//
//闁告鍠栭弫鎾诲箳閵夆晜浜ら柟椋庡厴閺佹捇寮妶鍡楊伓闂佽法鍠撻顏堝棘閵堝棗顏堕悗娑崇畱闁解晠宕ｆ导瀛樻櫢闁哄倶鍊栫€氱畤ww.yuanzige.com
//闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊寮ㄩ鐐存櫢閻炴稒顨愮紞鍥箯缁屾仭tp://www.openedv.com/forum.php
//闂佽法鍠撳▓鏇㈠箟鐎ｎ偄顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁轰焦鐟辩紞鍥箯缁屾仭tps://zhengdianyuanzi.tmall.com
//闂佽法鍠愰弸濠氬箯闁垮鏆堢€甸偊鍣ｉ弫鎾绘嚇濮樿鲸顏熼柟椋庡厴閺佹捇寮妶鍡楊伓妤犵偛鍟胯ぐ鏉戭嚗椤曗偓閺佹捇鎳樺顒€濞囬柨婵嗙箲鐎氾拷"闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊宕㈤悢鍏兼櫢闁哄倶鍊栫€氾拷"闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳銈﹂敃鍌涙櫢濡ゆぞ璀﹂幗鏈癗Q & FPGA & STM32 & LINUX闂佽法鍠愰弸濠氬箯閻戣姤鏅搁弶鍫濆暊濡插嫰骞忛敓锟�
//闂佽法鍠愰弸濠氬箯闁垮缍€闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柛娆樺亾缂嶅洭骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏樼槐锝夋煥閻斿憡鐏柟椋庡厴閺佹捇鏁撻敓锟�
//Copyright(C) 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊宕㈤悢鍏兼櫢闁哄倶鍊栫€氾拷 2023-2033
//All rights reserved                                  
//----------------------------------------------------------------------------------------
// File name:           ov5640_hdmi_median_filter
// Created by:          闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊宕㈤悢鍏兼櫢闁哄倶鍊栫€氾拷
// Created date:        2025闂佽法鍠愰弸濠氬箯閿燂拷11闂佽法鍠愰弸濠氬箯閿燂拷5闂佽法鍠愰弸濠氬箯閿燂拷10:40:02
// Version:             V1.0
// Descriptions:        闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氱瓌V5640闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳寰勯幘顔芥櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁瑰嘲鍢查埀顒€銈搁弫鎾诲礈閼愁垼鍤嬮柟椋庡厴閺佹捇寮妶鍡楊伓闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氾拷
//
//----------------------------------------------------------------------------------------
//****************************************************************************************//

`default_nettype none
module ov5640_hdmi_median_filter(    
    input wire sys_clk      ,  //缂侇垵宕电划娲籍閸洘鏅搁柡鍌樺€栫€氾拷
    input wire sys_rst_n    ,  //缂侇垵宕电划娲煥閻斿憡鐏柟鐤腹缂嶅懘鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘煀閻㈡鏆滈柟宄板槻闁解晠鏌ㄩ悢鍛婄伄闁圭兘鏀遍弲锟�
    //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳寰勯幘顔芥櫢闁规亽鍎辩亸鍛村箯閿燂拷
    input wire cam_pclk     ,  //cmos 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕柡鍐ㄧ埣閺佹捇寮妶鍡楊伓
    input wire cam_vsync    ,  //cmos 闂佽法鍠愰弸濠氬箯瀹勭増鍊遍梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁煎瓨姘ㄧ亸銊╁箯閿燂拷
    input wire cam_href     ,  //cmos 闂佽法鍠愰弸濠氬箯瀹勭増鍊遍梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁煎瓨姘ㄧ亸銊╁箯閿燂拷
    input wire [7:0]         cam_data     ,  //cmos 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氾拷
    output wire cam_rst_n    ,  //cmos 闂佽法鍠愰弸濠氬箯閾氬倻绉撮梺璺ㄥ枙閸撳ジ宕ｉ崙銈囩Ф闁归鍏橀弫鎾绘煀閻㈡鏆滈柟宄板槻闁解晠鏌ㄩ悢鍛婄伄闁圭兘鏀遍弲锟�
    output wire cam_pwdn     ,  //闂佽法鍠愰弸濠氬箯闁垮鐖遍梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氱懓螣閳ュ磭纭€闂侇偄顦甸弫鎾诲棘閵堝棗顏� 0闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯鐎殿噯鎷� 1闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氱懓鈹冮幇鐗堟櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯鐎殿噯鎷�
    output wire cam_scl      ,  //cmos SCCB_SCL闂佽法鍠愰弸濠氬箯閿燂拷
    inout wire cam_sda      ,  //cmos SCCB_SDA闂佽法鍠愰弸濠氬箯閿燂拷
    input wire key0        ,  // 闁哄倹婢橀·鍐晬濞嗙竴Y0闁哄鍎诲ù鍥箰婢舵劖鏆涢弶鍫熸尭閸欙拷
    input wire key1        ,  // KEY1閺夎儻娴囬幐澶愭暛鏉堟挸鍙嗛敍鍫ヮ杹閼规彃鍨忛幑顫礆
    input wire uart_rxd    ,  // USB-UART RX from CH340C
    output wire uart_txd   ,  // USB-UART TX to CH340C
    // DDR3
    inout wire [31:0]        ddr3_dq      ,  //DDR3 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氾拷
    inout wire [3:0]         ddr3_dqs_n   ,  //DDR3 dqs闂佽法鍠愰弸濠氬箯閿燂拷
    inout wire [3:0]         ddr3_dqs_p   ,  //DDR3 dqs闂佽法鍠愰弸濠氬箯閿燂拷  
    output wire [13:0]        ddr3_addr    ,  //DDR3 闂佽法鍠愰弸濠氬箯瀹勭増绲�   
    output wire [2:0]         ddr3_ba      ,  //DDR3 bank闂侇偄顦甸弫鎾诲棘閵堝棗顏�
    output wire ddr3_ras_n   ,  //DDR3 闂佽法鍠愰弸濠氬箯閻戣В鍋撴径鎰櫢闁哄倶鍊栫€氾拷
    output wire ddr3_cas_n   ,  //DDR3 闂佽法鍠愰弸濠氬箯閻戣В鍋撴径鎰櫢闁哄倶鍊栫€氾拷
    output wire ddr3_we_n    ,  //DDR3 闂佽法鍠愰弸濠氬箯瀹勬澘鏅搁梺顐㈩樀閺佹捇寮妶鍡楊伓
    output wire ddr3_reset_n ,  //DDR3 闂佽法鍠愰弸濠氬箯閾氬倻绉�
    output wire [0:0]         ddr3_ck_p    ,  //DDR3 闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛敓锟�
    output wire [0:0]         ddr3_ck_n    ,  //DDR3 闁哄啫鐖奸弫鎾诲箳閵夆晜浜ら柟鍑ゆ嫹
    output wire [0:0]         ddr3_cke     ,  //DDR3 闁哄啫鐖奸弫鎾诲棘閵堝棗顏跺ù锝呮健閺佹捇寮妶鍡楊伓
    output wire [0:0]         ddr3_cs_n    ,  //DDR3 闁绘娲埀顒婃嫹
    output wire [3:0]         ddr3_dm      ,  //DDR3_dm
    output wire [0:0]         ddr3_odt     ,  //DDR3_odt
    //HDMI闂佽法鍠愮敮鎾礌閳╁啫顏�
    output wire tmds_clk_p   ,  //TMDS 闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺顐ｅ哺閺佹捇寮妶鍡楊伓
    output wire tmds_clk_n   ,
    output wire [2:0]         tmds_data_p  ,  //TMDS 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌呭鑸垫櫢闁哄倶鍊栫€氾拷
    output wire [2:0]         tmds_data_n  
    );

parameter  V_CMOS_DISP = 11'd768;         //CMOS闂佽法鍠曢、婊堝箟鐎ｎ偄顏堕梺璺ㄥ枑閺嬪骞忛敓锟�--闂佽法鍠愰弸濠氬箯閿燂拷
parameter  H_CMOS_DISP = 11'd1024;        //CMOS闂佽法鍠曢、婊堝箟鐎ｎ偄顏堕梺璺ㄥ枑閺嬪骞忛敓锟�--闂佽法鍠愰弸濠氬箯閿燂拷
parameter  TOTAL_H_PIXEL = H_CMOS_DISP + 12'd1216;
parameter  TOTAL_V_PIXEL = V_CMOS_DISP + 12'd504;

//wire define
wire pixel_clk,pixel_clk_5x,rd_vsync,post_frame_href;
wire          clk_50m              ;  //50MHz闁哄啫鐖奸弫鎾诲棘閵堝棗顏�
wire          locked               ;  //闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢璇插闁绘艾鐡ㄧ€氾拷
wire          rst_n                ;  //闁稿繈鍔戦弫鎾舵偘濡ゅ懏浜ら柟鐤腹缂嶏拷
wire          cam_init_done        ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳寰勯幘顔芥櫢闁哄倶鍊栫€氳鎱ㄧ€ｎ喗鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘晸閿燂拷
wire          i2c_done             ;  //I2C闂佽法鍠嶉懠搴㈡綇閻愵剙顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悿顖涱棛闂佽法鍣﹂幏锟�
wire          i2c_dri_clk          ;  //I2C闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊寮崼鏇熸櫢闁哄倶鍊栫€氾拷
wire          wr_en                ;  //DDR3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯闂佽法鍠愰弸濠氬箯瀹勬澘鏅稿ù锝呮健閺佹捇寮妶鍡楊伓
wire  [15:0]  wr_data              ;  //DDR3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯闂佽法鍠愰弸濠氬箯瀹勬澘鏅搁梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
wire          rdata_req            ;  //DDR3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯闂佽法鍠愰弸濠氬箯閻戣姤鏅哥紓浣哄仧濞呫垽骞忛悜鑺ユ櫢闁跨噦鎷�
wire  [15:0]  rd_data              ;  //DDR3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀辫啯闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘晸閿燂拷
wire          cmos_frame_valid     ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀遍弲銉︽媴閸ф鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢璇插闁绘艾鐡ㄧ€氾拷
wire          init_calib_complete  ;  //DDR3闂佽法鍠愰弸濠氬箯瀹勯偊娼楅梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢铏诡浄nit_calib_complete
wire          sys_init_done        ;  //缂侇垵宕电划娲煥閻斿憡鐏柟宄板槻椤劙鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ櫐閹凤拷(DDR闂佽法鍠愰弸濠氬箯瀹勯偊娼楅梺璺ㄥ枑閺嬪骞忛敓锟�+闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳寰勯幘顔芥櫢闁哄倶鍊栫€氳鎱ㄧ€ｎ喗鏅搁柡鍌樺€栫€氾拷)
wire          clk_200m             ;  //DDR3闂佽法鍠曟繛鍥礌閳╁啫顏堕柡鍐ㄧ埣閺佹捇寮妶鍡楊伓
wire          cmos_frame_vsync     ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁悶娑欍仜濡插嫰骞忛悜鑺ユ櫢闁告瑯鍊ゅ鍡楊伓闂佽法鍠栭崣娲敆婵犲啫顏堕梺璺ㄥ枑閺嬪骞忛悿顖涱棛闂佽法鍣﹂幏锟�
wire          cmos_frame_href      ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁悶娑欍仜濡插嫰骞忛悜鑺ユ櫢闁告瑯鍊ゅ鍡楊伓闂佽法鍠栭崣娲敆婵犲啫顏堕梺璺ㄥ枑閺嬪骞忛悿顖涱棛闂佽法鍣﹂幏锟�
wire  [10:0]  pixel_xpos           ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柟鎼簽椤ｎ噣骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘晸閿燂拷
wire  [10:0]  pixel_ypos           ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柟鎼簽椤ｎ噣骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏�
wire  [15:0]  post_rgb             ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁瑰嘲鍢插ù姗€鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛敓锟�
wire          post_frame_vsync     ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鎯板缂佹稖顫夌€氬綊鏌ㄩ悢璇插闁绘艾鐡ㄧ€氾拷
wire          post_frame_de        ;  //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊寮崼婊冣枏闂佽法鍠愰弸濠氬箯閿燂拷

///////////////////////////
wire [10:0]  center_x;         // 婵☆偀鍋撴繛鏉戭儑濞蹭即寮介崶锕佸幀闊洤鍎ｉ柛褎鍔栭悥锟�
wire [10:0]  center_y;         // 婵☆偀鍋撴繛鏉戭儑濞蹭即寮介崶锕佸幀闊洤鍎ら柛褎鍔栭悥锟�
wire         center_valid;     // 闁烩晩鍠楅悥锝夊嫉婢跺娅忛柡宥呮搐缁伙拷
wire         frame_pulse;      // 閻㈩垎鍐╁€辨慨婵勫劥閸擄箓宕樼拠褏绀勬慨锝呯箰閹舵碍绋夐埀顒佺▔椤忓海绀�
wire         key_short_pulse;  // 闁活収鍘界€垫粓鎳樻径濠傛毐
wire         key_long_pulse;   // 闂傗偓閹稿骸鐦婚柤鏉戭槸閸燂拷
wire         key1_short_pulse;// KEY1閻厽瀵滈懘澶婂暱
wire         key1_long_pulse; // KEY1闂€鎸庡瘻閼村鍟�
reg [1:0]    color_mode;      // 妫版粏澹婂Ο鈥崇础閿涳拷0=blue,1=red,2=green,3=all
wire         recording;        // 閻犱焦婢樼紞宥嗘媴閼愁垰鍘�
wire         clear_traj;       // 婵炴挸鎳愰埞鏍ㄦ姜閵娿劍濮�
wire         draw_start;       // 鐎殿喒鍋撳┑顔碱儑閺佸墽鐥敓锟�
wire         draw_busy;        // 闁汇垼宕甸崵搴ょ疀閿燂拷
wire         clear_start;      // 鐎殿喒鍋撳┑顔碱儐缁旇崵绮氶敓锟�
wire         clear_busy;       // 婵炴挸鎳愰埞鏍矚濞差亝锛�

wire [9:0]   draw_x0, draw_y0, draw_x1, draw_y1; // 闁汇垼宕甸崵搴ㄥ锤閹邦厾鍨�
wire [19:0]  bmp_waddr;       // 濞达絽绉村ù姗€宕樺▎蹇斿嬀闁秆€鍋�
wire         bmp_wdata;       // 濞达絽绉村ù姗€宕樺▎鎰闁圭櫢鎷�
wire         bmp_wen;         // 濞达絽绉村ù姗€宕樺▎搴♀枏闁肩鎷�
wire [19:0]  bmp_raddr;       // 濞达絽绉村ù妯兼嫚鐠囧弶鍕鹃柛褉鍋�
wire         bmp_rdata;       // 濞达絽绉村ù妯兼嫚缂佹ɑ娈堕柟鐧告嫹

wire         traj_hit;        // 閺夌偑鍔忛幎妤呭磽韫囨洜顦遍柛娑欏灊閼碉拷
wire [15:0]  hdmi_data_final; // 闁哄牃鍋撶紓浣告箽DMI閺夊牊鎸搁崵顓㈠极閻楀牆绁�

wire [15:0] roi_valid, roi_observed, roi_estimated;
wire [175:0] roi_x0, roi_x1, roi_y0, roi_y1;
wire [47:0] roi_color;
wire [3:0] goal_index;
wire [15:0] astar_obs_valid;

wire         host_short_pulse;
wire         host_clear_pulse;
wire         host_path_snapshot_pulse;
wire         host_path_clear_pulse;
wire         host_path_live_pulse;
wire [1:0]   path_mode;
wire         host_mode_stb;
wire [1:0]   host_mode;
wire         traj_short_pulse;
wire         traj_long_pulse;
wire [1:0]   traj_state;
wire         path_planning_busy;

wire [10:0] car_cx, car_cy;

wire        car_valid;
wire [3:0]  car_index;

wire        goal_valid;
wire [15:0] cnn_block_valid;
wire [10:0] goal_cx, goal_cy;
wire [10:0] goal_min_x, goal_min_y, goal_max_x, goal_max_y;

wire        path_valid, path_hit, path_hit_vis;

///////////////////////////
wire [15:0] hdmi_data_d;
wire cnn_overlay_hit;
reg cnn_overlay_hit_d1;
reg rdata_req_d;
always @(posedge pixel_clk or negedge rst_n)
 if(!rst_n)rdata_req_d<=0;else rdata_req_d<=rdata_req;
wire [5:0]  time_sec;   // 鏉炪劏鎶楃拋鏉跨秿閺冨爼妫块敍鍫㈩潡閿涳拷
wire        osd_hit;
reg         osd_hit_d1;    // OSD 閺傚洤鐡ч崨鎴掕厬
//*****************************************************
//**                    main code
//*****************************************************

//闂佽法鍠愰弸濠氬箯闁垮顦ч梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢璇测枏濞村吋鐟︾€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕柦妯绘礋閺佹捇鏁撻敓锟�
wire rst_n_raw=sys_rst_n & locked;
wire camera_rst_n,config_rst_n;
reset_release_sync rst_pixel(.clk(pixel_clk),.arst_n(rst_n_raw),.srst_n(rst_n));
reset_release_sync rst_camera(.clk(cam_pclk),.arst_n(rst_n_raw),.srst_n(camera_rst_n));
reset_release_sync rst_config(.clk(clk_50m),.arst_n(rst_n_raw),.srst_n(config_rst_n));

// KEY1 short press: blue -> red -> green -> all -> blue
always @(posedge pixel_clk or negedge rst_n) begin
    if (!rst_n)
        color_mode <= 2'd0;
    else if (host_mode_stb)
        color_mode <= host_mode;
    else if (key1_short_pulse) begin
        if (color_mode == 2'd3)
            color_mode <= 2'd0;
        else
            color_mode <= color_mode + 2'd1;
    end
end

//缂侇垵宕电划娲煥閻斿憡鐏柟宄板槻椤劙鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏舵俊妤佸灴閺佹挾妲愮猾鍢�3闂佽法鍠愰弸濠氬箯瀹勯偊娼楅梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悤鍌涘
assign  sys_init_done = init_calib_complete;

//OV5640闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳寰勯幘顔芥櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁瑰嚖鎷�
ov5640_dri u_ov5640_dri (
    .clk               (clk_50m),
    .rst_n             (config_rst_n),

    .cam_pclk          (cam_pclk ),
    .cam_vsync         (cam_vsync),
    .cam_href          (cam_href ),
    .cam_data          (cam_data ),
    .cam_rst_n         (cam_rst_n),
    .cam_pwdn          (cam_pwdn ),
    .cam_scl           (cam_scl  ),
    .cam_sda           (cam_sda  ),

    .capture_start     (init_calib_complete),
    .cmos_h_pixel      (H_CMOS_DISP),
    .cmos_v_pixel      (V_CMOS_DISP),
    .total_h_pixel     (TOTAL_H_PIXEL),
    .total_v_pixel     (TOTAL_V_PIXEL),
    .cmos_frame_vsync  (cmos_frame_vsync),
    .cmos_frame_href   (cmos_frame_href),
    .cmos_frame_valid  (cmos_frame_valid),
    .cmos_frame_data   (wr_data)
    );

//闁搞儵绠栭弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛柨瀣嗕線鏌ㄩ悢鍛婄伄闁瑰嚖鎷�
vip u_vip (
    //module clock
    .clk              (cam_pclk),          // 闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺璺ㄥ枙閸撳ジ鎮€涙ê顏�
    .rst_n            (camera_rst_n),            // 闂佽法鍠愰弸濠氬箯閾氬倻绉撮梺璺ㄥ枙閸撳ジ宕ｉ崙銈囩Ф闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛柨瀣珡闂佽法鍠愰弸濠氬箯閿燂拷
    //闁搞儵绠栭弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忓畡鏉款枀闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢绋跨ス闁规亽鍎辩亸鍛村箯閿燂拷
    .pre_frame_vsync  (cmos_frame_vsync),
    .pre_frame_href   (cmos_frame_href),
    .pre_frame_de     (cmos_frame_valid),
    .pre_rgb          (wr_data),

    //闁搞儵绠栭弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲箲闁垮澶嶉柛鏍ゅ墲鐎氾拷
    .post_frame_vsync (post_frame_vsync),  // 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鎯板缂佹稖顫夌€氬綊鏌ㄩ悢璇插闁绘艾鐡ㄧ€氾拷
    .post_frame_href  (post_frame_href),                 // 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枙閸撳ジ鎮€涙ê顏�
    .post_frame_de    (post_frame_de),     // 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊寮崼婊冣枏闂佽法鍠愰弸濠氬箯閿燂拷
    .post_rgb         (post_rgb) ,          // 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁瑰嘲鍢插ù姗€鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛敓锟�
    .post_gray() ,         // 闂佸搫鍊瑰姗€路閸愵喗鏅慨姗嗗墻濡查亶鏌ｉ悙鍙夘棞闁诡喗顨堥惀顏堫敍濠娾偓缁辨骞栨潏鍓х暠婵炲瓨锕㈠畷鎾圭疀濮樿京鐐曢梺鍛婂煀閹凤拷///////////////////////////////////
    .post_cb(),           // 闁哄倹婢橀·鍐晬濮橆剦妲遍柣鐐叉閹b闁艰褰冪€硅櫕娼忛幘鍐叉瘔  ////////////////2
    .post_cr()            // 闁哄倹婢橀·鍐晬濮橆剦妲遍柣鐐叉閹r闁艰褰冪€硅櫕娼忛幘鍐叉瘔  ////////////////2
    );

//DDR3闂佽法鍠愰弸濠氬箯瀹勬澘鏅搁梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氱懓螣閿熺姵鏅搁柡鍌樺€栫€氾拷
ddr3_top u_ddr3_top (
    .rst_n               (rst_n),                //闂佽法鍠愰弸濠氬箯閾氬倻绉�,闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊寮敓锟�
    .init_calib_complete (init_calib_complete),  //DDR3闂佽法鍠愰弸濠氬箯瀹勯偊娼楅梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鏌夊Λ鏃堟煥閻曞倹瀚�
    //DDR3闂佽法鍠愮敮鎾礌閳╁啫顏堕梺璺ㄥ枙閸撳ジ鎮€涙ê顏�
    .app_addr_rd_min     (28'd0),                //闂佽法鍠愰弸濠氬箯缁嬵棯R3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳鎱ㄧ€ｎ喗鏅搁柡鍌樺€栫€氬綊宕搁埀锟�
    .app_addr_rd_max     (28'd393216),           //闂佽法鍠愰弸濠氬箯缁嬵棯R3闂佽法鍠嶉懠搴ㄥ棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊宕搁埀锟�
    .rd_bust_len         (H_CMOS_DISP[10:4]),    //闂佽法鍠愰弸濠氬箯缁嬵棯R3闂佽法鍠庤ぐ銊ф媼鐟欏嫬顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊寮崼鏇熸櫢闁哄倶鍊栫€氬湱绮ｆ笟鈧弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
    .app_addr_wr_min     (28'd0),                //闁告劖顭紻R3闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氳鎱ㄧ€ｎ喗鏅搁柡鍌樺€栫€氬綊宕搁埀锟�
    .app_addr_wr_max     (28'd393216),           //闁告劖顭紻R3闂佽法鍠嶉懠搴ㄥ棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊宕搁埀锟�
    .wr_bust_len         (H_CMOS_DISP[10:4]),    //闂佽法鍠愰弸濠氬箯缁嬵棯R3闂佽法鍠愰弸濠氬箯瀹勬澘鏅搁梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊寮崼鏇熸櫢闁哄倶鍊栫€氬湱绮ｆ笟鈧弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
    // DDR3 IO闂佽法鍠愮敮鎾礌閳╁啫顏�
    .ddr3_dq             (ddr3_dq),              //DDR3 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氾拷
    .ddr3_dqs_n          (ddr3_dqs_n),           //DDR3 dqs闂佽法鍠愰弸濠氬箯閿燂拷
    .ddr3_dqs_p          (ddr3_dqs_p),           //DDR3 dqs
    .ddr3_addr           (ddr3_addr),            //DDR3 闂佽法鍠愰弸濠氬箯瀹勭増绲�
    .ddr3_ba             (ddr3_ba),              //DDR3 bank闂侇偄顦甸弫鎾诲棘閵堝棗顏�
    .ddr3_ras_n          (ddr3_ras_n),           //DDR3 闂佽法鍠愰弸濠氬箯閻戣В鍋撴径鎰櫢闁哄倶鍊栫€氾拷
    .ddr3_cas_n          (ddr3_cas_n),           //DDR3 闂佽法鍠愰弸濠氬箯閻戣В鍋撴径鎰櫢闁哄倶鍊栫€氾拷
    .ddr3_we_n           (ddr3_we_n),            //DDR3 闂佽法鍠愰弸濠氬箯瀹勬澘鏅搁梺顐㈩樀閺佹捇寮妶鍡楊伓
    .ddr3_reset_n        (ddr3_reset_n),         //DDR3 闂佽法鍠愰弸濠氬箯閾氬倻绉�
    .ddr3_ck_p           (ddr3_ck_p),            //DDR3 闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛敓锟�
    .ddr3_ck_n           (ddr3_ck_n),            //DDR3 闁哄啫鐖奸弫鎾诲箳閵夆晜浜ら柟鍑ゆ嫹
    .ddr3_cke            (ddr3_cke),             //DDR3 闁哄啫鐖奸弫鎾诲棘閵堝棗顏跺ù锝呮健閺佹捇寮妶鍡楊伓
    .ddr3_cs_n           (ddr3_cs_n),            //DDR3 闁绘娲埀顒婃嫹
    .ddr3_dm             (ddr3_dm),              //DDR3_dm
    .ddr3_odt            (ddr3_odt),             //DDR3_odt
    // System Clock Ports
    .sys_clk_i           (clk_200m),
    // Reference Clock Ports
    .clk_ref_i           (clk_200m),
    //闂佽法鍠撻悡顐ｅ濞嗘劕顏堕梺璺ㄥ枑鐢挳宕犻埄鍐伓
    .ddr3_read_valid     (1'b1),                 //DDR3 闂佽法鍠愰弸濠氬箯閾氬倸鈻忛梺璺ㄥ枑閺嬪骞忛敓锟�
    .ddr3_pingpang_en    (1'b1),                 //DDR3 濞戞梹甯￠弫鎾诲箵椤撯槅鍤嬮柟椋庡厴閺佹捇寮妶鍡楊伓濞达絽娼￠弫鎾诲棘閵堝棗顏�
    .wr_clk              (cam_pclk),             //闁告劖鐟﹀鍌炴煥閻斿憡鐏柟鍑ゆ嫹
    .wr_load             (post_frame_vsync),     //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氱懓鈹冮幇鐗堟櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘嚇濮樺崬鐨戦柟鍑ゆ嫹
    .wr_en               (post_frame_de),        //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘鏀遍弲銉︽媴閸ф鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢璇插闁绘艾鐡ㄧ€氾拷
    .wrdata              (post_rgb),             //闂佽法鍠愰弸濠氬箯闁垮娅忛梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
    .rd_clk              (pixel_clk),            //闂佽法鍠愰弸濠氬箯闁垮顦ч梺璺ㄥ枑閺嬪骞忛敓锟�
    .rd_load             (rd_vsync),             //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柣銊ユ閹活亪骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鏌夊Λ鏃堟煥閻曞倹瀚�
    .rddata              (rd_data),              //rfifo闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘晸閿燂拷
    .rdata_req           (rdata_req)             //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
    );

//闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊寮崼鏇熸櫢闁哄倶鍊栫€氱P闂佽法鍠愰弸濠氬箯閿燂拷
 clk_wiz_0 u_clk_wiz_0 (
    // Clock out ports
    .clk_out1              (clk_200m),
    .clk_out2              (clk_50m),
    .clk_out3              (pixel_clk_5x),
    .clk_out4              (pixel_clk),
    // Status and control signals
    .reset                 (~sys_rst_n),
    .locked                (locked),
   // Clock in ports
    .clk_in1               (sys_clk)
    );

//HDMI闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁圭兘顥撻妵姘熼敓鐘虫櫢闁哄倶鍊栫€氾拷
hdmi_top u_hdmi_top (
    .pixel_clk            (pixel_clk),
    .pixel_clk_5x         (pixel_clk_5x),
    .sys_rst_n            (sys_init_done & rst_n),
    //HDMI闂佽法鍠愮敮鎾礌閳╁啫顏�
    .tmds_clk_p           (tmds_clk_p),    // TMDS 闁哄啫鐖奸弫鎾诲棘閵堝棗顏堕梺顐ｅ哺閺佹捇寮妶鍡楊伓
    .tmds_clk_n           (tmds_clk_n),
    .tmds_data_p          (tmds_data_p),   // TMDS 闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌呭鑸垫櫢闁哄倶鍊栫€氾拷
    .tmds_data_n          (tmds_data_n),
    //闂佽法鍠撻悡顐ｅ濞嗘劕顏堕梺璺ㄥ枑鐢挳宕犻埄鍐伓
    .video_vs             (rd_vsync),      //HDMI闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柤瀛樻皑鐏忋劑骞忛敓锟�
    .pixel_xpos           (pixel_xpos),    //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柟鎼簽椤ｎ噣骞忛悜鑺ユ櫢闁哄倶鍊栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾绘晸閿燂拷
    .pixel_ypos           (pixel_ypos),
    //.data_in              (hdmi_data_d),       //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏�
    .data_in         (hdmi_data_final),     // 濞ｅ浂鍠楅弫濂告晬濮橆厼澶嶉柛蹇嬪劚瑜版棃宕濋悩鍝勭紦閺夆晝鎳撻幃妤呮儍閸曨剚浠樼紓浣哥墢閺侀箖妫冮敓锟�
    .data_req             (rdata_req)      //闂佽法鍠愰弸濠氬箯閻戣姤鏅搁柡鍌樺€栫€氬綊鏌ㄩ悢鍛婄伄闁归鍏橀弫鎾诲棘閵堝棗顏堕梺璺ㄥ枑閺嬪骞忛悜鑺ユ櫢闁哄倶鍊栫€氾拷
    );

// ===== HDMI闁哄牃鍋撶紓浣哥墣缁额參宕欓悮瀵哥獥閺夌偑鍔忛幎妤佸濡搫甯ョ紒鐙欏洨褰ù婊冩捣鐠炪垹顩奸崱娆愭毎闂傚牞鎷� =====
reg [15:0] hdmi_data_d_d1;   // 娴ｅ秴娴橀崥灞绢劄鐠囩粯娅�1閹峰稄绱濋悽濠氭桨娑旂喎娆㈡潻锟�1閹峰秴顕锟�
always @(posedge pixel_clk or negedge rst_n) begin
    if (!rst_n)
        begin hdmi_data_d_d1 <= 16'd0;cnn_overlay_hit_d1<=0;osd_hit_d1<=0;end
    else
        begin hdmi_data_d_d1 <= hdmi_data_d;cnn_overlay_hit_d1<=cnn_overlay_hit;osd_hit_d1<=osd_hit;end
end

assign path_hit_vis = path_hit && (color_mode == 2'd3);

assign hdmi_data_final =
    osd_hit_d1       ? 16'h07E0 :
    path_hit_vis     ? 16'h07E0 :
    cnn_overlay_hit_d1 ? hdmi_data_d_d1 :
    traj_hit         ? 16'h001F :
    hdmi_data_d_d1;

//==================== multi object detect + overlay ====================//
multi_object_overlay_v2 #(
    .MAX_OBJ        (16)
) u_multi_object_overlay_v2 (
    .cam_clk        (cam_pclk),
    .pixel_clk      (pixel_clk),
    .rst_n          (rst_n_raw),
    .frame_vsync    (post_frame_vsync),
    .frame_href     (post_frame_href),
    .frame_de       (post_frame_de),
    .frame_rgb      (post_rgb),
/////////////////////////
    .color_mode     (color_mode),   // 妫版粏澹婂Ο鈥崇础闁瀚�
    .center_x       (center_x),       // 闁哄倹婢橀·鍐晬濮樿鲸绐楅柡宥呮矗閼垫垼绠涢崓妤呭锤閹邦厾鍨�
    .center_y       (center_y),       // 闁哄倹婢橀·鍐晬濮樿鲸绐楅柡宥呮矗閼垫垼绠涢崓姗€宕搁幇顓犲灱
    .center_valid   (center_valid),   // 闁哄倹婢橀·鍐晬濮樿鲸绐楅柡宥呮处濠€渚€寮崼鐔哄灱闊浄鎷�
    .cnn_car_valid  (car_valid),
    .cnn_car_index  (car_index),
    .cnn_block_valid(cnn_block_valid),
    .frame_pulse    (frame_pulse),    // 闁哄倹婢橀·鍐晬濮橆剚濮庨柛姘湰椤掔偤鎳樻径濠傛毐
/////////////////////////
    .pixel_xpos     (pixel_xpos),
    .pixel_ypos     (pixel_ypos),
    .rd_data        (rd_data),
    .display_vsync  (rd_vsync),
    .display_de     (rdata_req_d),
    .cnn_overlay_hit(cnn_overlay_hit),
    .hdmi_data_d    (hdmi_data_d),
    .roi_valid      (roi_valid),
    .roi_observed   (roi_observed),
    .roi_estimated  (roi_estimated),
    .roi_x0         (roi_x0),
    .roi_x1         (roi_x1),
    .roi_y0         (roi_y0),
    .roi_y1         (roi_y1),
    .roi_color      (roi_color)
);

wire [10:0] car_min_x = roi_x0[car_index*11 +: 11];
wire [10:0] car_max_x = roi_x1[car_index*11 +: 11];
wire [10:0] car_min_y = roi_y0[car_index*11 +: 11];
wire [10:0] car_max_y = roi_y1[car_index*11 +: 11];

wire [11:0] car_cx_sum = {1'b0, car_min_x} + {1'b0, car_max_x};
wire [11:0] car_cy_sum = {1'b0, car_min_y} + {1'b0, car_max_y};

assign car_cx = car_cx_sum[11:1];
assign car_cy = car_cy_sum[11:1];

goal_box_selector u_goal_box_selector (
    .roi_valid(roi_valid),
    .roi_block_valid(cnn_block_valid),
    .roi_color(roi_color),
    .roi_x0(roi_x0), .roi_x1(roi_x1),
    .roi_y0(roi_y0), .roi_y1(roi_y1),
    .goal_valid(goal_valid), .goal_index(goal_index),
    .goal_cx(goal_cx), .goal_cy(goal_cy),
    .goal_min_x(goal_min_x), .goal_min_y(goal_min_y),
    .goal_max_x(goal_max_x), .goal_max_y(goal_max_y)
);

genvar astar_box;
generate for (astar_box=0; astar_box<16; astar_box=astar_box+1) begin : astar_obstacle_boxes
    assign astar_obs_valid[astar_box] = roi_valid[astar_box] &&
        !(car_valid && car_index == astar_box) &&
        !(goal_valid && goal_index == astar_box);
end endgenerate

astar_path_overlay u_astar_path_overlay (
    .clk             (pixel_clk),
    .rst_n           (rst_n),
    .frame_pulse     (frame_pulse),
    .all_mode        (color_mode == 2'd3),
    .snapshot_pulse  (host_path_snapshot_pulse),
    .clear_pulse     (host_path_clear_pulse),
    .live_pulse      (host_path_live_pulse),
    .start_valid     (car_valid),
    .start_x         (car_cx),
    .start_y         (car_cy),
    .car_min_x       (car_min_x),
    .car_min_y       (car_min_y),
    .car_max_x       (car_max_x),
    .car_max_y       (car_max_y),
    .goal_valid      (goal_valid),
    .goal_x          (goal_cx),
    .goal_y          (goal_cy),
    .obstacle_valid  (astar_obs_valid),
    .obstacle_x0     (roi_x0),
    .obstacle_y0     (roi_y0),
    .obstacle_x1     (roi_x1),
    .obstacle_y1     (roi_y1),
    .pixel_x         (pixel_xpos == 0 ? 11'd0 : pixel_xpos - 1'b1),
    .pixel_y         (pixel_ypos == 0 ? 11'd0 : pixel_ypos - 1'b1),
    .path_valid      (path_valid),
    .path_hit        (path_hit),
    .planning_busy   (path_planning_busy),
    .path_mode       (path_mode)
);

/*path_planner u_path_planner (
    .clk(pixel_clk), .rst_n(rst_n), .frame_pulse(frame_pulse),
    .all_mode(color_mode == 2'd3),
    .start_valid(car_valid), .start_cx(car_cx), .start_cy(car_cy),
    .goal_valid(goal_valid), .goal_cx(goal_cx), .goal_cy(goal_cy),
    .obs1_valid(obs1_valid),
    .obs1_min_x(obs1_min_x), .obs1_min_y(obs1_min_y),
    .obs1_max_x(obs1_max_x), .obs1_max_y(obs1_max_y),
    .obs2_valid(obs2_valid),
    .obs2_min_x(obs2_min_x), .obs2_min_y(obs2_min_y),
    .obs2_max_x(obs2_max_x), .obs2_max_y(obs2_max_y),
    .stream_ready(stream_ready),
    .path_valid(path_valid), .path_update(path_update), .path_clear(path_clear),
    .stream_valid(stream_valid), .stream_x(stream_x), .stream_y(stream_y)
);*/

/*path_manager u_path_manager (
    .clk(pixel_clk), .rst_n(rst_n),
    .path_clear(path_clear),
    .stream_valid(stream_valid), .stream_x(stream_x), .stream_y(stream_y),
    .stream_ready(stream_ready),
    .draw_start(draw_start_p),
    .draw_x0(draw_x0_p), .draw_y0(draw_y0_p),
    .draw_x1(draw_x1_p), .draw_y1(draw_y1_p),
    .draw_busy(draw_busy_p),
    .clear_start(clear_start_p), .clear_busy(clear_busy_p)
);*/

/*line_drawer u_path_line_drawer (
    .clk(pixel_clk), .rst_n(rst_n),
    .start(draw_start_p),
    .x0(draw_x0_p), .y0(draw_y0_p),
    .x1(draw_x1_p), .y1(draw_y1_p),
    .busy(draw_busy_p),
    .clear(clear_start_p), .clear_done(clear_busy_p),
    .bmp_addr(path_bmp_waddr), .bmp_wdata(path_bmp_wdata), .bmp_wen(path_bmp_wen)
);*/

/*traj_bitmap u_path_bitmap (
    .clk(pixel_clk),
    .wen(path_bmp_wen), .waddr(path_bmp_waddr),
    .wdata(path_bmp_wdata), .raddr(path_bmp_raddr), .rdata(path_bmp_rdata)
);*/

/*path_display u_path_display (
    .pixel_xpos(pixel_xpos), .pixel_ypos(pixel_ypos),
    .bmp_raddr(path_bmp_raddr), .bmp_rdata(path_bmp_rdata),
    .path_hit(path_hit)
);*/

// ===== 闁圭ǹ顦甸弫顓炩槈閸喎顫嶆俊顖椻偓铏仴 =====
key_debounce u_key_debounce(
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .key_in         (key0),
    .key_short_pulse(key_short_pulse),
    .key_long_pulse (key_long_pulse)
);

// ===== KEY1閹稿鏁☉鍫熷濡€虫健 =====
key_debounce u_key1_debounce(
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .key_in         (key1),
    .key_short_pulse(key1_short_pulse),
    .key_long_pulse (key1_long_pulse)
);

assign traj_short_pulse = key_short_pulse | host_short_pulse;
assign traj_long_pulse  = key_long_pulse  | host_clear_pulse;

host_control_link #(
    .CLK_FREQ       (65_000_000),
    .UART_BPS       (115200)
) u_host_control_link (
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .uart_rxd       (uart_rxd),
    .uart_txd       (uart_txd),
    .traj_state     (traj_state),
    .time_sec       (time_sec),
    .color_mode     (color_mode),
    .car_valid      (car_valid),
    .goal_valid     (goal_valid),
    .path_valid     (path_valid),
    .planning_busy  (path_planning_busy),
    .path_mode      (path_mode),
    .short_pulse    (host_short_pulse),
    .clear_pulse    (host_clear_pulse),
    .path_snapshot_pulse (host_path_snapshot_pulse),
    .path_clear_pulse    (host_path_clear_pulse),
    .path_live_pulse     (host_path_live_pulse),
    .mode_stb       (host_mode_stb),
    .mode_value     (host_mode)
);

// ===== 閺夌偑鍔忛幎妤呭箳瑜嶉崺妤€螣閳ヨ櫕鍋� =====
traj_ctrl u_traj_ctrl(
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .key_short_pulse(traj_short_pulse),
    .key_long_pulse (traj_long_pulse),
    .recording      (recording),
    .clear_traj     (clear_traj),
    .time_sec       (time_sec),
    .traj_state     (traj_state)
);

// ===== 閺夌偑鍔忛幎妤冪不閿涘嫭鍊炴俊顖椻偓铏仴 =====
traj_manager u_traj_manager(
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .center_x       (center_x),
    .center_y       (center_y),
    .center_valid   (center_valid),
    .frame_pulse    (frame_pulse),
    .recording      (recording),
    .clear_traj     (clear_traj),
    .draw_start     (draw_start),
    .draw_x0        (draw_x0),
    .draw_y0        (draw_y0),
    .draw_x1        (draw_x1),
    .draw_y1        (draw_y1),
    .draw_busy      (draw_busy),
    .clear_start    (clear_start),
    .clear_busy     (clear_busy)
);

// ===== 闁烩晛顕崵搴ㄦ偨閼姐倕娈犳俊顖椻偓铏仴 =====
line_drawer u_line_drawer(
    .clk            (pixel_clk),
    .rst_n          (rst_n),
    .start          (draw_start),
    .x0             (draw_x0),
    .y0             (draw_y0),
    .x1             (draw_x1),
    .y1             (draw_y1),
    .busy           (draw_busy),
    .clear          (clear_start),
    .clear_done     (clear_busy),
    .bmp_addr       (bmp_waddr),
    .bmp_wdata      (bmp_wdata),
    .bmp_wen        (bmp_wen)
);

// ===== 閺夌偑鍔忛幎妤佹媴瀹ュ懏绂堥柣銏ｎ嚙缁旂āRAM =====
traj_bitmap u_traj_bitmap(
    .clk            (pixel_clk),
    //.rst_n          (rst_n),
    .waddr          (bmp_waddr),
    .wdata          (bmp_wdata),
    .wen            (bmp_wen),
    .raddr          (bmp_raddr),
    .rdata          (bmp_rdata)
);

// ===== 閺夌偑鍔忛幎妤呭及閸撗佷粵閺夊牊鎸搁崵顓炍熼垾铏仴 =====
traj_display u_traj_display(
    //.clk            (pixel_clk),
    //.rst_n          (rst_n),
    .pixel_xpos     (pixel_xpos),
    .pixel_ypos     (pixel_ypos),
    .bmp_raddr      (bmp_raddr),
    .bmp_rdata      (bmp_rdata),
    .traj_hit       (traj_hit)
);
// ===== OSD 閺傚洤鐡ч崣鐘插 =====
osd_text u_osd_text(
    .pixel_xpos (pixel_xpos),
    .pixel_ypos (pixel_ypos),
    .time_sec   (time_sec),
    .color_mode (color_mode),
    .osd_hit    (osd_hit)
);
endmodule
`default_nettype wire
