`timescale 1ns/1ps
module tb_traj_manager;

    reg clk, rst_n;
    reg recording, clear_traj;
    reg center_valid;
    reg [10:0] center_x, center_y;
    reg frame_pulse;
    wire draw_start;
    wire [7:0] draw_x0, draw_y0, draw_x1, draw_y1;
    reg draw_busy, clear_busy;
    wire clear_start;

    traj_manager dut (
        .clk(clk), .rst_n(rst_n),
        .recording(recording), .clear_traj(clear_traj),
        .center_valid(center_valid), .center_x(center_x), .center_y(center_y),
        .frame_pulse(frame_pulse),
        .draw_start(draw_start),
        .draw_x0(draw_x0), .draw_y0(draw_y0),
        .draw_x1(draw_x1), .draw_y1(draw_y1),
        .draw_busy(draw_busy), .clear_start(clear_start), .clear_busy(clear_busy)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        rst_n = 0; recording = 0; clear_traj = 0;
        center_valid = 0; center_x = 0; center_y = 0;
        frame_pulse = 0; draw_busy = 0; clear_busy = 0;
        #100 rst_n = 1;
        #100;

        recording = 1;

        // 帧1：物体 (100,100)，无上一点，不画
        center_valid = 1; center_x = 11'd100; center_y = 11'd100;
        frame_pulse = 1; #10; frame_pulse = 0; #20;

        // 帧2：物体 (200,200)，画 (25,25)->(50,50)
        center_x = 11'd200; center_y = 11'd200;
        frame_pulse = 1; #10; frame_pulse = 0; #20;

        // 帧3：框消失，断线
        center_valid = 0;
        frame_pulse = 1; #10; frame_pulse = 0; #20;

        // 帧4：框回来 (400,300)，断线后第一个点，不画
        center_valid = 1; center_x = 11'd400; center_y = 11'd300;
        frame_pulse = 1; #10; frame_pulse = 0; #20;

        // 帧5：物体 (500,400)，画 (100,75)->(125,100)
        center_x = 11'd500; center_y = 11'd400;
        frame_pulse = 1; #10; frame_pulse = 0; #20;

        // 长按清空
        clear_traj = 1; #10; clear_traj = 0;
        #50;

        $finish;
    end

    always @(posedge clk) begin
        if (draw_start)
            $display("t=%0t DRAW (%0d,%0d)->(%0d,%0d)",
                     $time, draw_x0, draw_y0, draw_x1, draw_y1);
        if (clear_start)
            $display("t=%0t CLEAR", $time);
    end

endmodule
