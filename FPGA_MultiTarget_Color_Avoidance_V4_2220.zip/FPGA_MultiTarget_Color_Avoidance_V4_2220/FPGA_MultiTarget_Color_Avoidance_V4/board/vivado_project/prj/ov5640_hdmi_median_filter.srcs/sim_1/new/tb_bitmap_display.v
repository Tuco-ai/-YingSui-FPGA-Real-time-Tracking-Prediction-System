`timescale 1ns/1ps
module tb_bitmap_display;

    reg clk;
    reg wen;
    reg [15:0] waddr;
    reg wdata;
    reg [10:0] px, py;

    wire [15:0] raddr;
    wire rdata, traj_hit;

    traj_bitmap bm (
        .clk(clk), .wen(wen), .waddr(waddr), .wdata(wdata),
        .raddr(raddr), .rdata(rdata)
    );

    traj_display disp (
        .pixel_xpos(px), .pixel_ypos(py),
        .bmp_raddr(raddr), .bmp_rdata(rdata), .traj_hit(traj_hit)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        wen = 0; waddr = 0; wdata = 0; px = 0; py = 0;
        #100;

        // 写位图点 (x=3, y=1) → 地址 = 1*256 + 3 = 259
        waddr = 16'd259; wdata = 1'b1; wen = 1'b1;
        #10; wen = 1'b0;
        #10;

        // 屏幕坐标 (13,5) → 位图 (13>>2=3, 5>>2=1) → 命中
        px = 11'd13; py = 11'd5;
        #10;
        $display("px=13 py=5  -> bmp(3,1) hit=%b  (期望1)", traj_hit);

        // 屏幕坐标 (20,10) → 位图 (5,2) → 没写 → 不命中
        px = 11'd20; py = 11'd10;
        #10;
        $display("px=20 py=10 -> bmp(5,2) hit=%b  (期望0)", traj_hit);

        // 屏幕坐标 (0,0) → 位图 (0,0) → 没写 → 不命中
        px = 11'd0; py = 11'd0;
        #10;
        $display("px=0  py=0  -> hit=%b  (期望0)", traj_hit);

        $finish;
    end

endmodule
