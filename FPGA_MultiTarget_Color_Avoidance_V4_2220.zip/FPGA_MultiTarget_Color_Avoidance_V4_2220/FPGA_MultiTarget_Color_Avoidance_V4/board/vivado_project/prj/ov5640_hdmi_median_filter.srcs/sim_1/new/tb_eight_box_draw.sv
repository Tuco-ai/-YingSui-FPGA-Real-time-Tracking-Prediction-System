`timescale 1ns/1ps
module tb_eight_box_draw;
    reg clk=0,rst_n=0,update=0;
    always #5 clk=~clk;
    reg [10:0] pixel_x=0,pixel_y=0;
    reg [1:0] color_mode=1;
    reg [15:0] observed=16'b0000000000000110,class_valid=16'b0000000000000110;
    reg [31:0] classes=0;
    reg [47:0] object_color=0;
    reg [175:0] x0=0,x1=0,y0=0,y1=0;
    wire [15:0] rgb_out;
    wire overlay_hit,center_valid;
    wire [10:0] center_x,center_y;
    cnn_class_overlay dut(.clk(clk),.rst_n(rst_n),.update(update),
      .pixel_x(pixel_x),.pixel_y(pixel_y),.rgb_in(16'hffff),
      .color_mode(color_mode),.observed(observed),.class_valid(class_valid),
      .classes(classes),.object_color(object_color),.x0(x0),.x1(x1),
      .y0(y0),.y1(y1),.rgb_out(rgb_out),.overlay_hit(overlay_hit),
      .center_x(center_x),.center_y(center_y),.center_valid(center_valid));
    initial begin
        x0[11+:11]=100;x1[11+:11]=150;y0[11+:11]=100;y1[11+:11]=150;
        x0[22+:11]=300;x1[22+:11]=350;y0[22+:11]=100;y1[22+:11]=150;
        object_color[3+:3]=2;object_color[6+:3]=2;
        classes[2+:2]=1;classes[4+:2]=1;
        repeat(3) @(negedge clk);rst_n=1;
        @(negedge clk);update=1;
        @(negedge clk);update=0;
        repeat(4) @(negedge clk);
        pixel_x=100;pixel_y=120;#1;
        if(!overlay_hit) $fatal(1,"first red box missing");
        pixel_x=300;pixel_y=120;#1;
        if(!overlay_hit) $fatal(1,"second red box missing");
        pixel_x=220;pixel_y=120;#1;
        if(overlay_hit) $fatal(1,"false box between red objects");
        // Pink has no separate key mode. In All mode, two pink blocks must
        // occupy independent lanes and both be visible.
        @(negedge clk);
        color_mode=3;observed=16'b1000000000010000;class_valid=16'b1000000000010000;
        x0[44+:11]=500;x1[44+:11]=550;y0[44+:11]=100;y1[44+:11]=150;
        x0[165+:11]=700;x1[165+:11]=750;y0[165+:11]=100;y1[165+:11]=150;
        object_color[12+:3]=3;object_color[45+:3]=3;
        classes[8+:2]=1;classes[30+:2]=1;
        update=1;
        @(negedge clk);update=0;
        repeat(4) @(negedge clk);
        pixel_x=500;pixel_y=120;#1;
        if(!overlay_hit) $fatal(1,"first pink box missing");
        pixel_x=700;pixel_y=120;#1;
        if(!overlay_hit) $fatal(1,"second pink box missing");
        // A wide car and a wide, shallow block must keep their own bounds.
        @(negedge clk);
        observed=16'h0003;class_valid=16'h0003;
        x0[0+:11]=800;x1[0+:11]=920;y0[0+:11]=300;y1[0+:11]=350;
        x0[11+:11]=100;x1[11+:11]=160;y0[11+:11]=100;y1[11+:11]=130;
        object_color[0+:3]=1;object_color[3+:3]=2;
        classes[0+:2]=0;classes[2+:2]=1;
        update=1;
        @(negedge clk);update=0;
        repeat(4) @(negedge clk);
        pixel_x=800;pixel_y=325;#1;
        if(!overlay_hit || !center_valid || center_x!=860 || center_y!=325)
            $fatal(1,"car rectangle or center incorrect");
        pixel_x=920;pixel_y=325;#1;
        if(!overlay_hit) $fatal(1,"car right edge missing");
        pixel_x=800;pixel_y=351;#1;
        if(overlay_hit) $fatal(1,"car box was enlarged beyond detected height");
        pixel_x=100;pixel_y=115;#1;
        if(!overlay_hit) $fatal(1,"block rectangle missing");
        pixel_x=100;pixel_y=131;#1;
        if(overlay_hit) $fatal(1,"block box was enlarged beyond detected height");
        // A green block in All mode becomes a destination label. The same
        // green block remains a normal block in Green mode.
        @(negedge clk);
        color_mode=3;observed=16'h0080;class_valid=16'h0080;
        x0[77+:11]=500;x1[77+:11]=550;
        y0[77+:11]=200;y1[77+:11]=250;
        object_color[21+:3]=4;classes[14+:2]=1;
        update=1;
        @(negedge clk);update=0;
        repeat(4) @(negedge clk);
        pixel_x=631;pixel_y=195;#1;
        if(!overlay_hit || rgb_out!==16'hffff)
            $fatal(1,"All-mode destination label is missing or too narrow");
        pixel_x=504;pixel_y=194;#1;
        if(rgb_out!==16'h0000)
            $fatal(1,"All-mode destination glyph is missing");
        pixel_x=632;pixel_y=195;#1;
        if(overlay_hit)
            $fatal(1,"All-mode destination label extends past its panel");
        @(negedge clk);
        color_mode=2;update=1;
        @(negedge clk);update=0;
        repeat(4) @(negedge clk);
        pixel_x=561;pixel_y=195;#1;
        if(overlay_hit)
            $fatal(1,"Green-mode block label incorrectly became destination");
        $display("PASS sixteen slots, rectangular boxes, and destination label gating");
        $finish;
    end
endmodule
