`timescale 1ns/1ps
module tb_video_pipeline_alignment;
    reg clk=0,rst_n=0;
    always #5 clk=~clk;
    wire video_hs,video_vs,video_de,data_req;
    wire [15:0] video_rgb;
    wire [10:0] pixel_xpos,pixel_ypos;
    reg [15:0] pixel_data_d1=0;
    reg osd_hit_d1=0;
    integer pixel_count=0,line_count=0,cycles=0;

    video_driver #(.H_SYNC(4),.H_BACK(4),.H_DISP(8),.H_FRONT(4),.H_TOTAL(20),
                   .V_SYNC(2),.V_BACK(2),.V_DISP(2),.V_FRONT(1),.V_TOTAL(7)) dut(
       .pixel_clk(clk),.sys_rst_n(rst_n),.video_hs(video_hs),.video_vs(video_vs),
       .video_de(video_de),.video_rgb(video_rgb),.data_req(data_req),
       .pixel_data(pixel_data_d1),.pixel_xpos(pixel_xpos),.pixel_ypos(pixel_ypos));

    always @(posedge clk) begin
        pixel_data_d1 <= {5'b0,pixel_xpos};
        osd_hit_d1 <= pixel_xpos==3;
    end
    always @(posedge clk) begin
        #1;
        if (rst_n) begin
            cycles=cycles+1;
            if (video_de) begin
                pixel_count=pixel_count+1;
                if (video_rgb !== pixel_count)
                    $fatal(1,"active pixel %0d contains %0d",pixel_count,video_rgb);
                if (osd_hit_d1 !== (pixel_count==3))
                    $fatal(1,"OSD shifted at active pixel %0d",pixel_count);
            end else if (pixel_count!=0) begin
                if (pixel_count!=8) $fatal(1,"line lost pixels: %0d",pixel_count);
                line_count=line_count+1;
                pixel_count=0;
            end
            if (line_count==2) begin
                $display("PASS two active lines, pixels 1..8 and OSD aligned");
                $finish;
            end
            if (cycles>300) $fatal(1,"video timing timeout");
        end
    end
    initial begin
        repeat(3) @(negedge clk);
        rst_n=1;
    end
endmodule
