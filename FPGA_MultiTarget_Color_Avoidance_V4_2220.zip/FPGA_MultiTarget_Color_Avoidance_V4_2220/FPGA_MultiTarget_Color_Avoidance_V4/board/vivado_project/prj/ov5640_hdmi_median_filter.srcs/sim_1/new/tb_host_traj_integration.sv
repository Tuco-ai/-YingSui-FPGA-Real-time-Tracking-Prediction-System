`timescale 1ns/1ps

module tb_host_traj_integration;
    localparam integer CLK_FREQ = 100_000_000;
    localparam integer UART_BPS = 1_000_000;
    localparam integer BIT_CYCLES = CLK_FREQ / UART_BPS;

    reg clk = 0;
    reg rst_n = 0;
    reg uart_rxd = 1;
    wire uart_txd;

    wire host_short_pulse;
    wire host_clear_pulse;
    wire host_mode_stb;
    wire [1:0] host_mode;
    wire recording;
    wire clear_traj;
    wire [5:0] time_sec;
    wire [1:0] traj_state;
    reg [1:0] color_mode = 0;
    reg clear_seen = 0;

    always #5 clk = ~clk;
    always @(posedge clk) begin
        if (!rst_n) color_mode <= 2'd0;
        else if (host_mode_stb) color_mode <= host_mode;
        if (clear_traj) clear_seen <= 1'b1;
    end

    host_control_link #(
        .CLK_FREQ(CLK_FREQ),
        .UART_BPS(UART_BPS)
    ) host (
        .clk(clk), .rst_n(rst_n),
        .uart_rxd(uart_rxd), .uart_txd(uart_txd),
        .traj_state(traj_state), .time_sec(time_sec),
        .color_mode(color_mode),
        .car_valid(1'b1), .goal_valid(1'b1),
        .path_valid(1'b1), .planning_busy(1'b0),
        .path_mode(2'd0),
        .short_pulse(host_short_pulse),
        .clear_pulse(host_clear_pulse),
        .mode_stb(host_mode_stb), .mode_value(host_mode)
    );

    traj_ctrl traj (
        .clk(clk), .rst_n(rst_n),
        .key_short_pulse(host_short_pulse),
        .key_long_pulse(host_clear_pulse),
        .recording(recording), .clear_traj(clear_traj),
        .time_sec(time_sec), .traj_state(traj_state)
    );

    function automatic [7:0] crc8_step(input [7:0] crc, input [7:0] data);
        integer i;
        reg [7:0] c;
        begin
            c = crc ^ data;
            for (i = 0; i < 8; i = i + 1)
                c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
            crc8_step = c;
        end
    endfunction

    task automatic send_byte(input [7:0] value);
        integer i;
        begin
            @(negedge clk);
            uart_rxd = 1'b0;
            repeat (BIT_CYCLES) @(posedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                uart_rxd = value[i];
                repeat (BIT_CYCLES) @(posedge clk);
            end
            uart_rxd = 1'b1;
            repeat (BIT_CYCLES) @(posedge clk);
        end
    endtask

    task automatic send_command(input [7:0] cmd, input [7:0] arg);
        reg [7:0] crc;
        begin
            crc = crc8_step(crc8_step(8'h00, cmd), arg);
            send_byte(8'hA5);
            send_byte(8'h5A);
            send_byte(cmd);
            send_byte(arg);
            send_byte(crc);
            repeat (4 * BIT_CYCLES) @(posedge clk);
        end
    endtask

    initial begin
        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (3) @(posedge clk);

        clear_seen = 1'b0;
        send_command(8'h01, 8'h00);
        if (traj_state !== 2'd1 || !recording || !clear_seen)
            $fatal(1, "host START did not enter recording");

        send_command(8'h02, 8'h00);
        if (traj_state !== 2'd2 || recording)
            $fatal(1, "host PAUSE failed");

        send_command(8'h03, 8'h00);
        if (traj_state !== 2'd1 || !recording)
            $fatal(1, "host RESUME failed");

        send_command(8'h05, 8'h03);
        if (color_mode !== 2'd3)
            $fatal(1, "host SET_MODE failed");

        clear_seen = 1'b0;
        send_command(8'h04, 8'h00);
        if (traj_state !== 2'd0 || recording || !clear_seen)
            $fatal(1, "host CLEAR failed");

        $display("PASS host UART to traj_ctrl integration");
        $finish;
    end
endmodule
