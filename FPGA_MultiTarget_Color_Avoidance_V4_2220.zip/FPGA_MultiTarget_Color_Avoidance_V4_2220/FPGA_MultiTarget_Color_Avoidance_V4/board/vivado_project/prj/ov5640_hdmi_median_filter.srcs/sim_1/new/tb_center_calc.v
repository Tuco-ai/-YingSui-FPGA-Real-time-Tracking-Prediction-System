`timescale 1ns/1ps
module tb_center_calc;

    reg [10:0] min_x, max_x, min_y, max_y;
    reg        valid;
    wire [10:0] center_x, center_y;
    wire        center_valid;

    center_calc dut (
        .min_x(min_x), .max_x(max_x),
        .min_y(min_y), .max_y(max_y),
        .valid(valid),
        .center_x(center_x), .center_y(center_y),
        .center_valid(center_valid)
    );

    initial begin
        valid = 0;
        min_x = 0; max_x = 0; min_y = 0; max_y = 0;
        #10;

        // 例1: 3~4 → 中点应为 4（四舍五入，3+4+1>>1 = 8>>1 = 4）
        valid = 1; min_x = 3; max_x = 4; min_y = 10; max_y = 20;
        #10;

        // 例2: 100~200 → 中点 150
        min_x = 100; max_x = 200; min_y = 50; max_y = 80;
        #10;

        // 例3: 偶数区间 0~100 → 中点 50
        min_x = 0; max_x = 100; min_y = 0; max_y = 60;
        #10;

        valid = 0;
        #10;
        $finish;
    end

    initial $monitor("t=%0t min=(%0d,%0d) max=(%0d,%0d) -> center=(%0d,%0d) valid=%b",
                     $time, min_x, min_y, max_x, max_y, center_x, center_y, center_valid);

endmodule