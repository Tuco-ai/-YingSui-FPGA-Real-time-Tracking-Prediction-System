`timescale 1ns/1ps
module tb_goal_box_selector_16;
    reg [15:0] roi_valid=16'h8003;
    reg [15:0] roi_block_valid=16'h0002;
    reg [47:0] roi_color=0;
    reg [175:0] roi_x0=0,roi_x1=0,roi_y0=0,roi_y1=0;
    wire goal_valid;
    wire [3:0] goal_index;
    wire [10:0] goal_cx,goal_cy,goal_min_x,goal_min_y,goal_max_x,goal_max_y;
    goal_box_selector dut(.*);
    initial begin
        roi_color[0+:3]=4; // Green CAR: not in the block mask.
        roi_color[3+:3]=1; // Blue BLOCK: wrong color.
        roi_color[45+:3]=4;
        roi_x0[165+:11]=100;roi_x1[165+:11]=140;
        roi_y0[165+:11]=200;roi_y1[165+:11]=240;
        #1;
        if (goal_valid)
            $fatal(1,"green CAR must not become the goal");
        roi_block_valid[15]=1;
        #1;
        if (!goal_valid || goal_index!=15 || goal_cx!=120 || goal_cy!=220)
            $fatal(1,"green BLOCK target in slot 15 was missed");
        roi_block_valid[15]=0;
        #1;
        if (goal_valid)
            $fatal(1,"unclassified green target must not remain valid");
        $display("PASS green BLOCK goal and diagonal center");
        $finish;
    end
endmodule
