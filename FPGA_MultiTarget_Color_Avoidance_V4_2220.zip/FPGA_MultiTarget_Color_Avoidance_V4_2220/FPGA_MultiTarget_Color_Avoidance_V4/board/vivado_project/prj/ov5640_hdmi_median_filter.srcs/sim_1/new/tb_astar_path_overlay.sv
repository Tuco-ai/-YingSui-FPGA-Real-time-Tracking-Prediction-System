`timescale 1ns/1ps
module tb_astar_path_overlay;
    logic clk=0;
    always #5 clk=~clk;
    logic rst_n=0, frame_pulse=0, all_mode=1;
    logic snapshot_pulse=0, clear_pulse=0, live_pulse=0;
    logic [1:0] path_mode;
    logic start_valid=1, goal_valid=1;
    logic [10:0] start_x,start_y,goal_x,goal_y;
    logic [10:0] car_min_x,car_min_y,car_max_x,car_max_y;
    logic [15:0] obstacle_valid=16'b0000000000000011;
    logic [175:0] obstacle_x0=0,obstacle_y0=0,obstacle_x1=0,obstacle_y1=0;
    logic [10:0] pixel_x=0,pixel_y=0;
    logic path_valid,path_hit,planning_busy;

    astar_path_overlay dut(.*);

    task automatic check_pixel(input integer x, y, expected_hit);
        logic previous_hit;
        begin
            previous_hit=path_hit;
            @(negedge clk); pixel_x=x;pixel_y=y;
            #1;
            if (path_hit !== previous_hit)
                $fatal(1,"path hit changed before the pixel clock");
            @(posedge clk);#1;
            if (path_hit !== (expected_hit != 0))
                $fatal(1,"pixel (%0d,%0d) hit=%0d expected=%0d",x,y,path_hit,expected_hit);
        end
    endtask

    task automatic commit_pending_route;
        integer guard;
        begin
            guard=0;
            while (dut.bank_swap_pending && guard<8) begin
                @(negedge clk);
                frame_pulse=1;
                @(negedge clk);
                frame_pulse=0;
                guard=guard+1;
            end
            if (dut.bank_swap_pending)
                $fatal(1,"route was not committed at a frame boundary");
        end
    endtask

    task automatic test_pending_replan;
        integer ticks;
        logic [11:0] expected_target;
        logic old_bank;
        begin
            @(negedge clk);goal_x=248;frame_pulse=1;
            @(negedge clk);frame_pulse=0;
            repeat(20) @(negedge clk);
            if (!planning_busy) $fatal(1,"planner did not start");
            goal_x=312;
            expected_target={goal_y[9:4],goal_x[9:4]};
            frame_pulse=1;
            @(negedge clk);frame_pulse=0;
            if (!dut.pending_replan) $fatal(1,"busy frame pulse was lost");
            ticks=0;
            while (dut.target !== expected_target && ticks<5000000) begin
                @(negedge clk);ticks=ticks+1;
                if (dut.bank_swap_pending)
                    commit_pending_route();
            end
            if (dut.target !== expected_target)
                $fatal(1,"pending goal was not loaded");
            ticks=0;
            while ((dut.active_target !== expected_target || planning_busy) && ticks<5000000) begin
                @(negedge clk);ticks=ticks+1;
                if (dut.bank_swap_pending) begin
                    old_bank=dut.active_bank;
                    repeat (20) @(negedge clk);
                    if (dut.active_bank !== old_bank)
                        $fatal(1,"active_bank changed inside a display frame");
                    frame_pulse=1;
                    @(negedge clk);
                    frame_pulse=0;
                    if (dut.active_bank === old_bank)
                        $fatal(1,"active_bank did not switch at frame boundary");
                end
            end
            if (!path_valid || dut.active_target !== expected_target)
                $fatal(1,"pending goal route was not shown");
            $display("PASS busy frame pulse replans to latest goal");
        end
    endtask

    task automatic test_path_line_width;
        logic [11:0] test_cell;
        begin
            test_cell=12'd20*64+12'd20;
            // Isolate one vertical arm in an otherwise unused cell.
            dut.connections[{dut.active_bank,test_cell}]=8'h04;
            check_pixel(12'd326,12'd328,0);
            check_pixel(12'd327,12'd328,1);
            check_pixel(12'd328,12'd328,1);
            check_pixel(12'd329,12'd328,1);
            check_pixel(12'd330,12'd328,0);
            // Isolate one horizontal arm.
            dut.connections[{dut.active_bank,test_cell}]=8'h01;
            check_pixel(12'd328,12'd326,0);
            check_pixel(12'd328,12'd327,1);
            check_pixel(12'd328,12'd328,1);
            check_pixel(12'd328,12'd329,1);
            check_pixel(12'd328,12'd330,0);
            dut.connections[{dut.active_bank,test_cell}]=8'h00;
            $display("PASS three-pixel horizontal and vertical route width");
        end
    endtask

    task automatic run_case(input integer case_no, hit_x, hit_y, block_x, block_y);
        integer ticks, count, i, step_delta;
        logic [11:0] route_points [0:3071];
        logic [7:0] from_arm, to_arm;
        begin
            if (case_no == 1) begin
                obstacle_valid=16'b1000000000000011;
                start_x=947;start_y=351;goal_x=181;goal_y=360;
                car_min_x=865;car_min_y=280;car_max_x=1023;car_max_y=420;
                obstacle_x0[0+:11]=435;obstacle_y0[0+:11]=220;obstacle_x1[0+:11]=550;obstacle_y1[0+:11]=320;
                obstacle_x0[11+:11]=450;obstacle_y0[11+:11]=365;obstacle_x1[11+:11]=565;obstacle_y1[11+:11]=470;
                obstacle_x0[165+:11]=650;obstacle_y0[165+:11]=310;obstacle_x1[165+:11]=700;obstacle_y1[165+:11]=370;
            end else begin
                obstacle_valid=16'b0000000000000011;
                start_x=940;start_y=340;goal_x=248;goal_y=365;
                car_min_x=875;car_min_y=275;car_max_x=1005;car_max_y=405;
                obstacle_x0[0+:11]=440;obstacle_y0[0+:11]=110;obstacle_x1[0+:11]=555;obstacle_y1[0+:11]=215;
                obstacle_x0[11+:11]=520;obstacle_y0[11+:11]=550;obstacle_x1[11+:11]=640;obstacle_y1[11+:11]=670;
            end
            // The live-mode button itself requests the first route.
            if (case_no != 1) begin
                @(negedge clk);frame_pulse=1;
                @(negedge clk);frame_pulse=0;
            end
            if (case_no == 2 && !path_valid)
                $fatal(1,"old route disappeared during replanning");
            ticks=0; count=0;
            while ((planning_busy || dut.active_source !== {start_y[9:4],start_x[9:4]} ||
                    dut.active_target !== {goal_y[9:4],goal_x[9:4]}) && ticks<5000000) begin
                @(negedge clk);ticks=ticks+1;
                if (dut.bank_swap_pending)
                    commit_pending_route();
                if (case_no == 2 && !path_valid)
                    $fatal(1,"old route vanished while a new route was building");
                if (dut.planner_valid) begin
                    route_points[count] = {dut.planner_row,dut.planner_col};
                    count=count+1;
                end
            end
            if (!path_valid) $fatal(1,"overlay case %0d timeout",case_no);
            if (case_no == 1 && !dut.obstacle_map[21*64+42])
                $fatal(1,"slot 15 obstacle was not copied into the A* map");
            if (count < 2) $fatal(1,"overlay case %0d path too short",case_no);
            for (i=0; i<count-1; i=i+1) begin
                if (dut.obstacle_map[route_points[i]])
                    $fatal(1,"overlay case %0d crossed obstacle at %0d",case_no,route_points[i]);
                step_delta = $signed({1'b0,route_points[i+1]}) -
                             $signed({1'b0,route_points[i]});
                from_arm=0;to_arm=0;
                case (step_delta)
                    -1:  begin from_arm=8'h01;to_arm=8'h02;end
                     1:  begin from_arm=8'h02;to_arm=8'h01;end
                    -64: begin from_arm=8'h04;to_arm=8'h08;end
                     64: begin from_arm=8'h08;to_arm=8'h04;end
                    -65: begin from_arm=8'h10;to_arm=8'h80;end
                    -63: begin from_arm=8'h20;to_arm=8'h40;end
                     63: begin from_arm=8'h40;to_arm=8'h20;end
                     65: begin from_arm=8'h80;to_arm=8'h10;end
                    default: $fatal(1,"overlay case %0d illegal segment",case_no);
                endcase
                if ((dut.connections[{dut.active_bank,route_points[i]}] & from_arm)==0 ||
                    (dut.connections[{dut.active_bank,route_points[i+1]}] & to_arm)==0)
                    $fatal(1,"overlay case %0d missing segment %0d",case_no,i);
            end
            if (case_no == 1 && (dut.margin_x != 71 || dut.margin_y != 71))
                $fatal(1,"case 1 car-box clearance calculation is wrong");
            if (case_no == 2 && (dut.margin_x != 66 || dut.margin_y != 66))
                $fatal(1,"case 2 car-box clearance calculation is wrong");
            check_pixel(start_x,start_y,1);
            check_pixel(goal_x,goal_y,1);
            check_pixel(hit_x,hit_y,1);
            check_pixel(block_x,block_y,0);
            $display("PASS overlay case %0d: ready in %0d cycles",case_no,ticks);
            if (case_no == 1) test_path_line_width();
        end
    endtask

    task automatic test_snapshot_and_mode_switch;
        integer ticks;
        logic [11:0] frozen_target;
        begin
            @(negedge clk); goal_x=400; frame_pulse=1;
            @(negedge clk); frame_pulse=0;
            repeat(20) @(negedge clk);
            if (!planning_busy) $fatal(1,"live job did not start before snapshot");
            snapshot_pulse=1;
            @(negedge clk); snapshot_pulse=0;
            frozen_target={goal_y[9:4],goal_x[9:4]};
            goal_x=500; // The queued snapshot must still use goal_x=400.
            ticks=0;
            while ((dut.active_target !== frozen_target || planning_busy) && ticks<5000000) begin
                @(negedge clk); ticks=ticks+1;
                if (dut.bank_swap_pending)
                    commit_pending_route();
            end
            if (!path_valid || path_mode !== 2'd1 || ticks==5000000)
                $fatal(1,"single-shot route was not committed");
            @(negedge clk); goal_x=500; start_valid=0; goal_valid=0;
            frame_pulse=1;
            @(negedge clk); frame_pulse=0;
            repeat(20) @(negedge clk);
            if (!path_valid || planning_busy || dut.active_target !== frozen_target)
                $fatal(1,"single-shot route changed after detection moved or vanished");
            snapshot_pulse=1;
            @(negedge clk); snapshot_pulse=0;
            @(negedge clk);
            if (path_valid || path_mode !== 2'd1)
                $fatal(1,"scan without CAR/goal did not clear the old route");
            start_valid=1; goal_valid=1; goal_x=400;
            snapshot_pulse=1;
            @(negedge clk); snapshot_pulse=0;
            ticks=0;
            while ((!path_valid || planning_busy) && ticks<5000000) begin
                @(negedge clk); ticks=ticks+1;
                if (dut.bank_swap_pending)
                    commit_pending_route();
            end
            if (!path_valid || ticks==5000000)
                $fatal(1,"snapshot did not regenerate after missing endpoints");
            clear_pulse=1;
            @(negedge clk); clear_pulse=0;
            @(negedge clk);
            if (path_valid || path_mode !== 2'd0)
                $fatal(1,"snapshot clear did not hide the route");
            start_valid=1; goal_valid=1;
            live_pulse=1;
            @(negedge clk); live_pulse=0;
            ticks=0;
            while ((!path_valid || planning_busy || path_mode !== 2'd2) && ticks<5000000) begin
                @(negedge clk); ticks=ticks+1;
                if (dut.bank_swap_pending)
                    commit_pending_route();
            end
            if (!path_valid || ticks==5000000)
                $fatal(1,"live mode did not resume planning");
            clear_pulse=1;
            @(negedge clk); clear_pulse=0;
            @(negedge clk);
            if (!path_valid || path_mode !== 2'd2)
                $fatal(1,"snapshot clear affected live route");
            all_mode=0;
            @(negedge clk);
            if (path_valid || path_mode !== 2'd0)
                $fatal(1,"leaving All did not clear path mode");
            all_mode=1; frame_pulse=1;
            @(negedge clk); frame_pulse=0;
            repeat(20) @(negedge clk);
            if (path_valid || planning_busy || path_mode !== 2'd0)
                $fatal(1,"re-entering All started a route without a host command");
            $display("PASS snapshot freeze, clear, live protection and All entry");
        end
    endtask

    initial begin
        repeat(4) @(negedge clk);rst_n=1;
        @(negedge clk); frame_pulse=1;
        @(negedge clk); frame_pulse=0;
        repeat(10) @(negedge clk);
        if (path_valid || planning_busy || path_mode !== 2'd0)
            $fatal(1,"All mode planned before a host command");
        live_pulse=1;
        @(negedge clk); live_pulse=0;
        run_case(1,947,351,512,288); // route begins at car; barrier stays clear
        run_case(2,940,340,576,608);
        test_pending_replan();
        test_snapshot_and_mode_switch();
        $finish;
    end
endmodule
