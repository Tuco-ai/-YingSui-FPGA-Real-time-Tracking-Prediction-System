`timescale 1ns/1ps
module tb_traj_ctrl;

    reg clk, rst_n;
    reg key_short_pulse, key_long_pulse;
    wire recording, clear_traj;

    traj_ctrl #(.MAX_CNT(32'd50)) dut (   // 计数值缩到 50，方便测"30秒自动停"
        .clk(clk), .rst_n(rst_n),
        .key_short_pulse(key_short_pulse),
        .key_long_pulse (key_long_pulse),
        .recording(recording), .clear_traj(clear_traj)
    );

    initial clk = 0;
    always #5 clk = ~clk;          // 10ns 周期

    task pulse_short; begin
        key_short_pulse = 1'b1; #10;
        key_short_pulse = 1'b0;
    end
    endtask

    task pulse_long; begin
        key_long_pulse = 1'b1; #10;
        key_long_pulse = 1'b0;
    end
    endtask

    initial begin
        rst_n = 0; key_short_pulse = 0; key_long_pulse = 0;
        #100 rst_n = 1;
        #100;

        pulse_short; #30;    // ① 短按 → 开始记录（recording=1，clear_traj 脉冲）
        pulse_short; #30;    // ② 短按 → 暂停（recording=0）
        pulse_short; #30;    // ③ 短按 → 继续（recording=1）
        pulse_long;  #30;    // ④ 长按 → 清空回 IDLE（clear_traj 脉冲）

        pulse_short; #600;   // ⑤ 短按重新开始，等 50 周期 → 自动 DONE
        pulse_short; #30;    // ⑥ DONE 下短按 → 无效，recording 仍 0
        pulse_long;  #50;    // ⑦ 长按 → 清空回 IDLE

        $finish;
    end

    initial $monitor("t=%0t rec=%b clear=%b", $time, recording, clear_traj);

endmodule