`timescale 1ns/1ps
module tb_eight_color_tracker;
    reg clk=0, rst_n=0, frame_vsync=0;
    always #5 clk=~clk;
    wire [15:0] roi_valid,roi_observed,roi_estimated;
    wire [175:0] roi_x0,roi_x1,roi_y0,roi_y1;
    wire [47:0] roi_color;
    wire [15:0] roi_frame_id,hdmi_data;
    wire [10:0] center_x,center_y;
    wire center_valid,frame_pulse;
    integer i,seen_red,seen_pink;

    all_color_tracker dut(
        .cam_clk(clk),.pixel_clk(clk),.rst_n(rst_n),
        .frame_vsync(frame_vsync),.frame_href(1'b0),.frame_de(1'b0),
        .frame_rgb(16'd0),.pixel_xpos(11'd0),.pixel_ypos(11'd0),
        .rd_data(16'd0),.hdmi_data(hdmi_data),
        .center_x(center_x),.center_y(center_y),.center_valid(center_valid),
        .frame_pulse(frame_pulse),.roi_valid(roi_valid),
        .roi_observed(roi_observed),.roi_estimated(roi_estimated),
        .roi_frame_id(roi_frame_id),.roi_x0(roi_x0),.roi_x1(roi_x1),
        .roi_y0(roi_y0),.roi_y1(roi_y1),.roi_color(roi_color)
    );

    initial begin
        repeat(5) @(negedge clk);
        rst_n=1;
        repeat(6) @(negedge clk);
        // Inject sixteen components; all must survive selection and transfer.
        dut.cv=32'h0000ffff;
        for(i=0;i<16;i=i+1)begin
            dut.cc[i]=(i==0)?1:((i==1||i==2)?2:((i==3)?4:3));
            dut.ca[i]=(i==0)?20'd20000:(19000-i*1000);
            dut.cx0[i]=i*60;
            dut.cx1[i]=i*60+39;
            dut.cy0[i]=100;
            dut.cy1[i]=149;
        end
        // This exceeds the old maximum-area threshold and must remain valid.
        dut.ca[3]=20'd400000;
        dut.cx0[3]=0;dut.cx1[3]=799;
        dut.cy0[3]=0;dut.cy1[3]=599;
        repeat(8) @(negedge clk);
        frame_vsync=1;
        @(negedge clk);frame_vsync=0;
        repeat(140) @(negedge clk);
        if(roi_valid!==16'hffff) $fatal(1,"expected sixteen boxes, got %h",roi_valid);
        if(roi_color[2:0]!==3'd1) $fatal(1,"slot zero is not blue car");
        seen_red=0;seen_pink=0;
        for(i=0;i<16;i=i+1)begin
            if(roi_color[i*3+:3]==3'd2) seen_red=seen_red+1;
            if(roi_color[i*3+:3]==3'd3) seen_pink=seen_pink+1;
        end
        if(seen_red!=2) $fatal(1,"expected two red boxes, got %0d",seen_red);
        if(seen_pink<2) $fatal(1,"expected multiple pink boxes, got %0d",seen_pink);
        if(roi_color[5:3]!==3'd4) $fatal(1,"large green box was filtered");
        $display("PASS sixteen boxes, two red boxes, multiple pink boxes, large green, blue car slot");
        $finish;
    end
endmodule
