`timescale 1ns/1ps
module tb_cnn_car_pick;
 reg [15:0] roi_valid=0,roi_observed=0,class_valid=0;
 reg [31:0] classes=32'hffffffff;
 wire car_valid;
 wire [3:0] car_index;
 cnn_car_pick dut(.*);
 initial begin
  roi_valid[0]=1;roi_observed[0]=1;class_valid[0]=1;
  classes[0+:2]=2'd1;#1;
  if(car_valid) $fatal(1,"blue slot classified BLOCK became start");
  roi_valid[7]=1;roi_observed[7]=1;class_valid[7]=1;
  classes[14+:2]=2'd0;#1;
  if(!car_valid||car_index!=7) $fatal(1,"CNN CAR in slot 7 was missed");
  classes[0+:2]=2'd0;#1;
  if(!car_valid||car_index!=0) $fatal(1,"slot 0 CAR priority failed");
  roi_observed[0]=0;#1;
  if(!car_valid||car_index!=7) $fatal(1,"unobserved car was chosen");
  roi_observed[7]=0;#1;
  if(car_valid) $fatal(1,"stale CAR was chosen");
  $display("PASS CNN CAR selection and slot priority");
  $finish;
 end
endmodule
