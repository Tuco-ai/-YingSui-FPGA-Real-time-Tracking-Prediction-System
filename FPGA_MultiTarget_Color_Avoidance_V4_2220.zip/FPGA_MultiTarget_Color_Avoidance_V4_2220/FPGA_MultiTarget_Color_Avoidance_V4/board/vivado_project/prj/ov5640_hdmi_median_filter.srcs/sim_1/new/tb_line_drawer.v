`timescale 1ns/1ps
module tb_line_drawer;

    reg clk, rst_n;
    reg start, clear;
    reg [7:0] x0, y0, x1, y1;
    wire busy, done, clear_done;
    wire [15:0] bmp_addr;
    wire bmp_wdata, bmp_wen;

    line_drawer dut (
        .clk(clk), .rst_n(rst_n),
        .start(start), .clear(clear),
        .x0(x0), .y0(y0), .x1(x1), .y1(y1),
        .busy(busy), .done(done), .clear_done(clear_done),
        .bmp_addr(bmp_addr), .bmp_wdata(bmp_wdata), .bmp_wen(bmp_wen)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        rst_n = 0; start = 0; clear = 0;
        x0 = 0; y0 = 0; x1 = 0; y1 = 0;
        #100 rst_n = 1;
        #100;

        // 画一条 21 个点的横线 (0,0)->(20,0)，箭头应在第 8 和第 16 个点
        x0 = 8'd0; y0 = 8'd0; x1 = 8'd20; y1 = 8'd0;
        start = 1; #10; start = 0;
        wait (done == 1);
        #50;

        $finish;
    end

    // 只打印 data=1 的写点（画线和箭头）
    always @(posedge clk) begin
        if (bmp_wen && bmp_wdata)
            $display("WRITE x=%0d y=%0d addr=%0d",
                     bmp_addr[7:0], bmp_addr[15:8], bmp_addr);
    end

    always @(posedge clk) begin
        if (done) $display("===== DRAW DONE =====");
    end

endmodule