`timescale 1ns/1ps

module tb_host_control_link;
    localparam integer CLK_FREQ = 100_000_000;
    localparam integer UART_BPS = 1_000_000;
    localparam integer CLK_PERIOD = 10;
    localparam integer BAUD_PERIOD = CLK_FREQ / UART_BPS * CLK_PERIOD;

    reg clk = 0;
    reg rst_n = 0;
    reg uart_rxd = 1;
    wire uart_txd;

    reg [1:0] traj_state = 0;
    reg [5:0] time_sec = 0;
    reg [1:0] color_mode = 0;
    reg car_valid = 0;
    reg goal_valid = 0;
    reg path_valid = 0;
    reg planning_busy = 0;
    reg [1:0] path_mode = 0;
    wire path_snapshot_pulse, path_clear_pulse, path_live_pulse;
    reg snapshot_seen=0, path_clear_seen=0, live_seen=0;
    wire short_pulse;
    wire clear_pulse;
    wire mode_stb;
    wire [1:0] mode_value;
    reg short_seen = 0;
    reg clear_seen = 0;
    reg mode_seen = 0;
    reg [1:0] mode_seen_value = 0;

    always #(CLK_PERIOD/2) clk = ~clk;
    always @(posedge clk) begin
        if (short_pulse) short_seen <= 1'b1;
        if (clear_pulse) clear_seen <= 1'b1;
        if (path_snapshot_pulse) snapshot_seen <= 1'b1;
        if (path_clear_pulse) path_clear_seen <= 1'b1;
        if (path_live_pulse) live_seen <= 1'b1;
        if (mode_stb) begin
            mode_seen <= 1'b1;
            mode_seen_value <= mode_value;
        end
    end

    host_control_link #(
        .CLK_FREQ(CLK_FREQ),
        .UART_BPS(UART_BPS)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .uart_rxd(uart_rxd),
        .uart_txd(uart_txd),
        .traj_state(traj_state),
        .time_sec(time_sec),
        .color_mode(color_mode),
        .car_valid(car_valid),
        .goal_valid(goal_valid),
        .path_valid(path_valid),
        .planning_busy(planning_busy),
        .path_mode(path_mode),
        .path_snapshot_pulse(path_snapshot_pulse),
        .path_clear_pulse(path_clear_pulse),
        .path_live_pulse(path_live_pulse),
        .short_pulse(short_pulse),
        .clear_pulse(clear_pulse),
        .mode_stb(mode_stb),
        .mode_value(mode_value)
    );

    function automatic [7:0] crc8_step(input [7:0] crc, input [7:0] data);
        integer i;
        reg [7:0] c;
        begin
            c = crc ^ data;
            for (i = 0; i < 8; i = i + 1)
                c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
            crc8_step = c;
        end
    endfunction

    function automatic [7:0] crc8_pair(input [7:0] a, input [7:0] b);
        begin
            crc8_pair = crc8_step(crc8_step(8'h00, a), b);
        end
    endfunction

    task automatic send_byte(input [7:0] value);
        integer i;
        begin
            @(negedge clk);
            uart_rxd = 1'b0;
            repeat (CLK_FREQ / UART_BPS) @(posedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                uart_rxd = value[i];
                repeat (CLK_FREQ / UART_BPS) @(posedge clk);
            end
            uart_rxd = 1'b1;
            repeat (CLK_FREQ / UART_BPS) @(posedge clk);
        end
    endtask

    task automatic send_command(input [7:0] cmd, input [7:0] arg);
        begin
            send_byte(8'hA5);
            send_byte(8'h5A);
            send_byte(cmd);
            send_byte(arg);
            send_byte(crc8_pair(cmd, arg));
        end
    endtask

    task automatic receive_byte(output [7:0] value);
        integer i;
        begin
            wait (uart_txd == 1'b0);
            repeat (CLK_FREQ / UART_BPS + CLK_FREQ / UART_BPS / 2)
                @(posedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                value[i] = uart_txd;
                repeat (CLK_FREQ / UART_BPS) @(posedge clk);
            end
            repeat (CLK_FREQ / UART_BPS) @(posedge clk);
            if (uart_txd !== 1'b1)
                $display("WARN: UART stop sampled low");
        end
    endtask

    task automatic expect_ack(input [7:0] cmd, input [7:0] result);
        reg [7:0] b0, b1, b2, b3, b4;
        begin
            receive_byte(b0);
            receive_byte(b1);
            receive_byte(b2);
            receive_byte(b3);
            receive_byte(b4);
            if ({b0, b1, b2, b3, b4} !==
                {8'hA5, 8'h5A, cmd | 8'h80, result,
                 crc8_pair(cmd | 8'h80, result)})
                $fatal(1, "unexpected ACK for command %02h", cmd);
        end
    endtask

    task automatic expect_status(input [1:0] expected_path_mode);
        reg [7:0] b0, b1, b2, b3, b4, b5, b6, b7, b8;
        reg [7:0] crc;
        begin
            receive_byte(b0);
            receive_byte(b1);
            receive_byte(b2);
            receive_byte(b3);
            receive_byte(b4);
            receive_byte(b5);
            receive_byte(b6);
            receive_byte(b7);
            receive_byte(b8);
            crc = crc8_step(8'h00, b3);
            crc = crc8_step(crc, b4);
            crc = crc8_step(crc, b5);
            crc = crc8_step(crc, b6);
            crc = crc8_step(crc, b7);
            if ({b0, b1, b2, b3, b4, b5, b6, b7} !==
                {8'hA5, 8'h5A, 8'h90, 8'h00, 8'h03, 8'h07, 8'h07, {6'd0,expected_path_mode}} ||
                b8 !== crc)
                $fatal(1, "unexpected status frame");
        end
    endtask

    initial begin
        repeat (5) @(posedge clk);
        rst_n = 1;
        repeat (2) @(posedge clk);

        short_seen = 0;
        send_command(8'h01, 8'h00);
        if (!short_seen) $fatal(1, "START pulse missing");
        expect_ack(8'h01, 8'h00);
        traj_state = 2'd1;

        short_seen = 0;
        send_command(8'h02, 8'h00);
        if (!short_seen) $fatal(1, "PAUSE pulse missing");
        expect_ack(8'h02, 8'h00);
        traj_state = 2'd2;

        short_seen = 0;
        send_command(8'h03, 8'h00);
        if (!short_seen) $fatal(1, "RESUME pulse missing");
        expect_ack(8'h03, 8'h00);
        traj_state = 2'd1;

        mode_seen = 0;
        send_command(8'h05, 8'h03);
        if (!mode_seen || mode_seen_value !== 2'd3)
            $fatal(1, "SET_MODE pulse/value missing");
        expect_ack(8'h05, 8'h00);
        color_mode = 2'd3;

        clear_seen = 0;
        send_command(8'h04, 8'h00);
        if (!clear_seen) $fatal(1, "CLEAR pulse missing");
        expect_ack(8'h04, 8'h00);
        traj_state = 2'd0;

        time_sec = 6'd7;
        car_valid = 1'b1;
        goal_valid = 1'b1;
        path_valid = 1'b1;
        snapshot_seen=0;
        send_command(8'h20, 8'h00);
        if (!snapshot_seen) $fatal(1,"PATH_SNAPSHOT pulse missing");
        expect_ack(8'h20, 8'h00);
        path_mode=2'd1;
        send_command(8'h10, 8'h00);
        expect_status(2'd1);

        path_clear_seen=0;
        send_command(8'h21, 8'h00);
        if (!path_clear_seen) $fatal(1,"PATH_CLEAR pulse missing");
        expect_ack(8'h21, 8'h00);
        path_mode=2'd0;

        live_seen=0;
        send_command(8'h22, 8'h00);
        if (!live_seen) $fatal(1,"PATH_LIVE pulse missing");
        expect_ack(8'h22, 8'h00);
        path_mode=2'd2;

        path_clear_seen=0;
        send_command(8'h21, 8'h00);
        if (path_clear_seen) $fatal(1,"PATH_CLEAR affected live mode");
        expect_ack(8'h21, 8'h01);
        send_command(8'h10, 8'h00);
        expect_status(2'd2);

        goal_valid=0;
        snapshot_seen=0;
        send_command(8'h20, 8'h00);
        if (!snapshot_seen) $fatal(1,"missing goal snapshot was not forwarded");
        expect_ack(8'h20, 8'h00);

        $display("PASS host command mapping, ACK and status protocol");
        $finish;
    end
endmodule
