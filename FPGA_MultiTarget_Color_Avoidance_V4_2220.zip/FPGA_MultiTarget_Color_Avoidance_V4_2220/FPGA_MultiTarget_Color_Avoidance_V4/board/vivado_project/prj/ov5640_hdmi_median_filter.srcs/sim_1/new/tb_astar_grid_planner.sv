`timescale 1ns/1ps
module tb_astar_grid_planner;
    logic clk = 0;
    always #5 clk = ~clk;
    logic rst_n = 0, start = 0, path_ready = 1;
    logic [11:0] start_idx = 0, goal_idx = 0;
    logic [3071:0] obstacle_map = 0;
    logic busy, done, found, path_valid, path_last;
    logic [22:0] path_cost;
    logic [11:0] path_length;
    logic [5:0] path_row, path_col;

    astar_grid_planner dut (
        .clk(clk), .rst_n(rst_n), .start(start),
        .start_idx(start_idx), .goal_idx(goal_idx), .obstacle_map(obstacle_map),
        .busy(busy), .done(done), .found(found), .path_cost(path_cost),
        .path_length(path_length), .path_valid(path_valid), .path_ready(path_ready),
        .path_row(path_row), .path_col(path_col), .path_last(path_last)
    );

    // Mark every cell touched by a photo-estimated box plus a pixel margin.
    task automatic mark_box(input integer l, t, r, b, margin_x, margin_y);
        integer row, col, x0, y0, x1, y1;
        begin
            x0 = l - margin_x; if (x0 < 0) x0 = 0;
            y0 = t - margin_y; if (y0 < 0) y0 = 0;
            x1 = r + margin_x; if (x1 > 1023) x1 = 1023;
            y1 = b + margin_y; if (y1 > 767) y1 = 767;
            for (row = y0/16; row <= y1/16; row = row+1)
                for (col = x0/16; col <= x1/16; col = col+1)
                    obstacle_map[row*64+col] = 1'b1;
        end
    endtask

    task automatic run_no_path;
        integer row, ticks;
        begin
            obstacle_map = 0;
            for (row = 0; row < 48; row = row + 1)
                obstacle_map[row*64+32] = 1'b1;
            start_idx = 20*64+58;
            goal_idx = 22*64+10;
            @(negedge clk); start = 1;
            @(negedge clk); start = 0;
            ticks = 0;
            while (!done && ticks < 10000000) begin
                @(negedge clk);
                ticks = ticks + 1;
                if (path_valid) $fatal(1,"no-path case emitted a path point");
            end
            if (ticks >= 10000000 || found || path_length != 0)
                $fatal(1,"no-path case failed");
            $display("PASS no-path case: %0d cycles",ticks);
            @(negedge clk);
        end
    endtask

    task automatic run_case(input integer case_no, expected_cost);
        integer ticks, count, total, prev_r, prev_c, dr, dc;
        integer curr_r, curr_c;
        logic last_seen;
        begin
            obstacle_map = 0;
            if (case_no == 1) begin
                // video_frame_14s.png: pink/red block middle; route around.
                start_idx = 21*64+59; goal_idx = 22*64+11;
                mark_box(435,220,550,320,71,71);
                mark_box(450,365,565,470,71,71);
            end else if (case_no == 2) begin
                // Second photo: pink above, red below; straight corridor.
                start_idx = 21*64+58; goal_idx = 22*64+15;
                mark_box(440,110,555,215,66,66);
                mark_box(520,550,640,670,66,66);
            end else begin
                // Highest-index row and column exercise the 12-bit path index.
                start_idx = 47*64+63; goal_idx = 47*64+62;
            end
            @(negedge clk); start = 1;
            @(negedge clk); start = 0;
            ticks = 0; count = 0; total = 0; last_seen = 0;
            prev_r = -1; prev_c = -1;
            while (!done && ticks < 10000000) begin
                @(negedge clk);
                ticks = ticks + 1;
                if (path_valid) begin
                    curr_r = path_row; curr_c = path_col;
                    if (obstacle_map[curr_r*64+curr_c])
                        $fatal(1,"case %0d path enters obstacle (%0d,%0d)",case_no,curr_r,curr_c);
                    if (count == 0 && curr_r*64+curr_c != start_idx)
                        $fatal(1,"case %0d does not start at car",case_no);
                    if (count > 0) begin
                        dr = (curr_r > prev_r) ? curr_r-prev_r : prev_r-curr_r;
                        dc = (curr_c > prev_c) ? curr_c-prev_c : prev_c-curr_c;
                        if (dr > 1 || dc > 1 || (dr == 0 && dc == 0))
                            $fatal(1,"case %0d illegal step",case_no);
                        if (dr == 1 && dc == 1) begin
                            if (obstacle_map[curr_r*64+prev_c] ||
                                obstacle_map[prev_r*64+curr_c])
                                $fatal(1,"case %0d cuts obstacle corner",case_no);
                            total = total + 1414;
                        end else total = total + 1000;
                    end
                    prev_r = curr_r; prev_c = curr_c;
                    count = count + 1;
                    if (path_last) begin
                        if (curr_r*64+curr_c != goal_idx)
                            $fatal(1,"case %0d last point is not goal",case_no);
                        last_seen = 1;
                    end
                end
            end
            if (ticks >= 10000000) $fatal(1,"case %0d timeout",case_no);
            if (!found || !last_seen || count != path_length ||
                total != path_cost || total != expected_cost)
                $fatal(1,"case %0d mismatch found=%0d count=%0d len=%0d total=%0d rtl=%0d expected=%0d",
                       case_no,found,count,path_length,total,path_cost,expected_cost);
            $display("PASS case %0d: %0d cells, cost %0d, %0d cycles",case_no,count,total,ticks);
            @(negedge clk);
        end
    endtask

    initial begin
        repeat (4) @(negedge clk);
        rst_n = 1;
        run_case(1, 58936); // Independent Dijkstra reference, 16-pixel map.
        run_case(2, 43414);
        run_case(3, 1000);
        run_no_path();
        $display("PASS all cases");
        $finish;
    end
endmodule
