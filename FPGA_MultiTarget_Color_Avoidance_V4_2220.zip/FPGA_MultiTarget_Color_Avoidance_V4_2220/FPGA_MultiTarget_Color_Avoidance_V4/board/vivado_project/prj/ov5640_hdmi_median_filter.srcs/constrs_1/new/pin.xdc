create_clock -period 20.000 -name sys_clk [get_ports sys_clk]
# R4 = IO_L13P_T2_MRCC_34. Use dedicated sys_clk routing.
set_property PACKAGE_PIN R4 [get_ports sys_clk]
set_property IOSTANDARD LVCMOS15 [get_ports sys_clk]
set_property IOSTANDARD LVCMOS15 [get_ports sys_rst_n]
set_property PACKAGE_PIN U7 [get_ports sys_rst_n]

#锟斤拷锟斤拷头锟接口碉拷时锟斤拷
create_clock -period 20.000 -name cmos_pclk [get_ports cam_pclk]
# Camera non-clock pin: override is applied post-synthesis in camera_route.tcl
set_property -dict {PACKAGE_PIN U18 IOSTANDARD LVCMOS33} [get_ports cam_pclk]
set_property -dict {PACKAGE_PIN N17 IOSTANDARD LVCMOS33} [get_ports cam_rst_n]
set_property -dict {PACKAGE_PIN AB18 IOSTANDARD LVCMOS33} [get_ports cam_pwdn]
set_property -dict {PACKAGE_PIN P17 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[0]}]
set_property -dict {PACKAGE_PIN P15 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[1]}]
set_property -dict {PACKAGE_PIN R16 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[2]}]
set_property -dict {PACKAGE_PIN R17 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[3]}]
set_property -dict {PACKAGE_PIN P16 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[4]}]
set_property -dict {PACKAGE_PIN V17 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[5]}]
set_property -dict {PACKAGE_PIN W17 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[6]}]
set_property -dict {PACKAGE_PIN U17 IOSTANDARD LVCMOS33 IOB TRUE} [get_ports {cam_data[7]}]
set_property -dict {PACKAGE_PIN P14 IOSTANDARD LVCMOS33} [get_ports cam_vsync]
set_property -dict {PACKAGE_PIN N14 IOSTANDARD LVCMOS33} [get_ports cam_href]
set_property -dict {PACKAGE_PIN N13 IOSTANDARD LVCMOS33} [get_ports cam_scl]
set_property -dict {PACKAGE_PIN R14 IOSTANDARD LVCMOS33} [get_ports cam_sda]

set_property IOSTANDARD DIFF_SSTL15 [get_ports {ddr3_ck_n[0]}]

set_property PACKAGE_PIN H20 [get_ports {tmds_data_p[2]}]
set_property PACKAGE_PIN K21 [get_ports {tmds_data_p[1]}]
set_property PACKAGE_PIN J22 [get_ports {tmds_data_p[0]}]
set_property PACKAGE_PIN J20 [get_ports tmds_clk_p]
# 杞ㄨ抗鎺у埗鎸夐敭 KEY0
set_property -dict {PACKAGE_PIN T4 IOSTANDARD LVCMOS15} [get_ports key0]
# 颜色切换按键 KEY1
set_property -dict {PACKAGE_PIN T3 IOSTANDARD LVCMOS15} [get_ports key1]
set_property PULLUP TRUE [get_ports key1]
# ================= 异步时钟组声明（解决跨时钟域时序违例） =================
# 三个互不同步的时钟域，声明为异步，工具不再分析它们之间的时序：
#   组1：cmos_pclk   （摄像头 25MHz，独立）
#   组2：clk_pll_i   （DDR3 MIG 的 ui_clk 100MHz）
#   组3：sys_clk 及其 MMCM 派生时钟（50/200/50/325/65MHz，彼此同步）
set_clock_groups -asynchronous \
    -group [get_clocks cmos_pclk] \
    -group [get_clocks clk_pll_i] \
    -group [get_clocks {sys_clk clk_out1_clk_wiz_0 clk_out2_clk_wiz_0 clk_out3_clk_wiz_0 clk_out4_clk_wiz_0}]
# I2C divider: 50MHz/(50MHz/250kHz/4) = 1MHz.
create_generated_clock -name camera_i2c_clk -source [get_pins u_ov5640_dri/u_i2c_dr/dri_clk_reg/C] -divide_by 50 [get_pins u_ov5640_dri/u_i2c_dr/dri_clk_reg/Q]

# Both board keys are active low; retain a defined idle level.
set_property PULLUP TRUE [get_ports key0]
# cmos_pclk is constrained at 50 MHz; actual PCLK and external delays require board measurements.

# USB UART CH340C: PC TXD -> FPGA RXD(E14), FPGA TXD(D17) -> CH340C
set_property -dict { PACKAGE_PIN E14 IOSTANDARD LVCMOS33 PULLUP TRUE } [get_ports uart_rxd]
set_property -dict { PACKAGE_PIN D17 IOSTANDARD LVCMOS33 } [get_ports uart_txd]
