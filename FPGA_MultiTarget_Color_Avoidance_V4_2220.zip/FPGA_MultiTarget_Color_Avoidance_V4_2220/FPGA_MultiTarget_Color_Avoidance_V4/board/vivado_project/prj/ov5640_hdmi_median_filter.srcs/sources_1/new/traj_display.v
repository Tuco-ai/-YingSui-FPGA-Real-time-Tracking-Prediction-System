module traj_display (
    input  wire [10:0] pixel_xpos,   // 屏幕 x 0~1023
    input  wire [10:0] pixel_ypos,   // 屏幕 y 0~767

    output wire [19:0] bmp_raddr,    // 位图读地址
    input  wire        bmp_rdata,    // 位图读数据
    output wire        traj_hit      // 1 = 当前像素是轨迹
);
    assign bmp_raddr = { pixel_ypos[9:0], pixel_xpos[9:0] };  // 1:1 映射，不再缩放
    assign traj_hit  = bmp_rdata;
endmodule