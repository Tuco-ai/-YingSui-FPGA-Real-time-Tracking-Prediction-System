// 64x48 A* planner on 16-pixel cells. One synchronous read port per table lets Vivado use block RAM.
// The extra FSM cycles do not affect the path or the stream handshake.
`timescale 1ns/1ps
module astar_grid_planner (
    input  logic         clk,
    input  logic         rst_n,
    input  logic         start,
    input  logic [11:0]   start_idx,
    input  logic [11:0]   goal_idx,
    input  logic [3071:0] obstacle_map,
    output logic         busy,
    output logic         done,
    output logic         found,
    output logic [22:0]  path_cost,
    output logic [11:0]   path_length,
    output logic         path_valid,
    input  logic         path_ready,
    output logic [5:0]   path_row,
    output logic [5:0]   path_col,
    output logic         path_last
);
    localparam logic [22:0] INF = 23'h7fffff;
    localparam logic [23:0] INF_F = 24'hffffff;
    localparam logic [4:0]
        ST_IDLE=0, ST_INIT=1, ST_SEED=2, ST_SCAN_BEGIN=3,
        ST_SCAN_READ=4, ST_SCAN_EVAL=5, ST_SELECT=6,
        ST_BEST_READ=7, ST_BEST_EVAL=8,
        ST_NEIGHBOR_READ=9, ST_NEIGHBOR_EVAL=10,
        ST_RETRACE_READ=11, ST_RETRACE_EVAL=12,
        ST_OUTPUT_PREFETCH=13, ST_OUTPUT=14, ST_DONE=15;

    logic [4:0] state;
    logic [3071:0] blocked, open_set, closed_set;
    (* ram_style = "block" *) logic [22:0] g_cost [0:3071];
    (* ram_style = "block" *) logic [11:0] parent [0:3071];
    (* ram_style = "block" *) logic [11:0] reverse_path [0:3071];
    logic [22:0] g_q, current_g, candidate_g;
    logic [11:0] parent_q, path_q;
    logic [11:0] g_read_addr, parent_read_addr, path_read_addr;
    logic g_read_en;
    logic g_we, parent_we;
    logic [11:0] g_write_addr, parent_write_addr;
    logic [22:0] g_write_data;
    logic [11:0] parent_write_data;
    logic [11:0] source, target, scan_idx, best_idx, current_idx;
    logic [11:0] retrace_idx, retrace_len, output_idx;
    logic [11:0] candidate_idx;
    logic candidate_ok;
    logic [2:0] direction;
    logic [23:0] best_f, scan_f;
    logic [22:0] best_h, scan_h;

    logic neighbor_ok, in_bounds;
    logic [11:0] neighbor_idx, side_a, side_b;
    logic [22:0] edge_cost;

    function automatic logic [22:0] heuristic(input logic [11:0] a,
                                                 input logic [11:0] b);
        logic [5:0] dx, dy, short_side, long_side;
        begin
            dx = (a[5:0] > b[5:0]) ? a[5:0] - b[5:0] : b[5:0] - a[5:0];
            dy = (a[11:6] > b[11:6]) ? a[11:6] - b[11:6] : b[11:6] - a[11:6];
            short_side = (dx < dy) ? dx : dy;
            long_side  = (dx > dy) ? dx : dy;
            heuristic = 23'd1000 * long_side + 23'd414 * short_side;
        end
    endfunction

    always_comb begin
        in_bounds = 1'b1;
        neighbor_idx = current_idx;
        side_a = current_idx;
        side_b = current_idx;
        edge_cost = direction[2] ? 23'd1414 : 23'd1000;
        case (direction)
            3'd0: begin
                in_bounds = current_idx[5:0] != 0;
                neighbor_idx = current_idx - 12'd1;
            end
            3'd1: begin
                in_bounds = current_idx[5:0] != 63;
                neighbor_idx = current_idx + 12'd1;
            end
            3'd2: begin
                in_bounds = current_idx[11:6] != 0;
                neighbor_idx = current_idx - 12'd64;
            end
            3'd3: begin
                in_bounds = current_idx[11:6] != 47;
                neighbor_idx = current_idx + 12'd64;
            end
            3'd4: begin
                in_bounds = current_idx[11:6] != 0 && current_idx[5:0] != 0;
                neighbor_idx = current_idx - 12'd65;
                side_a = current_idx - 12'd64;
                side_b = current_idx - 12'd1;
            end
            3'd5: begin
                in_bounds = current_idx[11:6] != 0 && current_idx[5:0] != 63;
                neighbor_idx = current_idx - 12'd63;
                side_a = current_idx - 12'd64;
                side_b = current_idx + 12'd1;
            end
            3'd6: begin
                in_bounds = current_idx[11:6] != 47 && current_idx[5:0] != 0;
                neighbor_idx = current_idx + 12'd63;
                side_a = current_idx + 12'd64;
                side_b = current_idx - 12'd1;
            end
            3'd7: begin
                in_bounds = current_idx[11:6] != 47 && current_idx[5:0] != 63;
                neighbor_idx = current_idx + 12'd65;
                side_a = current_idx + 12'd64;
                side_b = current_idx + 12'd1;
            end
        endcase
        neighbor_ok = in_bounds && !blocked[neighbor_idx] &&
            (!direction[2] || (!blocked[side_a] && !blocked[side_b]));
    end

    always_comb begin
        g_read_addr = 12'd0;
        if (state == ST_SCAN_READ) g_read_addr = scan_idx;
        else if (state == ST_SCAN_EVAL) g_read_addr = (scan_idx == 12'd3071) ? scan_idx : scan_idx + 1'b1;
        else if (state == ST_BEST_READ) g_read_addr = best_idx;
        else if (state == ST_NEIGHBOR_READ) g_read_addr = neighbor_idx;
        parent_read_addr = retrace_idx;
        path_read_addr = output_idx;
        scan_h = heuristic(scan_idx, target);
        scan_f = {1'b0, g_q} + {1'b0, scan_h};
    end
    assign g_read_en = (state == ST_SCAN_READ || state == ST_SCAN_EVAL ||
                        state == ST_BEST_READ || state == ST_NEIGHBOR_READ);

    // One physical write port per table, shared by initialization and search.
    always_comb begin
        g_we = 1'b0;
        g_write_addr = 12'd0;
        g_write_data = 23'd0;
        parent_we = 1'b0;
        parent_write_addr = 12'd0;
        parent_write_data = 12'd0;
        if (state == ST_INIT) begin
            g_we = 1'b1;
            g_write_addr = scan_idx;
            g_write_data = INF;
            parent_we = 1'b1;
            parent_write_addr = scan_idx;
            parent_write_data = 12'hfff;
        end else if (state == ST_SEED && source < 3072 && target < 3072 &&
                     !blocked[source] && !blocked[target]) begin
            g_we = 1'b1;
            g_write_addr = source;
        end else if (state == ST_NEIGHBOR_EVAL && candidate_ok &&
                     candidate_g < g_q) begin
            g_we = 1'b1;
            g_write_addr = candidate_idx;
            g_write_data = candidate_g;
            parent_we = 1'b1;
            parent_write_addr = candidate_idx;
            parent_write_data = current_idx;
        end
    end

    // Each memory has one write port and one clocked read port.
    always_ff @(posedge clk) begin
        if (g_read_en) g_q <= g_cost[g_read_addr];
        if (state == ST_RETRACE_READ) parent_q <= parent[parent_read_addr];
        if (state == ST_OUTPUT_PREFETCH) path_q <= reverse_path[path_read_addr];
        if (g_we) g_cost[g_write_addr] <= g_write_data;
        if (parent_we) parent[parent_write_addr] <= parent_write_data;
        if (state == ST_RETRACE_EVAL)
            reverse_path[retrace_len] <= retrace_idx;
    end

    assign busy = (state != ST_IDLE && state != ST_DONE);
    assign done = (state == ST_DONE);
    assign path_valid = (state == ST_OUTPUT);
    assign path_row = path_q[11:6];
    assign path_col = path_q[5:0];
    assign path_last = (state == ST_OUTPUT && output_idx == 0);

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            source <= 0; target <= 0; blocked <= 0;
            open_set <= 0; closed_set <= 0;
            scan_idx <= 0; best_idx <= 0; best_f <= INF_F; best_h <= INF;
            current_idx <= 0; current_g <= 0; direction <= 0;
            candidate_idx <= 0; candidate_g <= 0; candidate_ok <= 0;
            retrace_idx <= 0; retrace_len <= 0; output_idx <= 0;
            found <= 0; path_cost <= 0; path_length <= 0;
        end else begin
            case (state)
                ST_IDLE: if (start) begin
                    source <= start_idx;
                    target <= goal_idx;
                    blocked <= obstacle_map;
                    found <= 0; path_cost <= 0; path_length <= 0;
                    scan_idx <= 0;
                    state <= ST_INIT;
                end
                ST_INIT: begin
                    open_set[scan_idx] <= 0;
                    closed_set[scan_idx] <= 0;
                    if (scan_idx == 12'd3071) state <= ST_SEED;
                    else scan_idx <= scan_idx + 1'b1;
                end
                ST_SEED: begin
                    if (source >= 3072 || target >= 3072 ||
                        blocked[source] || blocked[target]) begin
                        state <= ST_DONE;
                    end else begin
                        open_set[source] <= 1;
                        state <= ST_SCAN_BEGIN;
                    end
                end
                ST_SCAN_BEGIN: begin
                    scan_idx <= 0;
                    best_idx <= 12'hfff;
                    best_f <= INF_F;
                    best_h <= INF;
                    state <= ST_SCAN_READ;
                end
                ST_SCAN_READ: state <= ST_SCAN_EVAL;
                ST_SCAN_EVAL: begin
                    if (open_set[scan_idx] && !closed_set[scan_idx] &&
                        (scan_f < best_f || (scan_f == best_f && scan_h < best_h))) begin
                        best_idx <= scan_idx;
                        best_f <= scan_f;
                        best_h <= scan_h;
                    end
                    if (scan_idx == 12'd3071) state <= ST_SELECT;
                    else begin
                        scan_idx <= scan_idx + 1'b1;
                        state <= ST_SCAN_EVAL;
                    end
                end
                ST_SELECT: begin
                    if (best_idx == 12'hfff) state <= ST_DONE;
                    else state <= ST_BEST_READ;
                end
                ST_BEST_READ: state <= ST_BEST_EVAL;
                ST_BEST_EVAL: begin
                    if (best_idx == target) begin
                        found <= 1;
                        path_cost <= g_q;
                        retrace_idx <= target;
                        retrace_len <= 0;
                        state <= ST_RETRACE_READ;
                    end else begin
                        current_idx <= best_idx;
                        current_g <= g_q;
                        open_set[best_idx] <= 0;
                        closed_set[best_idx] <= 1;
                        direction <= 0;
                        state <= ST_NEIGHBOR_READ;
                    end
                end
                ST_NEIGHBOR_READ: begin
                    candidate_idx <= neighbor_idx;
                    candidate_ok <= neighbor_ok && !closed_set[neighbor_idx];
                    candidate_g <= current_g + edge_cost;
                    state <= ST_NEIGHBOR_EVAL;
                end
                ST_NEIGHBOR_EVAL: begin
                    if (candidate_ok && candidate_g < g_q)
                        open_set[candidate_idx] <= 1;
                    if (direction == 3'd7) state <= ST_SCAN_BEGIN;
                    else begin
                        direction <= direction + 1'b1;
                        state <= ST_NEIGHBOR_READ;
                    end
                end
                ST_RETRACE_READ: state <= ST_RETRACE_EVAL;
                ST_RETRACE_EVAL: begin
                    if (retrace_idx == source) begin
                        path_length <= retrace_len + 1'b1;
                        output_idx <= retrace_len;
                        state <= ST_OUTPUT_PREFETCH;
                    end else if (retrace_len == 12'd3071 || parent_q == 12'hfff) begin
                        found <= 0;
                        state <= ST_DONE;
                    end else begin
                        retrace_idx <= parent_q;
                        retrace_len <= retrace_len + 1'b1;
                        state <= ST_RETRACE_READ;
                    end
                end
                ST_OUTPUT_PREFETCH: state <= ST_OUTPUT;
                ST_OUTPUT: if (path_ready) begin
                    if (output_idx == 0) state <= ST_DONE;
                    else begin
                        output_idx <= output_idx - 1'b1;
                        state <= ST_OUTPUT_PREFETCH;
                    end
                end
                ST_DONE: state <= ST_IDLE;
                default: state <= ST_IDLE;
            endcase
        end
    end
endmodule
