module traj_manager (
    input  wire        clk,
    input  wire        rst_n,

    input  wire        recording,      // 来自 traj_ctrl
    input  wire        clear_traj,     // 1拍脉冲：清空
    input  wire        center_valid,   // 框有效
    input  wire [10:0] center_x,       // 中心点（屏幕坐标 0~1023）
    input  wire [10:0] center_y,       // 0~767
    input  wire        frame_pulse,    // 每帧1拍脉冲

    // 给 line_drawer
    output reg         draw_start,
    output reg  [9:0]  draw_x0, draw_y0,   // 位图坐标
    output reg  [9:0]  draw_x1, draw_y1,
    input  wire        draw_busy,
    output reg         clear_start,
    input  wire        clear_busy
);

    reg [9:0] prev_x, prev_y;     // 上一个中心点（位图坐标）
    reg       prev_valid;
    reg       clear_pending;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prev_x <= 10'd0; prev_y <= 10'd0;
            prev_valid <= 1'b0;
            clear_pending <= 1'b0;
            draw_start <= 1'b0;
            clear_start <= 1'b0;
        end else begin
            draw_start <= 1'b0;
            clear_start <= 1'b0;

            // 清空请求：先挂起，等 line_drawer 空闲再发
            if (clear_traj) begin
                clear_pending <= 1'b1;
                prev_valid <= 1'b0;
            end
            if (clear_pending && !draw_busy && !clear_busy) begin
                clear_start <= 1'b1;
                clear_pending <= 1'b0;
            end

            // 每帧更新点
            if (frame_pulse && !draw_busy && !clear_busy && !clear_pending) begin
                if (recording && center_valid) begin
                    if (prev_valid) begin
                        // 画 上一点 -> 当前点
                        draw_x0 <= prev_x;
                        draw_y0 <= prev_y;
                        draw_x1 <= center_x[9:0];   // 1:1 映射
                        draw_y1 <= center_y[9:0];
                        draw_start <= 1'b1;
                    end
                    prev_x <= center_x[9:0];
                    prev_y <= center_y[9:0];
                    prev_valid <= 1'b1;
                end else begin
                    // 暂停或框消失：断线
                    prev_valid <= 1'b0;
                end
            end
        end
    end

endmodule