module tiny_object_cnn_int8 #(
    parameter CONV1_W_FILE = "conv1_weights_int8.mem",
    parameter CONV1_B_FILE = "conv1_bias_int32.mem",
    parameter CONV1_M_FILE = "conv1_requant_multiplier_int32.mem",
    parameter CONV2_W_FILE = "conv2_weights_int8.mem",
    parameter CONV2_B_FILE = "conv2_bias_int32.mem",
    parameter CONV2_M_FILE = "conv2_requant_multiplier_int32.mem",
    parameter FC_W_FILE    = "fc_weights_int8.mem",
    parameter FC_B_FILE    = "fc_bias_int32.mem"
) (
    input  logic clk,
    input  logic rst_n,
    input  logic load_we,
    input  logic [9:0] load_addr,
    input  logic signed [7:0] load_data,
    input  logic start,
    output logic busy,
    output logic done,
    output logic [1:0] class_id,
    output logic signed [31:0] score_car, score_block, score_other
);
    localparam [3:0] S_IDLE=0, S_C1_FETCH=1, S_C1_MAC=2,
                     S_C1_QPRE=3, S_C1_QMULT=4, S_C1_STORE=5,
                     S_C2_FETCH=6, S_C2_MAC=7, S_C2_QPRE=8,
                     S_C2_QMULT=9, S_C2_STORE=10,
                     S_FC_FETCH=11, S_FC_MAC=12, S_RESULT=13;
    logic [3:0] state;

    logic signed [7:0] input_mem [0:1023];
    logic signed [7:0] pool1 [0:2047]; // 8x16x16
    logic signed [7:0] pool2 [0:1023]; // 16x8x8
    logic signed [7:0] conv1_w [0:71];
    logic signed [31:0] conv1_b [0:7];
    logic signed [31:0] conv1_m [0:7];
    logic signed [7:0] conv2_w [0:1151];
    logic signed [31:0] conv2_b [0:15];
    logic signed [31:0] conv2_m [0:15];
    logic signed [7:0] fc_w [0:3071];
    logic signed [31:0] fc_b [0:2];

    logic [3:0] oc, oy, ox;
    logic py, px;
    logic [2:0] ic;
    logic [1:0] ky, kx;
    logic [9:0] fc_index;
    logic [1:0] fc_class;
    logic signed [6:0] iy, ix;
    logic [10:0] weight_index;
    // INT32 MAC and INT64 requant product; export script verifies conservative bounds.
    logic signed [31:0] mac_acc, mac_term, mac_next;
    logic signed [7:0] input_sample, pool1_sample, pool2_sample;
    logic signed [7:0] conv1_weight_sample, conv2_weight_sample, fc_weight_sample;
    logic sample_valid;
    logic signed [31:0] quant_multiplier;
    logic signed [63:0] quant_product;
    logic signed [31:0] quant_value;
    logic signed [7:0] pool_max;
    logic signed [7:0] pooled_value;

    initial begin
        $readmemh(CONV1_W_FILE, conv1_w);
        $readmemh(CONV1_B_FILE, conv1_b);
        $readmemh(CONV1_M_FILE, conv1_m);
        $readmemh(CONV2_W_FILE, conv2_w);
        $readmemh(CONV2_B_FILE, conv2_b);
        $readmemh(CONV2_M_FILE, conv2_m);
        $readmemh(FC_W_FILE, fc_w);
        $readmemh(FC_B_FILE, fc_b);
    end

    // ReLU maps every negative product to zero. Positive rounding only
    // needs the seven integer bits and the half-LSB; detect saturation
    // before the small add to avoid a 64-bit negate/add/negate chain.
    function automatic signed [31:0] requant_relu_product;
        input signed [63:0] product;
        reg [7:0] rounded_positive;
        begin
            rounded_positive = {1'b0, product[30:24]} + product[23];
            if (product[63]) requant_relu_product = 0;
            else if ((|product[62:31]) || product[30:24] == 7'd127)
                requant_relu_product = 127;
            else requant_relu_product = {24'd0, rounded_positive};
        end
    endfunction

    // The address mux, INT8 multiply, INT32 accumulate and requantization
    // must not form one pixel-clock path. Each memory read is synchronous;
    // MAC, requant multiplication and clamp occupy separate cycles.
    always @* begin
        iy = oy*2 + py + ky - 1;
        ix = ox*2 + px + kx - 1;
        weight_index = 0;
        if (state == S_C1_FETCH)
            weight_index = oc*9 + ky*3 + kx;
        else if (state == S_C2_FETCH)
            weight_index = ((oc*8+ic)*3+ky)*3+kx;

        mac_term = 0;
        case (state)
            S_C1_MAC: if (sample_valid)
                mac_term = $signed(input_sample) * $signed(conv1_weight_sample);
            S_C2_MAC: if (sample_valid)
                mac_term = $signed(pool1_sample) * $signed(conv2_weight_sample);
            S_FC_MAC:
                mac_term = $signed(pool2_sample) * $signed(fc_weight_sample);
            default: mac_term = 0;
        endcase
        mac_next = mac_acc + mac_term;
        quant_value = requant_relu_product(quant_product);
        pooled_value = (quant_value[7:0] > pool_max) ? quant_value[7:0] : pool_max;
    end

    // Keep RAM read and write ports in the same non-reset process so Vivado
    // can infer block RAM instead of thousands of asynchronously-read FFs.
    always_ff @(posedge clk) begin
        if (load_we && !busy)
            input_mem[load_addr] <= load_data;
        if (state == S_C1_FETCH) begin
            sample_valid <= (iy >= 0 && iy < 32 && ix >= 0 && ix < 32);
            input_sample <= input_mem[{iy[4:0],ix[4:0]}];
            conv1_weight_sample <= conv1_w[weight_index];
        end
        if (state == S_C2_FETCH) begin
            sample_valid <= (iy >= 0 && iy < 16 && ix >= 0 && ix < 16);
            pool1_sample <= pool1[{ic,iy[3:0],ix[3:0]}];
            conv2_weight_sample <= conv2_w[weight_index];
        end
        if (state == S_FC_FETCH) begin
            pool2_sample <= pool2[fc_index];
            fc_weight_sample <= fc_w[{fc_class,fc_index}];
        end
        if (state == S_C1_STORE && py && px)
            pool1[{oc[2:0],oy,ox}] <= pooled_value;
        if (state == S_C2_STORE && py && px)
            pool2[{oc,oy[2:0],ox[2:0]}] <= pooled_value;
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE; busy <= 0; done <= 0; class_id <= 2; score_car <= 0; score_block <= 0; score_other <= 0; fc_class <= 0;
            oc<=0; oy<=0; ox<=0; py<=0; px<=0; ic<=0; ky<=0; kx<=0; fc_index<=0;
            mac_acc<=0; pool_max<=0; quant_multiplier<=0; quant_product<=0;
        end else begin
            done <= 0;
            case (state)
                S_IDLE: if (start) begin
                    busy<=1; oc<=0; oy<=0; ox<=0; py<=0; px<=0; ic<=0; ky<=0; kx<=0;
                    mac_acc<=conv1_b[0]; pool_max<=0; state<=S_C1_FETCH;
                end
                S_C1_FETCH: state<=S_C1_MAC;
                S_C1_MAC: begin
                    mac_acc<=mac_next;
                    if (kx < 2) begin kx<=kx+1; state<=S_C1_FETCH; end
                    else if (ky < 2) begin kx<=0; ky<=ky+1; state<=S_C1_FETCH; end
                    else begin kx<=0; ky<=0; state<=S_C1_QPRE; end
                end
                S_C1_QPRE: begin quant_multiplier<=conv1_m[oc]; state<=S_C1_QMULT; end
                S_C1_QMULT: begin quant_product<=mac_acc*quant_multiplier; state<=S_C1_STORE; end
                S_C1_STORE: begin
                    if (pooled_value > pool_max) pool_max<=pooled_value;
                    if (!px) begin px<=1; mac_acc<=conv1_b[oc]; state<=S_C1_FETCH; end
                    else if (!py) begin px<=0; py<=1; mac_acc<=conv1_b[oc]; state<=S_C1_FETCH; end
                    else begin
                        px<=0; py<=0; pool_max<=0;
                        if (ox < 15) begin ox<=ox+1; mac_acc<=conv1_b[oc]; state<=S_C1_FETCH; end
                        else if (oy < 15) begin ox<=0; oy<=oy+1; mac_acc<=conv1_b[oc]; state<=S_C1_FETCH; end
                        else if (oc < 7) begin ox<=0; oy<=0; oc<=oc+1; mac_acc<=conv1_b[oc+1]; state<=S_C1_FETCH; end
                        else begin oc<=0; oy<=0; ox<=0; ic<=0; mac_acc<=conv2_b[0]; state<=S_C2_FETCH; end
                    end
                end
                S_C2_FETCH: state<=S_C2_MAC;
                S_C2_MAC: begin
                    mac_acc<=mac_next;
                    if (kx < 2) begin kx<=kx+1; state<=S_C2_FETCH; end
                    else if (ky < 2) begin kx<=0; ky<=ky+1; state<=S_C2_FETCH; end
                    else if (ic < 7) begin kx<=0; ky<=0; ic<=ic+1; state<=S_C2_FETCH; end
                    else begin kx<=0; ky<=0; ic<=0; state<=S_C2_QPRE; end
                end
                S_C2_QPRE: begin quant_multiplier<=conv2_m[oc]; state<=S_C2_QMULT; end
                S_C2_QMULT: begin quant_product<=mac_acc*quant_multiplier; state<=S_C2_STORE; end
                S_C2_STORE: begin
                    if (pooled_value > pool_max) pool_max<=pooled_value;
                    if (!px) begin px<=1; mac_acc<=conv2_b[oc]; state<=S_C2_FETCH; end
                    else if (!py) begin px<=0; py<=1; mac_acc<=conv2_b[oc]; state<=S_C2_FETCH; end
                    else begin
                        px<=0; py<=0; pool_max<=0;
                        if (ox < 7) begin ox<=ox+1; mac_acc<=conv2_b[oc]; state<=S_C2_FETCH; end
                        else if (oy < 7) begin ox<=0; oy<=oy+1; mac_acc<=conv2_b[oc]; state<=S_C2_FETCH; end
                        else if (oc < 15) begin ox<=0; oy<=0; oc<=oc+1; mac_acc<=conv2_b[oc+1]; state<=S_C2_FETCH; end
                        else begin fc_class<=0; fc_index<=0; mac_acc<=fc_b[0]; state<=S_FC_FETCH; end
                    end
                end
                S_FC_FETCH: state<=S_FC_MAC;
                S_FC_MAC: begin
                    if (fc_index < 1023) begin fc_index<=fc_index+1; mac_acc<=mac_next; state<=S_FC_FETCH; end
                    else begin
                        if (fc_class == 0) score_car <= mac_next;
                        if (fc_class == 1) score_block <= mac_next;
                        if (fc_class < 2) begin
                            fc_class<=fc_class+1; fc_index<=0; mac_acc<=fc_b[fc_class+1]; state<=S_FC_FETCH;
                        end else begin
                            score_other<=mac_next;
                            state<=S_RESULT;
                        end
                    end
                end
                S_RESULT: begin
                    if (score_car >= score_block && score_car >= score_other) class_id<=0;
                    else if (score_block >= score_other) class_id<=1;
                    else class_id<=2;
                    busy<=0; done<=1; state<=S_IDLE;
                end
                default: state<=S_IDLE;
            endcase
        end
    end
endmodule
