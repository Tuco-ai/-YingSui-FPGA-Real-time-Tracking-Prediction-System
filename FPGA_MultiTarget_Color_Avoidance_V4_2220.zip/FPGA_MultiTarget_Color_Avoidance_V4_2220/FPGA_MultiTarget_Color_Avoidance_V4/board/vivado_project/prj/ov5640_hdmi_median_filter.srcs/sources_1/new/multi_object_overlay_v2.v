module multi_object_overlay_v2 #(
 parameter integer MAX_OBJ=16,MAX_RUNS=64,H_ACTIVE=1024,V_ACTIVE=768,
 parameter [5:0] GRAY_CENTER=8,GRAY_TOL=4,
 parameter [19:0] MIN_BLACK_AREA=300,MAX_BLACK_AREA=300000,
 parameter [7:0] HOLD_FRAMES=0,parameter [10:0] ROI_MARGIN=4,
 parameter [3:0] GAP_PIXELS=8,parameter integer MAX_CAND=5
)(
 input cam_clk,pixel_clk,rst_n,frame_vsync,frame_href,frame_de,
 input [15:0] frame_rgb,
 input [1:0] color_mode,input [10:0] pixel_xpos,pixel_ypos,
 input [15:0] rd_data,input display_vsync,display_de,
 output [15:0] hdmi_data_d,output cnn_overlay_hit,output [10:0] center_x,center_y,
 output center_valid,frame_pulse,
 output reg cnn_car_valid,output reg [3:0] cnn_car_index,
 output reg [15:0] cnn_block_valid,
 output [15:0] roi_valid,roi_observed,roi_estimated,
 output [175:0] roi_x0,roi_x1,roi_y0,roi_y1,
 output [47:0] roi_color
);
 wire pixel_reset_n;
 reset_release_sync pixel_reset(.clk(pixel_clk),.arst_n(rst_n),.srst_n(pixel_reset_n));
 wire [15:0] raw_v,raw_o,raw_e;
 wire raw_update;wire [15:0] raw_frame_id;
 wire [175:0] raw_x0,raw_x1,raw_y0,raw_y1;
 wire [47:0] raw_color;
 reg [15:0] av,ao,ae;
 reg [175:0] ax0,ax1,ay0,ay1;
 reg [47:0] ac;
 reg update,start_d1,start_d2;
 wire [15:0] class_valid;
 wire [31:0] classes;
 wire raw_car_found;
 wire [3:0] raw_car_index;
 wire [15:0] raw_block_valid;
 genvar block_slot;
 generate for(block_slot=0;block_slot<16;block_slot=block_slot+1)begin: block_candidates
  assign raw_block_valid[block_slot]=raw_v[block_slot]&&raw_o[block_slot]&&
   class_valid[block_slot]&&(classes[block_slot*2+:2]==2'd1);
 end endgenerate
 cnn_car_pick car_pick(.roi_valid(raw_v),.roi_observed(raw_o),
  .class_valid(class_valid),.classes(classes),
  .car_valid(raw_car_found),.car_index(raw_car_index));
 reg [15:0] draw_valid;
 reg [31:0] draw_classes;
 reg [47:0] draw_color;
 reg [1:0] draw_mode;
 reg vs_d;
 always @(posedge pixel_clk or negedge pixel_reset_n)if(!pixel_reset_n)vs_d<=0;else vs_d<=display_vsync;
 wire video_start=display_vsync&&!vs_d;
 // Frame-boundary snapshot prevents a moving rectangle tearing mid-scan.
 // Two blanking clocks let the generation tag update before ROI capture.
 always @(posedge pixel_clk or negedge pixel_reset_n) begin
  if(!pixel_reset_n) begin av<=0;ao<=0;ae<=0;ax0<=0;ax1<=0;ay0<=0;ay1<=0;ac<=0;update<=0;start_d1<=0;start_d2<=0;draw_valid<=0;draw_classes<=32'haaaaaaaa;draw_color<=0;draw_mode<=0;cnn_car_valid<=0;cnn_car_index<=0;cnn_block_valid<=0;end
  else begin
   start_d1<=video_start;start_d2<=start_d1;update<=0;
   if(video_start)begin draw_valid<=class_valid;draw_classes<=classes;draw_color<=raw_color;draw_mode<=color_mode;av<=raw_v;ao<=raw_o;ae<=raw_e;ax0<=raw_x0;ax1<=raw_x1;ay0<=raw_y0;ay1<=raw_y1;ac<=raw_color;cnn_car_valid<=raw_car_found;cnn_car_index<=raw_car_index;cnn_block_valid<=raw_block_valid;update<=1;end
  end
 end
 // The inherited video_driver exposes one-based active coordinates.
 wire [10:0] sample_x=(pixel_xpos==0)?11'd0:pixel_xpos-1'b1;
 wire [10:0] sample_y=(pixel_ypos==0)?11'd0:pixel_ypos-1'b1;
 wire pixel_valid=display_de&&(pixel_xpos>0)&&(pixel_xpos<=H_ACTIVE)&&(pixel_ypos>0)&&(pixel_ypos<=V_ACTIVE);
 assign roi_valid=av;assign roi_observed=ao;assign roi_estimated=ae;
 assign roi_x0=ax0;assign roi_x1=ax1;assign roi_y0=ay0;assign roi_y1=ay1;
 assign roi_color=ac;
 reg [2:0] geometry_ready;
 always @(posedge pixel_clk or negedge pixel_reset_n)if(!pixel_reset_n)geometry_ready<=0;else geometry_ready<={geometry_ready[1:0],update};
 assign frame_pulse=geometry_ready[2];
 all_color_tracker #(.H_ACTIVE(H_ACTIVE),.V_ACTIVE(V_ACTIVE),.MIN_AREA(MIN_BLACK_AREA),.HOLD_FRAMES(3),.PAD(0)) colors(
  .cam_clk(cam_clk),.pixel_clk(pixel_clk),.rst_n(rst_n),.frame_vsync(frame_vsync),.frame_href(frame_href),.frame_de(frame_de),
  .frame_rgb(frame_rgb),.pixel_xpos(pixel_xpos),.pixel_ypos(pixel_ypos),.rd_data(rd_data),.hdmi_data(),
  .center_x(),.center_y(),.center_valid(),.frame_pulse(raw_update),.roi_frame_id(raw_frame_id),.roi_valid(raw_v),.roi_observed(raw_o),.roi_estimated(raw_e),
  .roi_x0(raw_x0),.roi_x1(raw_x1),.roi_y0(raw_y0),.roi_y1(raw_y1),.roi_color(raw_color)
 );
 cnn_camera_classifier #(.H_ACTIVE(H_ACTIVE),.V_ACTIVE(V_ACTIVE)) classify(
  .cam_clk(cam_clk),.clk(pixel_clk),.rst_n(rst_n),
  .frame_vsync(frame_vsync),.frame_href(frame_href),.frame_de(frame_de),.frame_rgb(frame_rgb),
  .color_mode(color_mode),.candidate_update(raw_update),.candidate_frame_id(raw_frame_id),.candidate_observed(raw_o),.candidate_estimated(raw_e),.candidate_color(raw_color),
  .x0(raw_x0),.x1(raw_x1),.y0(raw_y0),.y1(raw_y1),.class_valid(class_valid),.classes(classes)
 );
 cnn_class_overlay #(.H_ACTIVE(H_ACTIVE),.V_ACTIVE(V_ACTIVE)) draw(
  .clk(pixel_clk),.rst_n(pixel_reset_n),.update(update),
  .pixel_x(sample_x),.pixel_y(sample_y),.rgb_in(rd_data),.color_mode(draw_mode),.observed(ao),
  .class_valid(draw_valid & class_valid),.classes(draw_classes),.object_color(draw_color),.x0(ax0),.x1(ax1),.y0(ay0),.y1(ay1),
  .rgb_out(hdmi_data_d),.overlay_hit(cnn_overlay_hit),.center_x(center_x),.center_y(center_y),.center_valid(center_valid)
 );
endmodule

// Select the first box that the CNN classifies as CAR. The color tracker
// reserves its largest blue component in slot 0, so it wins when qualified.
module cnn_car_pick(
 input [15:0] roi_valid,roi_observed,class_valid,
 input [31:0] classes,
 output reg car_valid,output reg [3:0] car_index
);
 integer slot;
 always @* begin
  car_valid=0;car_index=0;
  for(slot=15;slot>=0;slot=slot-1)
   if(roi_valid[slot]&&roi_observed[slot]&&class_valid[slot]&&
      classes[slot*2+:2]==2'd0)begin
    car_valid=1;car_index=slot;
   end
 end
endmodule

// Up to sixteen color-connected components, with one blue car reserved in slot zero.
// Synthesizable Verilog-2001.
module all_color_tracker #(
 parameter integer H_ACTIVE=1024,V_ACTIVE=768,
 parameter integer MIN_AREA=300,MIN_RUN=3,MIN_SIDE=8,
 parameter integer SAT_MIN=32,
 parameter integer FILTER_GEOMETRY=1,MAX_BBOX_SIDE=V_ACTIVE,MAX_COMPONENT_AREA=(H_ACTIVE*V_ACTIVE)/2,
 parameter integer PAD=3,HOLD_FRAMES=20,
 parameter [15:0] BOX_RGB=16'h07e0
)(
 input cam_clk,pixel_clk,rst_n,frame_vsync,frame_href,frame_de,
 input [15:0] frame_rgb,
 input [10:0] pixel_xpos,pixel_ypos,input [15:0] rd_data,
 output reg [15:0] hdmi_data,
 output reg [10:0] center_x,center_y,output reg center_valid,frame_pulse,
 output reg [15:0] roi_valid,roi_observed,roi_estimated,
 output reg [15:0] roi_frame_id,
 output reg [175:0] roi_x0,roi_x1,roi_y0,roi_y1,
 output reg [47:0] roi_color
);
wire cam_reset_n,pixel_reset_n;
reset_release_sync cam_reset(.clk(cam_clk),.arst_n(rst_n),.srst_n(cam_reset_n));
reset_release_sync pixel_reset(.clk(pixel_clk),.arst_n(rst_n),.srst_n(pixel_reset_n));
wire [7:0] r={frame_rgb[15:11],frame_rgb[15:13]};
wire [7:0] g={frame_rgb[10:5],frame_rgb[10:9]};
wire [7:0] b={frame_rgb[4:0],frame_rgb[4:2]};
wire [8:0] rr={1'b0,r},gg={1'b0,g},bb={1'b0,b};
wire [7:0] mxrg=r>g?r:g,mnrg=r<g?r:g;
wire [7:0] mx=mxrg>b?mxrg:b,mn=mnrg<b?mnrg:b;
wire [7:0] chroma=mx-mn;
wire saturated=(mx>=32)&&(chroma>=SAT_MIN)&&(({1'b0,chroma,3'b000})>=({3'b000,mx}+{2'b00,mx,1'b0}));
wire [3:0] mask;
// Mutually exclusive blue/red/pink/green hints. Thin neutral rod is rejected.
assign mask[0]=saturated&&(bb>=rr+20)&&(bb>=gg+12);
assign mask[1]=saturated&&(rr>=gg+20)&&({rr,1'b0}>=({1'b0,bb}+{bb,1'b0}));
assign mask[2]=saturated&&(rr>=gg+20)&&(bb>=gg+12)&&(({1'b0,bb}+{bb,1'b0})>={rr,1'b0})&&!mask[0]&&!mask[1];
assign mask[3]=saturated&&(mx>=40)&&(gg>=rr+8)&&(gg>=bb+14);
// Run-based components, with color kept as part of component identity.
// 32 working components reject detached speckles. Up to sixteen components
// are selected globally; a blue car, when present, keeps slot zero.
localparam NCOMP=32;
 generate if(MIN_RUN<3)begin: invalid_min_run_configuration
 MIN_RUN_must_be_at_least_3 invalid_parameter();
end endgenerate
reg [10:0] x,y;
reg vs_d,href_d;
wire frame_end=frame_vsync&&!vs_d;
reg [5:0] drain;
reg [15:0] cam_frame_id;
always @(posedge cam_clk or negedge cam_reset_n)
 if(!cam_reset_n)cam_frame_id<=0;else if(frame_end)cam_frame_id<=cam_frame_id+1'b1;
always @(posedge cam_clk or negedge cam_reset_n)
 if(!cam_reset_n)drain<=0;else drain<={drain[4:0],frame_end};
wire snapshot_end=drain[5];
wire row_end=href_d&&!frame_href;
reg [2:0] label;
always @* begin
 label=0;
 if(mask[0]) label=1;else if(mask[1]) label=2;
 else if(mask[2]) label=3;else if(mask[3]) label=4;
end
reg [2:0] run_color;
reg [10:0] run0,run1,run_len;
wire valid_pixel=frame_href&&frame_de&&!frame_vsync&&(x<H_ACTIVE)&&(y<V_ACTIVE);
wire commit_run=(run_len>=MIN_RUN)&&(row_end||(valid_pixel&&(label!=run_color)));
reg [NCOMP-1:0] cv;
reg [2:0] cc[0:NCOMP-1];
reg [10:0] cx0[0:NCOMP-1],cx1[0:NCOMP-1],cy0[0:NCOMP-1],cy1[0:NCOMP-1];
reg [19:0] ca[0:NCOMP-1];
reg [10:0] last_y[0:NCOMP-1];
 // Reject sparse/oversize components BEFORE choosing the largest of a color.
 // Three registered stages keep the bbox multiplication out of CCL feedback.
 reg [11:0] geo_w[0:NCOMP-1],geo_h[0:NCOMP-1];
 reg [19:0] geo_a0[0:NCOMP-1],geo_a1[0:NCOMP-1];
 reg [23:0] geo_box[0:NCOMP-1];
 reg [NCOMP-1:0] geo_v0,geo_v1,geometry_ok;
 integer geo_idx;
 always @(posedge cam_clk or negedge cam_reset_n) begin
  if(!cam_reset_n)begin
   geo_v0<=0;geo_v1<=0;geometry_ok<=0;
   for(geo_idx=0;geo_idx<NCOMP;geo_idx=geo_idx+1)begin geo_w[geo_idx]<=0;geo_h[geo_idx]<=0;geo_a0[geo_idx]<=0;geo_a1[geo_idx]<=0;geo_box[geo_idx]<=0;end
  end else for(geo_idx=0;geo_idx<NCOMP;geo_idx=geo_idx+1)begin
   geo_w[geo_idx]<={1'b0,cx1[geo_idx]}-{1'b0,cx0[geo_idx]}+12'd1;
   geo_h[geo_idx]<={1'b0,cy1[geo_idx]}-{1'b0,cy0[geo_idx]}+12'd1;
   geo_a0[geo_idx]<=ca[geo_idx];
   geo_v0[geo_idx]<=cv[geo_idx]&&(ca[geo_idx]>=MIN_AREA)&&
    (cx1[geo_idx]>=cx0[geo_idx]+MIN_SIDE-1)&&(cy1[geo_idx]>=cy0[geo_idx]+MIN_SIDE-1)&&
    (cx1[geo_idx]>=cx0[geo_idx])&&(cy1[geo_idx]>=cy0[geo_idx]);
   geo_box[geo_idx]<=geo_w[geo_idx]*geo_h[geo_idx];geo_a1[geo_idx]<=geo_a0[geo_idx];geo_v1[geo_idx]<=geo_v0[geo_idx];
   geometry_ok[geo_idx]<=geo_v1[geo_idx]&&({2'b0,geo_a1[geo_idx],2'b00}>=geo_box[geo_idx]);
  end
 end
 // Balanced reduction replaces the 32-entry serial priority/area chain.
 // Leaves are at NCOMP..2*NCOMP-1; each level halves the fan-in.
 wire [NCOMP-1:0] run_matches;
 wire [10:0] ml,mr,mt,mb;
 wire [19:0] ma;
 integer found;
 wire [2*NCOMP-1:1] match_any,free_any,reuse_any;
 wire [4:0] match_id[1:2*NCOMP-1];
 wire [4:0] free_id[1:2*NCOMP-1],reuse_id[1:2*NCOMP-1];
 wire [19:0] reuse_area[1:2*NCOMP-1],match_area[1:2*NCOMP-1];
 wire [10:0] match_l[1:2*NCOMP-1],match_r[1:2*NCOMP-1];
 wire [10:0] match_t[1:2*NCOMP-1],match_b[1:2*NCOMP-1];

 // MIN_RUN=3 guarantees at least three clocks between committed runs.
 // S0: reduce four live leaves per group. S1: reduce eight groups. S2: write CCL.
 reg [1:0] merge_pipe;
 reg [NCOMP-1:0] leaf_match;
 reg [10:0] held_run0,held_run1,held_len,held_y;
 reg [2:0] held_color;
 reg [10:0] merged_l,merged_r,merged_t,merged_b,merged_y;
 reg [19:0] merged_area;
 reg signed [5:0] merged_id;
 reg [2:0] merged_color;
 reg [NCOMP-1:0] merged_mask;
 always @(posedge cam_clk or negedge cam_reset_n)begin
 if(!cam_reset_n)begin
 merge_pipe<=0;leaf_match<=0;
 held_run0<=0;held_run1<=0;held_len<=0;held_y<=0;held_color<=0;
 merged_l<=0;merged_r<=0;merged_t<=0;merged_b<=0;merged_y<=0;merged_area<=0;merged_id<=-1;merged_color<=0;merged_mask<=0;
 end else begin
 merge_pipe<={merge_pipe[0],commit_run&&(!frame_vsync||frame_end)};
 if(commit_run&&(!frame_vsync||frame_end))begin
 held_run0<=run0;held_run1<=run1;held_len<=run_len;held_y<=y;held_color<=run_color;
 leaf_match<=run_matches;
 end
 if(merge_pipe[0])begin
 merged_l<=ml;merged_r<=mr;merged_t<=mt;merged_b<=mb;merged_y<=held_y;
 merged_area<=ma;merged_id<=found;merged_color<=held_color;merged_mask<=leaf_match;
 end
 end end
 genvar gi;
 generate
  for(gi=0;gi<NCOMP;gi=gi+1) begin: merge_leaf
   assign run_matches[gi]=cv[gi]&&(cc[gi]==run_color)&&
       ({1'b0,y}<={1'b0,last_y[gi]}+12'd2)&&({1'b0,run0}<={1'b0,cx1[gi]}+12'd2)&&({1'b0,run1}+12'd2>={1'b0,cx0[gi]});
   assign match_any[NCOMP+gi]=run_matches[gi];
   assign match_id[NCOMP+gi]=gi;
   assign free_any[NCOMP+gi]=!cv[gi];
   assign free_id[NCOMP+gi]=gi;
   assign reuse_any[NCOMP+gi]=cv[gi]&&({1'b0,last_y[gi]}+12'd2<{1'b0,y})&&(ca[gi]!=20'hfffff);
   assign reuse_id[NCOMP+gi]=gi;
   assign reuse_area[NCOMP+gi]=ca[gi];
   assign match_area[NCOMP+gi]=run_matches[gi]?ca[gi]:20'd0;
   assign match_l[NCOMP+gi]=cx0[gi];
   assign match_r[NCOMP+gi]=cx1[gi];
   assign match_t[NCOMP+gi]=cy0[gi];
   assign match_b[NCOMP+gi]=cy1[gi];
  end
  for(gi=1;gi<NCOMP;gi=gi+1) begin: merge_node
   wire left_reuse;
   wire calc_match_any;
   wire [4:0] calc_match_id;
   wire calc_free_any;
   wire [4:0] calc_free_id;
   wire calc_reuse_any;
   wire [4:0] calc_reuse_id;
   wire [19:0] calc_reuse_area;
   wire [19:0] calc_match_area;
   wire [10:0] calc_match_l;
   wire [10:0] calc_match_r;
   wire [10:0] calc_match_t;
   wire [10:0] calc_match_b;
   assign calc_match_any=match_any[2*gi]|match_any[2*gi+1];
   assign calc_match_id=match_any[2*gi]?match_id[2*gi]:match_id[2*gi+1];
   assign calc_free_any=free_any[2*gi]|free_any[2*gi+1];
   assign calc_free_id=free_any[2*gi]?free_id[2*gi]:free_id[2*gi+1];
   assign calc_reuse_any=reuse_any[2*gi]|reuse_any[2*gi+1];
   assign left_reuse=reuse_any[2*gi]&&
       (!reuse_any[2*gi+1]||(reuse_area[2*gi]<=reuse_area[2*gi+1]));
   assign calc_reuse_id=left_reuse?reuse_id[2*gi]:reuse_id[2*gi+1];
   assign calc_reuse_area=left_reuse?reuse_area[2*gi]:reuse_area[2*gi+1];
   assign calc_match_area=match_area[2*gi]+match_area[2*gi+1];
   assign calc_match_l=!match_any[2*gi]?match_l[2*gi+1]:
       !match_any[2*gi+1]?match_l[2*gi]:
       (match_l[2*gi]<match_l[2*gi+1]?match_l[2*gi]:match_l[2*gi+1]);
   assign calc_match_r=!match_any[2*gi]?match_r[2*gi+1]:
       !match_any[2*gi+1]?match_r[2*gi]:
       (match_r[2*gi]>match_r[2*gi+1]?match_r[2*gi]:match_r[2*gi+1]);
   assign calc_match_t=!match_any[2*gi]?match_t[2*gi+1]:
       !match_any[2*gi+1]?match_t[2*gi]:
       (match_t[2*gi]<match_t[2*gi+1]?match_t[2*gi]:match_t[2*gi+1]);
   assign calc_match_b=!match_any[2*gi]?match_b[2*gi+1]:
       !match_any[2*gi+1]?match_b[2*gi]:
       (match_b[2*gi]>match_b[2*gi+1]?match_b[2*gi]:match_b[2*gi+1]);
   // Register after the first two tree levels. The upper three levels then
   // have their own cycle; the overall three-clock run transaction is unchanged.
   if(gi>=NCOMP/4 && gi<NCOMP/2)begin: group_register
    reg [101:0] value_r;
    always @(posedge cam_clk or negedge cam_reset_n)
     if(!cam_reset_n)value_r<=0;
     else if(commit_run&&(!frame_vsync||frame_end))value_r<={calc_match_any,calc_match_id,calc_free_any,calc_free_id,calc_reuse_any,calc_reuse_id,calc_reuse_area,calc_match_area,calc_match_l,calc_match_r,calc_match_t,calc_match_b};
    assign {match_any[gi],match_id[gi],free_any[gi],free_id[gi],reuse_any[gi],reuse_id[gi],reuse_area[gi],match_area[gi],match_l[gi],match_r[gi],match_t[gi],match_b[gi]}=value_r;
   end else begin: combinational_level
    assign {match_any[gi],match_id[gi],free_any[gi],free_id[gi],reuse_any[gi],reuse_id[gi],reuse_area[gi],match_area[gi],match_l[gi],match_r[gi],match_t[gi],match_b[gi]}={calc_match_any,calc_match_id,calc_free_any,calc_free_id,calc_reuse_any,calc_reuse_id,calc_reuse_area,calc_match_area,calc_match_l,calc_match_r,calc_match_t,calc_match_b};
   end

  end
 endgenerate
 assign ml=match_any[1]&&match_l[1]<held_run0?match_l[1]:held_run0;
 assign mr=match_any[1]&&match_r[1]>held_run1?match_r[1]:held_run1;
 assign mt=match_any[1]&&match_t[1]<held_y?match_t[1]:held_y;
 assign mb=match_any[1]&&match_b[1]>held_y?match_b[1]:held_y;
 assign ma=held_len+match_area[1];
 always @* begin
  if(match_any[1]) found=match_id[1];
  else if(free_any[1]) found=free_id[1];
  else if(reuse_any[1]) found=reuse_id[1];
  else found=-1;
 end
integer a;
always @(posedge cam_clk or negedge cam_reset_n) begin
 if(!cam_reset_n) begin
  x<=0;y<=0;vs_d<=0;href_d<=0;run0<=0;run1<=0;run_len<=0;run_color<=0;cv<=0;
  for(a=0;a<NCOMP;a=a+1) begin
   cc[a]<=0;cx0[a]<=0;cx1[a]<=0;cy0[a]<=0;cy1[a]<=0;ca[a]<=0;last_y[a]<=0;
  end
 end else begin
  vs_d<=frame_vsync;href_d<=frame_href;
  if(frame_vsync) begin x<=0;y<=0;end
  else if(row_end) begin x<=0;y<=y+1'b1;end
  else if(valid_pixel) x<=x+1'b1;
  if(snapshot_end)cv<=0;
  else if(merge_pipe[1]&&(merged_id>=0))begin
    for(a=0;a<NCOMP;a=a+1)if(merged_mask[a])cv[a]<=0;
    cv[merged_id]<=1;cc[merged_id]<=merged_color;
    cx0[merged_id]<=merged_l;cx1[merged_id]<=merged_r;cy0[merged_id]<=merged_t;cy1[merged_id]<=merged_b;
    ca[merged_id]<=merged_area;last_y[merged_id]<=merged_y;
  end
  if(frame_end) begin run_len<=0;run_color<=0;end
  else begin
   if(row_end) begin run_len<=0;run_color<=0;end
   else if(valid_pixel) begin
    if(label==0) begin run_len<=0;run_color<=0;end
    else if((run_len!=0)&&(label==run_color)) begin run_len<=run_len+1'b1;run1<=x;end
    else begin run0<=x;run1<=x;run_len<=1;run_color<=label;end
   end
  end
 end
end
 // Snapshot all components before CCL resets for the next frame. A two-pass,
 // 64-clock selector reserves the largest blue component for the car, then
 // takes the largest fifteen remaining components irrespective of color.
 // With no blue component, all sixteen slots are available to other colors.
 localparam [2:0] SEL_IDLE=0,SEL_BLUE=1,SEL_INIT=2,SEL_SORT=3,SEL_OUT=4;
 reg [2:0] sel_state;
 reg [4:0] sel_idx,blue_idx;
 reg blue_found;
 reg [19:0] blue_area;
 reg [NCOMP-1:0] snap_valid;
 reg [2:0] snap_color[0:NCOMP-1];
 reg [19:0] snap_area[0:NCOMP-1];
 reg [10:0] snap_x0[0:NCOMP-1],snap_x1[0:NCOMP-1];
 reg [10:0] snap_y0[0:NCOMP-1],snap_y1[0:NCOMP-1];
 reg [15:0] top_valid;
 reg [4:0] top_idx[0:15];
 reg [19:0] top_area[0:15];
 reg [19:0] area[0:15];
 reg [2:0] color[0:15];
 reg [10:0] ax0[0:15],ax1[0:15],ay0[0:15],ay1[0:15];
 reg [2:0] finish_pipe;
 integer fp,rank;
 integer insert_pos;
 always @* begin
  insert_pos=16;
  if(snap_valid[sel_idx]&&!(blue_found&&(sel_idx==blue_idx)))
   for(rank=15;rank>=0;rank=rank-1)
    if((rank>=((blue_found)?1:0))&&
       (!top_valid[rank]||(snap_area[sel_idx]>top_area[rank])))
      insert_pos=rank;
 end
 always @(posedge cam_clk or negedge cam_reset_n) begin
  if(!cam_reset_n) begin
   sel_state<=SEL_IDLE;sel_idx<=0;blue_idx<=0;blue_found<=0;blue_area<=0;
   snap_valid<=0;top_valid<=0;finish_pipe<=0;
   for(fp=0;fp<NCOMP;fp=fp+1)begin
    snap_color[fp]<=0;snap_area[fp]<=0;
    snap_x0[fp]<=0;snap_x1[fp]<=0;snap_y0[fp]<=0;snap_y1[fp]<=0;
   end
   for(fp=0;fp<16;fp=fp+1)begin
    top_idx[fp]<=0;top_area[fp]<=0;area[fp]<=0;color[fp]<=0;
    ax0[fp]<=0;ax1[fp]<=0;ay0[fp]<=0;ay1[fp]<=0;
   end
  end else begin
   finish_pipe<={finish_pipe[1:0],sel_state==SEL_OUT};
   case(sel_state)
    SEL_IDLE:if(snapshot_end)begin
     for(fp=0;fp<NCOMP;fp=fp+1)begin
      snap_valid[fp]<=cv[fp]&&(ca[fp]!=0)&&
                       (!FILTER_GEOMETRY||geometry_ok[fp]);
      snap_color[fp]<=cc[fp];snap_area[fp]<=ca[fp];
      snap_x0[fp]<=cx0[fp];snap_x1[fp]<=cx1[fp];
      snap_y0[fp]<=cy0[fp];snap_y1[fp]<=cy1[fp];
     end
     blue_found<=0;blue_area<=0;blue_idx<=0;sel_idx<=0;sel_state<=SEL_BLUE;
    end
    SEL_BLUE:begin
     if(snap_valid[sel_idx]&&(snap_color[sel_idx]==1)&&
        (!blue_found||(snap_area[sel_idx]>blue_area)))begin
      blue_found<=1;blue_idx<=sel_idx;blue_area<=snap_area[sel_idx];
     end
     if(sel_idx==NCOMP-1)sel_state<=SEL_INIT;
     else sel_idx<=sel_idx+1'b1;
    end
    SEL_INIT:begin
     for(fp=0;fp<16;fp=fp+1)begin top_valid[fp]<=0;top_idx[fp]<=0;top_area[fp]<=0;end
     if(blue_found)begin top_valid[0]<=1;top_idx[0]<=blue_idx;top_area[0]<=blue_area;end
     sel_idx<=0;sel_state<=SEL_SORT;
    end
    SEL_SORT:begin
     if(insert_pos<16)begin
      for(fp=15;fp>0;fp=fp-1)if(fp>insert_pos)begin
       top_valid[fp]<=top_valid[fp-1];
       top_idx[fp]<=top_idx[fp-1];
       top_area[fp]<=top_area[fp-1];
      end
      top_valid[insert_pos]<=1;
      top_idx[insert_pos]<=sel_idx;
      top_area[insert_pos]<=snap_area[sel_idx];
     end
     if(sel_idx==NCOMP-1)sel_state<=SEL_OUT;
     else sel_idx<=sel_idx+1'b1;
    end
    SEL_OUT:begin
     for(fp=0;fp<16;fp=fp+1)begin
      area[fp]<=top_valid[fp]?top_area[fp]:0;
      color[fp]<=top_valid[fp]?snap_color[top_idx[fp]]:0;
      ax0[fp]<=top_valid[fp]?snap_x0[top_idx[fp]]:0;
      ax1[fp]<=top_valid[fp]?snap_x1[top_idx[fp]]:0;
      ay0[fp]<=top_valid[fp]?snap_y0[top_idx[fp]]:0;
      ay1[fp]<=top_valid[fp]?snap_y1[top_idx[fp]]:0;
     end
     sel_state<=SEL_IDLE;
    end
    default:sel_state<=SEL_IDLE;
   endcase
  end
 end

function [10:0] low_pad;
 input [10:0] v;
 begin low_pad=(v>PAD)?v-PAD:0;end
endfunction
function [10:0] high_x;
 input [10:0] v;
 begin high_x=(v+PAD<H_ACTIVE)?v+PAD:H_ACTIVE-1;end
endfunction
function [10:0] high_y;
 input [10:0] v;
 begin high_y=(v+PAD<V_ACTIVE)?v+PAD:V_ACTIVE-1;end
endfunction
function overlap;
 input [10:0] l0,r0,t0,b0,l1,r1,t1,b1;
 begin overlap=(l0<=r1)&&(r0>=l1)&&(t0<=b1)&&(b0>=t1);end
endfunction

// Tracking uses camera coordinates. Only a visibly shrunken stationary block
// contained in its old bounds may reuse those bounds during car contact.
// Car geometry always uses the current qualified color component.
reg [15:0] tv,observed,estimated;
reg [2:0] tracked_color[0:15];
reg [10:0] tx0[0:15],tx1[0:15],ty0[0:15],ty1[0:15];

reg [7:0] missed[0:15];
reg [15:0] good;
reg [10:0] nx0[0:15],nx1[0:15],ny0[0:15],ny1[0:15];
reg [15:0] nv,no,ne;
reg contact,car_contact;
integer c,d;
reg signed [12:0] left_i,right_i,top_i,bottom_i,w_i,h_i;
always @* begin
 for(c=0;c<16;c=c+1) begin
  good[c]=(area[c]>=MIN_AREA)&&(ax1[c]>=ax0[c]+MIN_SIDE-1)&&
          (ay1[c]>=ay0[c]+MIN_SIDE-1);
  nx0[c]=tx0[c];nx1[c]=tx1[c];ny0[c]=ty0[c];ny1[c]=ty1[c];
 end
 nv=tv;no=good;ne=0;car_contact=0;contact=0;
 for(c=0;c<16;c=c+1) begin
  if(good[c]) begin
   nx0[c]=low_pad(ax0[c]);nx1[c]=high_x(ax1[c]);
   ny0[c]=low_pad(ay0[c]);ny1[c]=high_y(ay1[c]);nv[c]=1;
  end else begin
   ne[c]=tv[c];
   if(missed[c]>=HOLD_FRAMES) nv[c]=0;
  end
 end
 for(d=1;d<16;d=d+1) begin
  // Only reconstruct a visibly shrunken, overlapping stationary block.
  // A full-size moved block must always use its current CCL geometry.
  contact=tv[d]&&good[d]&&good[0]&&(color[0]==1)&&
   (tracked_color[d]==color[d])&&
   overlap(ax0[d],ax1[d],ay0[d],ay1[d],tx0[d],tx1[d],ty0[d],ty1[d])&&
   overlap(nx0[0],nx1[0],ny0[0],ny1[0],tx0[d],tx1[d],ty0[d],ty1[d])&&
   (ax0[d]>=tx0[d])&&(ax1[d]<=tx1[d])&&(ay0[d]>=ty0[d])&&(ay1[d]<=ty1[d])&&
   (((ax1[d]-ax0[d]+2)<(tx1[d]-tx0[d]))||((ay1[d]-ay0[d]+2)<(ty1[d]-ty0[d])));
  if(contact) begin
   car_contact=1;
   nx0[d]=tx0[d];nx1[d]=tx1[d];ny0[d]=ty0[d];ny1[d]=ty1[d];ne[d]=1;
  end
 end

end
reg [15:0] stage_good,stage_nv,stage_no,stage_ne;
reg stage_contact;
reg [10:0] stage_x0[0:15],stage_x1[0:15],stage_y0[0:15],stage_y1[0:15];
integer st;
always @(posedge cam_clk or negedge cam_reset_n) begin
 if(!cam_reset_n)begin stage_good<=0;stage_nv<=0;stage_no<=0;stage_ne<=0;stage_contact<=0;
 for(st=0;st<16;st=st+1)begin stage_x0[st]<=0;stage_x1[st]<=0;stage_y0[st]<=0;stage_y1[st]<=0;end
 end else if(finish_pipe[0])begin
 stage_good<=good;stage_nv<=nv;stage_no<=no;stage_ne<=ne;stage_contact<=car_contact;
 for(st=0;st<16;st=st+1)begin stage_x0[st]<=nx0[st];stage_x1[st]<=nx1[st];stage_y0[st]<=ny0[st];stage_y1[st]<=ny1[st];end
 end
end
reg [10:0] ex0[0:15],ex1[0:15],ey0[0:15],ey1[0:15];
reg [15:0] ene;
integer e;
always @* begin
 for(e=0;e<16;e=e+1)begin ex0[e]=stage_x0[e];ex1[e]=stage_x1[e];ey0[e]=stage_y0[e];ey1[e]=stage_y1[e];end
 ene=stage_ne;
 left_i=0;right_i=0;top_i=0;bottom_i=0;w_i=0;h_i=0;

end
integer t;
always @(posedge cam_clk or negedge cam_reset_n) begin
 if(!cam_reset_n) begin
  tv<=0;observed<=0;estimated<=0;
  for(t=0;t<16;t=t+1) begin tx0[t]<=0;tx1[t]<=0;ty0[t]<=0;ty1[t]<=0;missed[t]<=0;tracked_color[t]<=0;end
 end else if(finish_pipe[1]) begin
  tv<=stage_nv;observed<=stage_no&stage_nv;estimated<=ene&stage_nv;
  for(t=0;t<16;t=t+1) begin
   tx0[t]<=ex0[t];tx1[t]<=ex1[t];ty0[t]<=ey0[t];ty1[t]<=ey1[t];
   if(stage_good[t]) tracked_color[t]<=color[t];
   if(stage_good[t]) missed[t]<=0;
   else if(missed[t]<255) missed[t]<=missed[t]+1'b1;
  end

 end
end

// Bundled-data request/acknowledge mailbox. Camera snapshot stays stable until
// display acknowledges it. All sixteen boxes transfer atomically.
reg req,ack;
(* ASYNC_REG="TRUE" *) reg [1:0] ack_s,req_s;
reg snapshot_pending;
reg [15:0] sv,so,se;
reg [175:0] sx0,sx1,sy0,sy1;
reg [47:0] sc;
reg [15:0] sid;
integer s;
always @(posedge cam_clk or negedge cam_reset_n) begin
 if(!cam_reset_n) begin
  req<=0;ack_s<=0;snapshot_pending<=0;sv<=0;so<=0;se<=0;
  sx0<=0;sx1<=0;sy0<=0;sy1<=0;sc<=0;sid<=0;
 end else begin
  ack_s<={ack_s[0],ack};
  if(finish_pipe[2]) snapshot_pending<=1;
  else if(snapshot_pending&&(req==ack_s[1])) begin
   sv<=tv;so<=observed;se<=estimated;sid<=cam_frame_id;
   for(s=0;s<16;s=s+1) begin
    sx0[s*11+:11]<=tx0[s];sx1[s*11+:11]<=tx1[s];
    sy0[s*11+:11]<=ty0[s];sy1[s*11+:11]<=ty1[s];
    sc[s*3+:3]<=tracked_color[s];
   end
   req<=~req;snapshot_pending<=0;
  end
 end
end
integer p;
always @(posedge pixel_clk or negedge pixel_reset_n) begin
 if(!pixel_reset_n) begin
  req_s<=0;ack<=0;roi_frame_id<=0;roi_valid<=0;roi_observed<=0;roi_estimated<=0;
  roi_x0<=0;roi_x1<=0;roi_y0<=0;roi_y1<=0;roi_color<=0;
  frame_pulse<=0;center_valid<=0;center_x<=0;center_y<=0;
 end else begin
  req_s<={req_s[0],req};frame_pulse<=0;
  if(req_s[1]!=ack) begin
   roi_frame_id<=sid;roi_valid<=sv;roi_observed<=so;roi_estimated<=se;
   roi_x0<=sx0;roi_x1<=sx1;roi_y0<=sy0;roi_y1<=sy1;roi_color<=sc;
   center_valid<=sv[0]&&(sc[2:0]==3'd1);
   center_x<=({1'b0,sx0[0+:11]}+sx1[0+:11])>>1;
   center_y<=({1'b0,sy0[0+:11]}+sy1[0+:11])>>1;
   ack<=req_s[1];frame_pulse<=1;
  end
 end
end
always @* begin
 // Standalone tracker preview. The integrated design leaves hdmi_data
 // unconnected and draws classified boxes in cnn_class_overlay instead.
 hdmi_data=rd_data;
 for(p=0;p<16;p=p+1) begin
  if(roi_valid[p]&&
    (((pixel_ypos==roi_y0[p*11+:11]||pixel_ypos==roi_y1[p*11+:11])&&
       pixel_xpos>=roi_x0[p*11+:11]&&pixel_xpos<=roi_x1[p*11+:11])||
     ((pixel_xpos==roi_x0[p*11+:11]||pixel_xpos==roi_x1[p*11+:11])&&
       pixel_ypos>=roi_y0[p*11+:11]&&pixel_ypos<=roi_y1[p*11+:11]))) hdmi_data=BOX_RGB;
 end
end
endmodule

