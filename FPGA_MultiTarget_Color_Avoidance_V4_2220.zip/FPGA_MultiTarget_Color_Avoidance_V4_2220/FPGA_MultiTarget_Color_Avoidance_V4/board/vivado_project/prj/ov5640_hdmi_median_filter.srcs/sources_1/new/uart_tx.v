`timescale 1ns/1ps

module uart_tx #(
    parameter integer CLK_FREQ = 65_000_000,
    parameter integer UART_BPS = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       uart_tx_en,
    input  wire [7:0] uart_tx_data,
    output reg        uart_txd,
    output reg        uart_tx_busy
);
    localparam integer BAUD_DIV = CLK_FREQ / UART_BPS;

    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [7:0]  tx_shift;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            uart_txd      <= 1'b1;
            uart_tx_busy  <= 1'b0;
            baud_cnt      <= 16'd0;
            bit_idx       <= 4'd0;
            tx_shift      <= 8'd0;
        end else if (!uart_tx_busy) begin
            uart_txd <= 1'b1;
            if (uart_tx_en) begin
                tx_shift     <= uart_tx_data;
                uart_tx_busy <= 1'b1;
                uart_txd     <= 1'b0;
                baud_cnt     <= 16'd0;
                bit_idx      <= 4'd0;
            end
        end else if (baud_cnt == BAUD_DIV - 1) begin
            baud_cnt <= 16'd0;
            if (bit_idx == 4'd9) begin
                uart_tx_busy <= 1'b0;
                uart_txd     <= 1'b1;
            end else begin
                bit_idx <= bit_idx + 4'd1;
                if (bit_idx < 4'd8)
                    uart_txd <= tx_shift[bit_idx[2:0]];
                else
                    uart_txd <= 1'b1;
            end
        end else begin
            baud_cnt <= baud_cnt + 16'd1;
        end
    end
endmodule
