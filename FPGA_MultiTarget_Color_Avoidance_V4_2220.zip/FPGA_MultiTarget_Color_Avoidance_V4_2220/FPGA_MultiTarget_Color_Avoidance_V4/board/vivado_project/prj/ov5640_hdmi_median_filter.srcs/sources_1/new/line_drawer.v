module line_drawer #(
    parameter [19:0] BMP_ADDR_MAX = 20'd786431   // 位图地址上限 = 1024*768 - 1
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        start,          // 1拍脉冲：开始画线
    input  wire [9:0]  x0, y0,         // 起点（位图坐标）
    input  wire [9:0]  x1, y1,         // 终点
    output reg         busy,
    output reg         done,

    output reg  [19:0] bmp_addr,
    output reg         bmp_wdata,
    output reg         bmp_wen,

    input  wire        clear,
    output reg         clear_done
);

    localparam [2:0] S_IDLE  = 3'd0;
    localparam [2:0] S_INIT  = 3'd1;
    localparam [2:0] S_DRAW  = 3'd2;
    localparam [2:0] S_CLEAR = 3'd3;
    localparam [2:0] S_DONE  = 3'd4;

    reg [2:0] state;

    // ===== dx/dy 符号和绝对值（组合）=====
    wire signed [10:0] dx_s = $signed({1'b0, x1}) - $signed({1'b0, x0});
    wire signed [10:0] dy_s = $signed({1'b0, y1}) - $signed({1'b0, y0});
    wire [9:0] adx_w = dx_s[10] ? (~dx_s[9:0] + 1'b1) : dx_s[9:0];
    wire [9:0] ady_w = dy_s[10] ? (~dy_s[9:0] + 1'b1) : dy_s[9:0];
    wire       sx_neg_w = dx_s[10];
    wire       sy_neg_w = dy_s[10];
    wire       x_major_w = (adx_w >= ady_w);

    // ===== Bresenham 寄存器 =====
    reg [9:0]         cur_x, cur_y;
    reg [9:0]         adx, ady;
    reg               sx_neg, sy_neg, x_major;
    reg signed [12:0] err, add_flat, add_diag;
    reg [10:0]        step_cnt;

    // ===== 清零 =====
    reg [19:0] clear_addr;
    reg        from_clear;

    // ===== 组合逻辑：前进后的点 =====
    reg [9:0]         nxt_x, nxt_y;
    reg signed [12:0] nxt_err;
    always @(*) begin
        if (x_major) begin
            nxt_x = sx_neg ? (cur_x - 1'b1) : (cur_x + 1'b1);
            if (err > 0) begin
                nxt_y = sy_neg ? (cur_y - 1'b1) : (cur_y + 1'b1);
                nxt_err = err + add_diag;
            end else begin
                nxt_y = cur_y;
                nxt_err = err + add_flat;
            end
        end else begin
            nxt_y = sy_neg ? (cur_y - 1'b1) : (cur_y + 1'b1);
            if (err > 0) begin
                nxt_x = sx_neg ? (cur_x - 1'b1) : (cur_x + 1'b1);
                nxt_err = err + add_diag;
            end else begin
                nxt_x = cur_x;
                nxt_err = err + add_flat;
            end
        end
    end

    // ===== 主状态机 =====
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_IDLE;
            busy <= 1'b0; done <= 1'b0; clear_done <= 1'b0;
            bmp_wen <= 1'b0; bmp_addr <= 20'd0; bmp_wdata <= 1'b0;
            from_clear <= 1'b0;
        end else begin
            done <= 1'b0;
            clear_done <= 1'b0;
            bmp_wen <= 1'b0;

            case (state)
                S_IDLE: begin
                    busy <= 1'b0;
                    if (clear) begin
                        state <= S_CLEAR;
                        clear_addr <= 20'd0;
                        from_clear <= 1'b1;
                        busy <= 1'b1;
                    end else if (start) begin
                        state <= S_INIT;
                        from_clear <= 1'b0;
                        busy <= 1'b1;
                    end
                end

                S_INIT: begin
                    adx <= adx_w;
                    ady <= ady_w;
                    sx_neg <= sx_neg_w;
                    sy_neg <= sy_neg_w;
                    x_major <= x_major_w;
                    cur_x <= x0;
                    cur_y <= y0;

                    if (x_major_w) begin
                        err      <= $signed({2'b00, ady_w, 1'b0}) - $signed({3'b000, adx_w});
                        add_flat <= $signed({2'b00, ady_w, 1'b0});
                        add_diag <= $signed({2'b00, ady_w, 1'b0}) - $signed({2'b00, adx_w, 1'b0});
                        step_cnt <= {1'b0, adx_w};
                    end else begin
                        err      <= $signed({2'b00, adx_w, 1'b0}) - $signed({3'b000, ady_w});
                        add_flat <= $signed({2'b00, adx_w, 1'b0});
                        add_diag <= $signed({2'b00, adx_w, 1'b0}) - $signed({2'b00, ady_w, 1'b0});
                        step_cnt <= {1'b0, ady_w};
                    end
                    state <= S_DRAW;
                end

                S_DRAW: begin
                    // 画轨迹点
                    bmp_addr <= {cur_y, cur_x};
                    bmp_wdata <= 1'b1;
                    bmp_wen <= 1'b1;

                    if (step_cnt == 0) begin
                        state <= S_DONE;          // 终点画完
                    end else begin
                        cur_x <= nxt_x;
                        cur_y <= nxt_y;
                        err <= nxt_err;
                        step_cnt <= step_cnt - 1'b1;
                    end
                end

                S_CLEAR: begin
                    bmp_addr <= clear_addr;
                    bmp_wdata <= 1'b0;
                    bmp_wen <= 1'b1;
                    if (clear_addr == BMP_ADDR_MAX) begin
                        state <= S_DONE;
                    end else begin
                        clear_addr <= clear_addr + 1'b1;
                    end
                end

                S_DONE: begin
                    busy <= 1'b0;
                    if (from_clear)
                        clear_done <= 1'b1;
                    else
                        done <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule