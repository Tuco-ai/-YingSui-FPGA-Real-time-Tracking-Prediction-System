`timescale 1ns/1ps

module uart_rx #(
    parameter integer CLK_FREQ = 65_000_000,
    parameter integer UART_BPS = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       uart_rxd,
    output reg        uart_rx_done,
    output reg  [7:0] uart_rx_data
);
    localparam integer BAUD_DIV = CLK_FREQ / UART_BPS;

    (* ASYNC_REG = "TRUE" *) reg [1:0] uart_sync;
    reg        rx_busy;
    reg        start_sampled;
    reg [15:0] baud_cnt;
    reg [3:0]  bit_idx;
    reg [7:0]  rx_shift;

    wire start_bit = uart_sync[1] && !uart_sync[0] && !rx_busy;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            uart_sync    <= 2'b11;
            rx_busy      <= 1'b0;
            start_sampled <= 1'b0;
            baud_cnt     <= 16'd0;
            bit_idx      <= 4'd0;
            rx_shift     <= 8'd0;
            uart_rx_done <= 1'b0;
            uart_rx_data <= 8'd0;
        end else begin
            uart_sync    <= {uart_sync[0], uart_rxd};
            uart_rx_done <= 1'b0;

            if (start_bit) begin
                rx_busy  <= 1'b1;
                start_sampled <= 1'b0;
                baud_cnt <= BAUD_DIV / 2;
                bit_idx  <= 4'd0;
            end else if (rx_busy) begin
                if (baud_cnt == BAUD_DIV - 1) begin
                    baud_cnt <= 16'd0;
                    if (!start_sampled) begin
                        // First centre sample belongs to the start bit.
                        start_sampled <= 1'b1;
                    end else if (bit_idx < 4'd8) begin
                        rx_shift[bit_idx[2:0]] <= uart_sync[1];
                        bit_idx <= bit_idx + 4'd1;
                    end else begin
                        rx_busy      <= 1'b0;
                        uart_rx_done <= 1'b1;
                        uart_rx_data <= rx_shift;
                    end
                end else begin
                    baud_cnt <= baud_cnt + 16'd1;
                end
            end
        end
    end
endmodule
