// Single-owner dual-clock frame store. Metadata must match the stored camera
// frame ID; the camera cannot overwrite RAM until all sixteen ROIs are loaded.
module cnn_frame_roi_loader #(parameter H_ACTIVE=1024,V_ACTIVE=768)(
 input wire cam_clk,clk,rst_n,frame_vsync,frame_href,frame_de,
 input wire [15:0] frame_rgb,
 input wire [15:0] candidate_frame_id,
 input wire [15:0] candidate_observed,cnn_busy,
 input wire [175:0] x0,x1,y0,y1,
 input wire [127:0] generations,
 output reg [15:0] load_we,start,loaded_mask,
 output reg [9:0] load_addr,
 output reg signed [7:0] load_data,
 output reg loaded,
 output reg [127:0] loaded_generations,
 output reg [15:0] loaded_frame_id
);
 wire cam_reset_n,pixel_reset_n;
 reset_release_sync cr(.clk(cam_clk),.arst_n(rst_n),.srst_n(cam_reset_n));
 reset_release_sync pr(.clk(clk),.arst_n(rst_n),.srst_n(pixel_reset_n));
 localparam PIXELS=H_ACTIVE*V_ACTIVE,AW=$clog2(PIXELS);
 (* ram_style="block" *) reg [7:0] frame_gray[0:PIXELS-1];
 reg [10:0] x,y;
 reg vs_d,href_d,started,enabled,seen_vsync;
 reg [AW:0] count;
 reg [AW-1:0] write_addr;
 reg [15:0] sequence_id,buffer_id;
 reg request,ack;
 (* ASYNC_REG="TRUE" *) reg [1:0] ack_sync,request_sync;
 wire locked=request!=ack_sync[1];
 wire frame_end=frame_vsync&&!vs_d;
 wire row_end=href_d&&!frame_href;
 wire valid_pixel=frame_href&&frame_de&&!frame_vsync&&(x<H_ACTIVE)&&(y<V_ACTIVE);
 wire [7:0] r={frame_rgb[15:11],frame_rgb[15:13]};
 wire [7:0] g={frame_rgb[10:5],frame_rgb[10:9]};
 wire [7:0] b={frame_rgb[4:0],frame_rgb[4:2]};
 wire [15:0] gray_sum=16'd77*r+16'd150*g+16'd29*b+16'd128;
 // RAM ports intentionally have no reset (BRAM inference).
 always @(posedge cam_clk)
  if(cam_reset_n&&valid_pixel&&enabled&&!locked)frame_gray[write_addr]<=gray_sum[15:8];
 always @(posedge cam_clk or negedge cam_reset_n)begin
  if(!cam_reset_n)begin
   x<=0;y<=0;vs_d<=0;href_d<=0;started<=0;enabled<=0;seen_vsync<=0;
   count<=0;write_addr<=0;sequence_id<=0;buffer_id<=0;request<=0;ack_sync<=0;
  end else begin
   vs_d<=frame_vsync;href_d<=frame_href;ack_sync<={ack_sync[0],ack};
   if(frame_vsync)begin x<=0;y<=0;end
   else if(row_end)begin x<=0;y<=y+1'b1;end
   else if(valid_pixel)x<=x+1'b1;
   // Rearm only before the first active pixel. An ack during an active
   // frame does not permit capturing the tail of that frame.
   if(seen_vsync&&!started&&!valid_pixel&&!locked)enabled<=1;
   if(valid_pixel)begin
    started<=1;
    if(enabled&&!locked)begin count<=count+1'b1;write_addr<=write_addr+1'b1;end
   end
   if(frame_end)begin
    sequence_id<=sequence_id+1'b1;seen_vsync<=1;started<=0;
    enabled<=0;count<=0;write_addr<=0;
    if(enabled&&!locked&&(count==PIXELS))begin
     buffer_id<=sequence_id+1'b1;request<=~request;
    end
   end
  end
 end
 localparam IDLE=0,SELECT=1,GEOMETRY=2,CLAMP=3,ADDRESS=4,READ=5,SEND=6,NEXT=7,LAUNCH=8,WAIT_META=9;
 reg [3:0] state;
 reg [15:0] mask;
 reg [3:0] slot;
 reg [175:0] bx0,bx1,by0,by1;
 reg [9:0] index;
 reg [15:0] captured_buffer_id;
 reg [11:0] width,height,cx,cy;
 reg [10:0] side,left,top;
 reg [1:0] shift;
 reg [8:0] sample_side;
 reg [AW-1:0] read_addr;
 reg [7:0] read_data;
 wire [11:0] long_side=width>=height?width:height;
 wire [11:0] expanded=long_side+(long_side>>3);
 wire [10:0] next_side=expanded>V_ACTIVE?V_ACTIVE:expanded<12?11'd12:expanded[10:0];
 wire [1:0] next_shift=next_side>512?2'd2:next_side>256?2'd1:2'd0;
 wire [11:0] un_left=cx>(side>>1)?cx-(side>>1):12'd0;
 wire [11:0] un_top=cy>(side>>1)?cy-(side>>1):12'd0;
 wire [13:0] sample_x=index[4:0]*sample_side,sample_y=index[9:5]*sample_side;
 wire [10:0] sx=left+({3'b0,sample_x[12:5]}<<shift);
 wire [10:0] sy=top+({3'b0,sample_y[12:5]}<<shift);
 wire signed [15:0] metadata_age=candidate_frame_id-captured_buffer_id;
 always @(posedge clk)if(state==READ)read_data<=frame_gray[read_addr];
 always @(posedge clk or negedge pixel_reset_n)begin
  if(!pixel_reset_n)begin
   request_sync<=0;ack<=0;captured_buffer_id<=0;state<=IDLE;slot<=0;mask<=0;index<=0;
   bx0<=0;bx1<=0;by0<=0;by1<=0;width<=0;height<=0;cx<=0;cy<=0;
   side<=12;left<=0;top<=0;shift<=0;sample_side<=12;read_addr<=0;
   load_we<=0;load_addr<=0;load_data<=0;start<=0;loaded<=0;
   loaded_mask<=0;loaded_generations<=0;loaded_frame_id<=0;
  end else begin
   request_sync<={request_sync[0],request};load_we<=0;start<=0;loaded<=0;
   case(state)
    IDLE:if(request_sync[1]!=ack)begin
     // Bundled data is captured only after the synchronized request arrives.
     // Compare frame IDs one clock later, entirely within the pixel domain.
     captured_buffer_id<=buffer_id;state<=WAIT_META;
    end
    WAIT_META:begin
     if(metadata_age>0)begin ack<=request_sync[1];state<=IDLE;end // stale mailbox: skip safely
     else if((metadata_age==0)&&!(|cnn_busy))begin
      bx0<=x0;bx1<=x1;by0<=y0;by1<=y1;mask<=candidate_observed;
      loaded_generations<=generations;loaded_frame_id<=captured_buffer_id;
      slot<=0;state<=SELECT;
     end
    end
    SELECT:begin
     if(!mask[slot])state<=NEXT;
     else begin
      width<={1'b0,bx1[slot*11+:11]}-{1'b0,bx0[slot*11+:11]}+12'd1;
      height<={1'b0,by1[slot*11+:11]}-{1'b0,by0[slot*11+:11]}+12'd1;
      cx<=({1'b0,bx0[slot*11+:11]}+bx1[slot*11+:11])>>1;
      cy<=({1'b0,by0[slot*11+:11]}+by1[slot*11+:11])>>1;
      state<=GEOMETRY;
     end
    end
    GEOMETRY:begin side<=next_side;shift<=next_shift;state<=CLAMP;end
    CLAMP:begin
     left<=un_left>(H_ACTIVE-side)?H_ACTIVE-side:un_left[10:0];
     top<=un_top>(V_ACTIVE-side)?V_ACTIVE-side:un_top[10:0];
     sample_side<=({2'b0,side}+((13'd1<<shift)-13'd1))>>shift;
     index<=0;state<=ADDRESS;
    end
    ADDRESS:begin read_addr<=sy*H_ACTIVE+sx;state<=READ;end
    READ:state<=SEND;
    SEND:begin
     load_we[slot]<=1;load_addr<=index;load_data<=read_data^8'h80;
     if(index==1023)state<=NEXT;else begin index<=index+1'b1;state<=ADDRESS;end
    end
    NEXT:if(slot==15)state<=LAUNCH;else begin slot<=slot+1'b1;state<=SELECT;end
    LAUNCH:begin
     start<=mask;loaded<=1;loaded_mask<=mask;ack<=request_sync[1];state<=IDLE;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
