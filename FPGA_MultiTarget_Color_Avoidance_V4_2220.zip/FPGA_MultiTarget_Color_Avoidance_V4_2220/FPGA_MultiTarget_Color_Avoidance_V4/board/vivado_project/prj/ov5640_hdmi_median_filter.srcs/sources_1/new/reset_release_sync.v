`default_nettype none
module reset_release_sync(input wire clk,arst_n,output wire srst_n);
(* ASYNC_REG="TRUE" *) reg [2:0] sync_ff;
always @(posedge clk or negedge arst_n)
 if(!arst_n)sync_ff<=0;else sync_ff<={sync_ff[1:0],1'b1};
assign srst_n=sync_ff[2];
endmodule

`default_nettype wire
