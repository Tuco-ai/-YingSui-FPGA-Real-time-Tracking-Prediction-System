module cnn_class_overlay #(parameter H_ACTIVE=1024,V_ACTIVE=768)(
 input wire clk,rst_n,update,
 input wire [10:0] pixel_x,pixel_y,
 input wire [15:0] rgb_in,
 input wire [1:0] color_mode,
 input wire [15:0] observed,class_valid,
 input wire [31:0] classes,
 input wire [47:0] object_color,
 input wire [175:0] x0,x1,y0,y1,
 output reg [15:0] rgb_out,
 output wire overlay_hit,
 output reg [10:0] center_x,center_y,
 output reg center_valid
);
 reg [15:0] mode_mask;
 integer m;
 always @* begin
  mode_mask=0;
  for(m=0;m<16;m=m+1)
   mode_mask[m]=(color_mode==2'd3)||
    ((color_mode==2'd0)&&(object_color[m*3+:3]==3'd1))||
    ((color_mode==2'd1)&&(object_color[m*3+:3]==3'd2))||
    ((color_mode==2'd2)&&(object_color[m*3+:3]==3'd4));
 end
 function [4:0] glyph;
  input block_class;input [2:0] char_index,row;
  begin case({block_class,char_index,row})
    7'h00: glyph=5'h00;
    7'h01: glyph=5'h00;
    7'h02: glyph=5'h0e;
    7'h03: glyph=5'h10;
    7'h04: glyph=5'h10;
    7'h05: glyph=5'h10;
    7'h06: glyph=5'h0e;
    7'h08: glyph=5'h00;
    7'h09: glyph=5'h00;
    7'h0a: glyph=5'h0e;
    7'h0b: glyph=5'h01;
    7'h0c: glyph=5'h0f;
    7'h0d: glyph=5'h11;
    7'h0e: glyph=5'h0f;
    7'h10: glyph=5'h00;
    7'h11: glyph=5'h00;
    7'h12: glyph=5'h16;
    7'h13: glyph=5'h19;
    7'h14: glyph=5'h10;
    7'h15: glyph=5'h10;
    7'h16: glyph=5'h10;
    7'h40: glyph=5'h10;
    7'h41: glyph=5'h10;
    7'h42: glyph=5'h16;
    7'h43: glyph=5'h19;
    7'h44: glyph=5'h11;
    7'h45: glyph=5'h11;
    7'h46: glyph=5'h1e;
    7'h48: glyph=5'h0c;
    7'h49: glyph=5'h04;
    7'h4a: glyph=5'h04;
    7'h4b: glyph=5'h04;
    7'h4c: glyph=5'h04;
    7'h4d: glyph=5'h04;
    7'h4e: glyph=5'h0e;
    7'h50: glyph=5'h00;
    7'h51: glyph=5'h00;
    7'h52: glyph=5'h0e;
    7'h53: glyph=5'h11;
    7'h54: glyph=5'h11;
    7'h55: glyph=5'h11;
    7'h56: glyph=5'h0e;
    7'h58: glyph=5'h00;
    7'h59: glyph=5'h00;
    7'h5a: glyph=5'h0e;
    7'h5b: glyph=5'h10;
    7'h5c: glyph=5'h10;
    7'h5d: glyph=5'h10;
    7'h5e: glyph=5'h0e;
    7'h60: glyph=5'h10;
    7'h61: glyph=5'h10;
    7'h62: glyph=5'h12;
    7'h63: glyph=5'h14;
    7'h64: glyph=5'h18;
    7'h65: glyph=5'h14;
    7'h66: glyph=5'h12;
   default:glyph=0;
  endcase end
 endfunction
 function [4:0] destination_glyph;
  input [3:0] char_index;
  input [2:0] row;
  begin
   case(char_index)
    4'd0:case(row)
     3'd0:destination_glyph=5'h01;3'd1:destination_glyph=5'h01;
     3'd2:destination_glyph=5'h0f;3'd3:destination_glyph=5'h11;
     3'd4:destination_glyph=5'h11;3'd5:destination_glyph=5'h11;
     3'd6:destination_glyph=5'h0f;default:destination_glyph=5'h00;
    endcase
    4'd1:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0e;3'd3:destination_glyph=5'h11;
     3'd4:destination_glyph=5'h1f;3'd5:destination_glyph=5'h10;
     3'd6:destination_glyph=5'h0e;default:destination_glyph=5'h00;
    endcase
    4'd2:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0e;3'd3:destination_glyph=5'h10;
     3'd4:destination_glyph=5'h0e;3'd5:destination_glyph=5'h01;
     3'd6:destination_glyph=5'h1e;default:destination_glyph=5'h00;
    endcase
    4'd3:case(row)
     3'd0:destination_glyph=5'h04;3'd1:destination_glyph=5'h04;
     3'd2:destination_glyph=5'h1f;3'd3:destination_glyph=5'h04;
     3'd4:destination_glyph=5'h04;3'd5:destination_glyph=5'h04;
     3'd6:destination_glyph=5'h03;default:destination_glyph=5'h00;
    endcase
    4'd4:case(row)
     3'd0:destination_glyph=5'h04;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0c;3'd3:destination_glyph=5'h04;
     3'd4:destination_glyph=5'h04;3'd5:destination_glyph=5'h04;
     3'd6:destination_glyph=5'h0e;default:destination_glyph=5'h00;
    endcase
    4'd5:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h16;3'd3:destination_glyph=5'h19;
     3'd4:destination_glyph=5'h11;3'd5:destination_glyph=5'h11;
     3'd6:destination_glyph=5'h11;default:destination_glyph=5'h00;
    endcase
    4'd6:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0e;3'd3:destination_glyph=5'h01;
     3'd4:destination_glyph=5'h0f;3'd5:destination_glyph=5'h11;
     3'd6:destination_glyph=5'h0f;default:destination_glyph=5'h00;
    endcase
    4'd7:case(row)
     3'd0:destination_glyph=5'h04;3'd1:destination_glyph=5'h04;
     3'd2:destination_glyph=5'h1f;3'd3:destination_glyph=5'h04;
     3'd4:destination_glyph=5'h04;3'd5:destination_glyph=5'h04;
     3'd6:destination_glyph=5'h03;default:destination_glyph=5'h00;
    endcase
    4'd8:case(row)
     3'd0:destination_glyph=5'h04;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0c;3'd3:destination_glyph=5'h04;
     3'd4:destination_glyph=5'h04;3'd5:destination_glyph=5'h04;
     3'd6:destination_glyph=5'h0e;default:destination_glyph=5'h00;
    endcase
    4'd9:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h0e;3'd3:destination_glyph=5'h11;
     3'd4:destination_glyph=5'h11;3'd5:destination_glyph=5'h11;
     3'd6:destination_glyph=5'h0e;default:destination_glyph=5'h00;
    endcase
    4'd10:case(row)
     3'd0:destination_glyph=5'h00;3'd1:destination_glyph=5'h00;
     3'd2:destination_glyph=5'h16;3'd3:destination_glyph=5'h19;
     3'd4:destination_glyph=5'h11;3'd5:destination_glyph=5'h11;
     3'd6:destination_glyph=5'h11;default:destination_glyph=5'h00;
    endcase
    default:destination_glyph=5'h00;
   endcase
  end
 endfunction
 function [3:0] label_char_index;
  input [10:0] dx;
  begin
   if(dx>=11'd120)label_char_index=4'd10;
   else if(dx>=11'd108)label_char_index=4'd9;
   else if(dx>=11'd96)label_char_index=4'd8;
   else if(dx>=11'd84)label_char_index=4'd7;
   else if(dx>=11'd72)label_char_index=4'd6;
   else if(dx>=11'd60)label_char_index=4'd5;
   else if(dx>=11'd48)label_char_index=4'd4;
   else if(dx>=11'd36)label_char_index=4'd3;
   else if(dx>=11'd24)label_char_index=4'd2;
   else if(dx>=11'd12)label_char_index=4'd1;
   else label_char_index=4'd0;
  end
 endfunction
 function [7:0] label_char_base;
  input [3:0] character;
  begin
   case(character)
    4'd0:label_char_base=8'd0;
    4'd1:label_char_base=8'd12;
    4'd2:label_char_base=8'd24;
    4'd3:label_char_base=8'd36;
    4'd4:label_char_base=8'd48;
    4'd5:label_char_base=8'd60;
    4'd6:label_char_base=8'd72;
    4'd7:label_char_base=8'd84;
    4'd8:label_char_base=8'd96;
    4'd9:label_char_base=8'd108;
    default:label_char_base=8'd120;
   endcase
  end
 endfunction
 wire [15:0] hit,visible;
 wire [15:0] ink_pixel[0:15];
 wire [10:0] cx_out[0:15],cy_out[0:15];
 genvar q;
 generate for(q=0;q<16;q=q+1)begin: object
  reg valid0,valid1,valid2,en0,en1,active;
  reg [1:0] cls0,cls1,cls2;
  reg [1:0] label_kind0,label_kind1,label_kind2;
  reg [10:0] x0_reg,x1_reg,y0_reg,y1_reg;
  reg [10:0] left1,right1,top1,bottom1;
  reg [10:0] cx0_reg,cy0_reg,cx1_reg,cy1_reg,cx2_reg,cy2_reg;
  reg [10:0] left2,right2,top2,bottom2,label_x,label_y;
  wire [11:0] cx_sum={1'b0,x0[q*11+:11]}+{1'b0,x1[q*11+:11]};
  wire [11:0] cy_sum={1'b0,y0[q*11+:11]}+{1'b0,y1[q*11+:11]};
  wire is_destination=(color_mode==2'd3)&&(object_color[q*3+:3]==3'd4)&&
   observed[q]&&class_valid[q]&&(classes[q*2+:2]==2'd1);
  wire [11:0] panel_width1=(label_kind1==2'd0)?12'd36:
    ((label_kind1==2'd2)?12'd132:12'd60);
  wire [11:0] label_limit=H_ACTIVE-panel_width1;
  // Preserve the detector's rectangular bounds through the three blanking
  // stages. CNN ROI sampling remains square; only the displayed box changes.
  always @(posedge clk or negedge rst_n)begin
   if(!rst_n)begin
    valid0<=0;valid1<=0;valid2<=0;en0<=0;en1<=0;active<=0;cls0<=2;cls1<=2;cls2<=2;
    label_kind0<=1;label_kind1<=1;label_kind2<=1;
    x0_reg<=0;x1_reg<=0;y0_reg<=0;y1_reg<=0;
    left1<=0;right1<=0;top1<=0;bottom1<=0;
    left2<=0;right2<=0;top2<=0;bottom2<=0;label_x<=0;label_y<=0;
    cx0_reg<=0;cy0_reg<=0;cx1_reg<=0;cy1_reg<=0;cx2_reg<=0;cy2_reg<=0;
   end else begin
    valid0<=update;valid1<=valid0;valid2<=valid1;
    if(update)begin
     x0_reg<=x0[q*11+:11];x1_reg<=x1[q*11+:11];
     y0_reg<=y0[q*11+:11];y1_reg<=y1[q*11+:11];
     cx0_reg<=cx_sum[11:1];cy0_reg<=cy_sum[11:1];
     cls0<=classes[q*2+:2];
     label_kind0<=is_destination?2'd2:((classes[q*2+:2]==0)?2'd0:2'd1);
     en0<=observed[q]&&class_valid[q]&&mode_mask[q]&&(classes[q*2+:2]<2);
    end
    if(valid0)begin
     left1<=x0_reg;right1<=x1_reg;top1<=y0_reg;bottom1<=y1_reg;
     cls1<=cls0;label_kind1<=label_kind0;en1<=en0;cx1_reg<=cx0_reg;cy1_reg<=cy0_reg;
    end
    if(valid1)begin
     left2<=left1;right2<=right1;top2<=top1;bottom2<=bottom1;
     label_x<=({1'b0,left1}>label_limit)?label_limit[10:0]:left1;
     label_y<=top1>=18?top1-18:top1+2;
     cls2<=cls1;label_kind2<=label_kind1;active<=en1;cx2_reg<=cx1_reg;cy2_reg<=cy1_reg;
    end
   end
  end
  assign visible[q]=active&&observed[q]&&class_valid[q];
  assign cx_out[q]=cx2_reg;assign cy_out[q]=cy2_reg;
  wire [15:0] color_ink=cls2==0?16'h07e0:16'h0000;
  wire [11:0] panel_width2=(label_kind2==2'd0)?12'd36:
    ((label_kind2==2'd2)?12'd132:12'd60);
  wire [10:0] dx=pixel_x-label_x,dy=pixel_y-label_y;
  wire panel=visible[q]&&(pixel_x>=label_x)&&(pixel_y>=label_y)&&({1'b0,dx}<panel_width2)&&(dy<16);
  wire edge_pixel=visible[q]&&(pixel_x>=left2)&&(pixel_x<=right2)&&(pixel_y>=top2)&&(pixel_y<=bottom2)&&
    ((pixel_x<=left2+1'b1)||(pixel_x+1'b1>=right2)||(pixel_y<=top2+1'b1)||(pixel_y+1'b1>=bottom2));
  wire [3:0] character=label_char_index(dx);
  wire [7:0] local_x=dx[7:0]-label_char_base(character);
  wire [4:0] glyph_row=(label_kind2==2'd2)?
    destination_glyph(character,dy[3:1]):
    glyph(label_kind2==2'd1,character[2:0],dy[3:1]);
  wire letter=panel&&(local_x<10)&&(dy<14)&&glyph_row[4-local_x[3:1]];
  assign hit[q]=panel||edge_pixel;
  assign ink_pixel[q]=panel?(letter?16'h0000:16'hffff):color_ink;
 end endgenerate
 assign overlay_hit=|hit;
 integer priority_idx;
 always @* begin
  rgb_out=rgb_in;
  center_x=0;center_y=0;center_valid=|visible;
  for(priority_idx=15;priority_idx>=0;priority_idx=priority_idx-1)begin
   if(hit[priority_idx])rgb_out=ink_pixel[priority_idx];
   if(visible[priority_idx])begin center_x=cx_out[priority_idx];center_y=cy_out[priority_idx];end
  end
 end
endmodule
