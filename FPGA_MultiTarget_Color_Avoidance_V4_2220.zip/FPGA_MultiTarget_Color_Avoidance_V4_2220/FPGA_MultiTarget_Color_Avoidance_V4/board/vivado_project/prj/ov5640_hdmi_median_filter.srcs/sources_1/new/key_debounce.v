module key_debounce #(
    parameter CLK_FREQ      = 65_000_000,  // 时钟频率(Hz)，pixel_clk = 65MHz
    parameter DEBOUNCE_MS   = 20,          // 消抖时间(ms)
    parameter LONG_PRESS_MS = 1500         // 长按时间(ms)
)(
    input  wire clk,
    input  wire rst_n,
    input  wire key_in,            // 按键：按下=0，松开=1（正点原子按键按下是低电平）
    output reg  key_short_pulse,   // 短按脉冲（1 个时钟周期）
    output reg  key_long_pulse     // 长按脉冲（1 个时钟周期）
);

    // 先除后乘，避免中间值溢出；65MHz 是 1000 的整数倍，无截断误差
    localparam integer DEBOUNCE_CNT = CLK_FREQ / 1000 * DEBOUNCE_MS;      // 20ms
    localparam integer LONG_CNT     = CLK_FREQ / 1000 * LONG_PRESS_MS;    // 1.5s

    // 1) 两级同步：消除按键进来的亚稳态
    (* ASYNC_REG="TRUE" *) reg [1:0] key_sync;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            key_sync <= 2'b11;
        else
            key_sync <= {key_sync[0], key_in};
    end

    // 2) 消抖：电平变化后，连续稳定 DEBOUNCE_CNT 个周期才承认
    reg        key_stable;
    reg [31:0] deb_cnt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_stable <= 1'b1;
            deb_cnt    <= 32'd0;
        end else begin
            if (key_sync[1] != key_stable) begin
                if (deb_cnt == DEBOUNCE_CNT - 1) begin
                    key_stable <= key_sync[1];   // 稳定够了，更新
                    deb_cnt    <= 32'd0;
                end else begin
                    deb_cnt <= deb_cnt + 1'b1;
                end
            end else begin
                deb_cnt <= 32'd0;                 // 跳回去就重新计
            end
        end
    end

    // 3) 边沿检测：按下=下降沿，松开=上升沿
    reg key_stable_d;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            key_stable_d <= 1'b1;
        else
            key_stable_d <= key_stable;
    end
          wire key_press   = key_stable_d & ~key_stable;   // 下降沿 = 按下
    wire key_release = ~key_stable_d & key_stable;   // 上升沿 = 松开
    // 4) 按下计时 + 长短按判定
    reg [31:0] press_cnt;
    reg        long_triggered;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            press_cnt       <= 32'd0;
            long_triggered  <= 1'b0;
            key_short_pulse <= 1'b0;
            key_long_pulse  <= 1'b0;
        end else begin
            key_short_pulse <= 1'b0;
            key_long_pulse  <= 1'b0;

            if (key_press) begin
                press_cnt      <= 32'd0;      // 刚按下，清零计时
                long_triggered <= 1'b0;
            end else if (!key_stable) begin
                if (!long_triggered) begin
                    if (press_cnt == LONG_CNT - 1) begin
                        key_long_pulse <= 1'b1;    // 满 1.5s → 长按脉冲
                        long_triggered <= 1'b1;
                        press_cnt      <= 32'd0;
                    end else begin
                        press_cnt <= press_cnt + 1'b1;
                    end
                end
            end

            if (key_release) begin
                if (!long_triggered)
                    key_short_pulse <= 1'b1;      // 1.5s 内松开 → 短按脉冲
                press_cnt      <= 32'd0;
                long_triggered <= 1'b0;
            end
        end
    end

endmodule