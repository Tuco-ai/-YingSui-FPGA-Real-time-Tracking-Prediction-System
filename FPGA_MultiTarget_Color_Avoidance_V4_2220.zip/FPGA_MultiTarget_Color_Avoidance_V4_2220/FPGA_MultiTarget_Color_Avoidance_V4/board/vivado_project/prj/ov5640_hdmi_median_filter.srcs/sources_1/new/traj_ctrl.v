module traj_ctrl #(
    parameter [31:0] MAX_CNT = 32'd1_950_000_000,   // 65MHz x 30s
    parameter [31:0] SEC_CNT = 32'd65_000_000        // 65MHz x 1s
)(
    input  wire clk,
    input  wire rst_n,
    input  wire key_short_pulse,
    input  wire key_long_pulse,
    output wire [1:0] traj_state,
    output reg  recording,
    output reg  clear_traj,
    output reg  [5:0] time_sec     // 0~30, 当前记录秒数
);

    localparam [1:0] S_IDLE  = 2'd0;
    localparam [1:0] S_REC   = 2'd1;
    localparam [1:0] S_PAUSE = 2'd2;
    localparam [1:0] S_DONE  = 2'd3;

    reg [1:0]  state;
    reg [31:0] time_cnt;
    reg [25:0] sec_cnt;   // 26bit, 数到 65,000,000

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state      <= S_IDLE;
            time_cnt   <= 32'd0;
            sec_cnt    <= 26'd0;
            recording  <= 1'b0;
            clear_traj <= 1'b0;
            time_sec   <= 6'd0;
        end else begin
            clear_traj <= 1'b0;

            case (state)
                S_IDLE: begin
                    if (key_short_pulse) begin
                        state      <= S_REC;
                        time_cnt   <= 32'd0;
                        sec_cnt    <= 26'd0;
                        time_sec   <= 6'd0;
                        recording  <= 1'b1;
                        clear_traj <= 1'b1;
                    end
                end

                S_REC: begin
                    if (key_long_pulse) begin
                        state      <= S_IDLE;
                        time_cnt   <= 32'd0;
                        sec_cnt    <= 26'd0;
                        time_sec   <= 6'd0;
                        recording  <= 1'b0;
                        clear_traj <= 1'b1;
                    end else if (key_short_pulse) begin
                        state     <= S_PAUSE;
                        recording <= 1'b0;
                    end else if (time_cnt == MAX_CNT - 1) begin
                        state     <= S_DONE;
                        recording <= 1'b0;
                    end else begin
                        time_cnt <= time_cnt + 1'b1;
                        // 秒计时：每 1 秒 time_sec +1，最大 30
                        if (sec_cnt == SEC_CNT - 1) begin
                            sec_cnt <= 26'd0;
                            if (time_sec < 6'd30)
                                time_sec <= time_sec + 1'b1;
                        end else begin
                            sec_cnt <= sec_cnt + 1'b1;
                        end
                    end
                end

                S_PAUSE: begin
                    if (key_long_pulse) begin
                        state      <= S_IDLE;
                        time_cnt   <= 32'd0;
                        sec_cnt    <= 26'd0;
                        time_sec   <= 6'd0;
                        recording  <= 1'b0;
                        clear_traj <= 1'b1;
                    end else if (key_short_pulse) begin
                        state     <= S_REC;
                        recording <= 1'b1;
                    end
                end

                S_DONE: begin
                    if (key_long_pulse) begin
                        state      <= S_IDLE;
                        time_cnt   <= 32'd0;
                        sec_cnt    <= 26'd0;
                        time_sec   <= 6'd0;
                        recording  <= 1'b0;
                        clear_traj <= 1'b1;
                    end
                end

                default: state <= S_IDLE;
            endcase
        end
    end

    assign traj_state = state;

endmodule
