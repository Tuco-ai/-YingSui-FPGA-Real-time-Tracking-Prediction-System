`timescale 1ns/1ps
// A* path display adapter for the existing 1024x768 HDMI pixel pipeline.
// Replans on frame_pulse; streams a route from astar_grid_planner into a
// compact 64x48 array of connection directions, then draws straight dashed segments.
module astar_path_overlay (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        frame_pulse,
    input  logic        all_mode,
    input  logic        snapshot_pulse,
    input  logic        clear_pulse,
    input  logic        live_pulse,
    input  logic        start_valid,
    input  logic [10:0] start_x, start_y,
    input  logic [10:0] car_min_x, car_min_y, car_max_x, car_max_y,
    input  logic        goal_valid,
    input  logic [10:0] goal_x, goal_y,
    input  logic [15:0] obstacle_valid,
    input  logic [175:0] obstacle_x0, obstacle_y0, obstacle_x1, obstacle_y1,
    input  logic [10:0] pixel_x, pixel_y,
    output logic        path_valid,
    output logic        path_hit,
    output logic        planning_busy,
    output logic [1:0]  path_mode
);
    localparam logic [2:0] IDLE=0, CLEAR=1, FIRE=2, COLLECT=3, FINAL=4;
    logic [2:0] state;
    localparam logic [1:0] PATH_OFF=2'd0, PATH_SNAPSHOT=2'd1, PATH_LIVE=2'd2;
    logic pending_replan, snapshot_pending;
    logic bank_swap_pending;
    logic [1:0] job_mode;
    logic [10:0] snapshot_start_x, snapshot_start_y, snapshot_goal_x, snapshot_goal_y;
    logic [10:0] snapshot_car_min_x, snapshot_car_min_y;
    logic [10:0] snapshot_car_max_x, snapshot_car_max_y;
    logic [15:0] snapshot_obstacle_valid;
    logic [175:0] snapshot_obstacle_x0, snapshot_obstacle_y0;
    logic [175:0] snapshot_obstacle_x1, snapshot_obstacle_y1;
    logic [11:0] clear_idx, source, target, previous_idx;
    logic previous_valid, route_active;
    (* ram_style = "distributed" *) logic [7:0] connections [0:6143];
    logic active_bank, build_bank;
    logic [11:0] active_source, active_target;
    logic [10:0] active_start_x, active_start_y, active_goal_x, active_goal_y;
    logic [7:0] previous_in_arm, final_arm;
    logic conn_we;
    logic [11:0] conn_write_idx;
    logic [7:0] conn_write_data;
    logic [3071:0] obstacle_map;

    logic [15:0] obstacle_valid_saved;
    logic [175:0] obstacle_x0_saved, obstacle_y0_saved, obstacle_x1_saved, obstacle_y1_saved;
    logic [10:0] actual_start_x,actual_start_y,actual_goal_x,actual_goal_y;
    logic [10:0] c_x0,c_y0,c_x1,c_y1;
    logic [15:0] obstacle_hit;
    logic [11:0] car_w, car_h, car_short_side, margin_x, margin_y;
    logic [10:0] cell_x0,cell_y0,cell_x1,cell_y1;
    logic planner_busy, planner_done, planner_found, planner_valid, planner_last;
    logic [22:0] planner_cost;
    logic [11:0] planner_length;
    logic [5:0] planner_row, planner_col;
    logic [11:0] point_idx;
    logic [7:0] old_arm, new_arm;
    integer delta;

    function automatic logic on_seg(input logic [10:0] px,py,x0,y0,x1,y1);
        logic signed [12:0] dx,dy,ex,ey;
        logic signed [25:0] cross_v;
        logic [12:0] adx,ady,maxd;
        logic [25:0] acr;
        begin
            dx = $signed({1'b0,x1}) - $signed({1'b0,x0});
            dy = $signed({1'b0,y1}) - $signed({1'b0,y0});
            ex = $signed({1'b0,px}) - $signed({1'b0,x0});
            ey = $signed({1'b0,py}) - $signed({1'b0,y0});
            cross_v = ex*dy - ey*dx;
            adx = (dx < 0) ? -dx : dx;
            ady = (dy < 0) ? -dy : dy;
            maxd = (adx > ady) ? adx : ady;
            acr = (cross_v < 0) ? -cross_v : cross_v;
            on_seg =
                px >= ((x0 < x1) ? x0 : x1) &&
                px <= ((x0 > x1) ? x0 : x1) &&
                py >= ((y0 < y1) ? y0 : y1) &&
                py <= ((y0 > y1) ? y0 : y1) &&
                acr <= (maxd << 1);
        end
    endfunction

    function automatic logic [11:0] lower(input logic [10:0] x,
                                           input logic [11:0] margin);
        lower = ({1'b0,x} > margin) ? {1'b0,x} - margin : 0;
    endfunction
    function automatic logic [11:0] upper(input logic [10:0] x,
                                           input logic [11:0] margin,
                                           input logic [11:0] limit);
        upper = ({1'b0,x} + margin > limit) ? limit : {1'b0,x} + margin;
    endfunction

    // User-selected isotropic clearance: half of the shorter car-box side.
    // The visible boxes do not change; only the planner's obstacle map does.
    assign car_w = (c_x1 >= c_x0) ? ({1'b0,c_x1} - {1'b0,c_x0} + 1'b1) : 0;
    assign car_h = (c_y1 >= c_y0) ? ({1'b0,c_y1} - {1'b0,c_y0} + 1'b1) : 0;
    assign car_short_side = (car_w < car_h) ? car_w : car_h;
    assign margin_x = (car_short_side + 1'b1) >> 1;
    assign margin_y = margin_x;
    genvar box_idx;
    generate for (box_idx=0; box_idx<16; box_idx=box_idx+1) begin : obstacle_cells
        wire [11:0] left_edge = lower(obstacle_x0_saved[box_idx*11+:11], margin_x);
        wire [11:0] top_edge = lower(obstacle_y0_saved[box_idx*11+:11], margin_y);
        wire [11:0] right_edge = upper(obstacle_x1_saved[box_idx*11+:11], margin_x, 12'd1023);
        wire [11:0] bottom_edge = upper(obstacle_y1_saved[box_idx*11+:11], margin_y, 12'd767);
        assign obstacle_hit[box_idx] = obstacle_valid_saved[box_idx] &&
            !(cell_x1 < left_edge || cell_x0 > right_edge ||
              cell_y1 < top_edge || cell_y0 > bottom_edge);
    end endgenerate
    assign cell_x0 = {clear_idx[5:0],4'b0};
    assign cell_y0 = {clear_idx[11:6],4'b0};
    assign cell_x1 = cell_x0 + 11'd15;
    assign cell_y1 = cell_y0 + 11'd15;

    astar_grid_planner planner (
        .clk(clk), .rst_n(rst_n), .start(state == FIRE),
        .start_idx(source), .goal_idx(target), .obstacle_map(obstacle_map),
        .busy(planner_busy), .done(planner_done), .found(planner_found),
        .path_cost(planner_cost), .path_length(planner_length),
        .path_valid(planner_valid), .path_ready(1'b1),
        .path_row(planner_row), .path_col(planner_col), .path_last(planner_last)
    );

    assign point_idx = {planner_row,planner_col};
    always @* begin
        delta = $signed({1'b0,point_idx}) - $signed({1'b0,previous_idx});
        old_arm = 0; new_arm = 0;
        case (delta)
            -1:  begin old_arm=8'h01; new_arm=8'h02; end // W / E
             1:  begin old_arm=8'h02; new_arm=8'h01; end
            -64: begin old_arm=8'h04; new_arm=8'h08; end // N / S
             64: begin old_arm=8'h08; new_arm=8'h04; end
            -65: begin old_arm=8'h10; new_arm=8'h80; end // NW / SE
            -63: begin old_arm=8'h20; new_arm=8'h40; end // NE / SW
             63: begin old_arm=8'h40; new_arm=8'h20; end
             65: begin old_arm=8'h80; new_arm=8'h10; end
        endcase
    end

    // Complete a cell when the next point arrives: one write port per cycle.
    always_comb begin
        conn_we = 1'b0;
        conn_write_idx = 12'd0;
        conn_write_data = 8'd0;
        if (state == CLEAR) begin
            conn_we = 1'b1;
            conn_write_idx = clear_idx;
        end else if (state == COLLECT && planner_valid && previous_valid) begin
            conn_we = 1'b1;
            conn_write_idx = previous_idx;
            conn_write_data = previous_in_arm | old_arm;
        end else if (state == FINAL) begin
            conn_we = 1'b1;
            conn_write_idx = previous_idx;
            conn_write_data = final_arm;
        end
    end
    always_ff @(posedge clk) begin
        if (conn_we) connections[{build_bank,conn_write_idx}] <= conn_write_data;
    end

    assign planning_busy = (state != IDLE) || planner_busy ||
                            snapshot_pending || bank_swap_pending;
    assign path_valid = route_active && all_mode &&
        (path_mode == PATH_SNAPSHOT ||
         (path_mode == PATH_LIVE && start_valid && goal_valid));

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE; clear_idx <= 0; source <= 0; target <= 0;
            previous_idx <= 0; previous_valid <= 0; route_active <= 0;
            active_bank <= 0; build_bank <= 1;
            active_source <= 0; active_target <= 0;
            active_start_x <= 0; active_start_y <= 0;
            active_goal_x <= 0; active_goal_y <= 0;
            previous_in_arm <= 0; final_arm <= 0; pending_replan <= 0;
            path_mode <= PATH_OFF; job_mode <= PATH_OFF; snapshot_pending <= 0;
            bank_swap_pending <= 0;
            snapshot_start_x <= 0; snapshot_start_y <= 0;
            snapshot_goal_x <= 0; snapshot_goal_y <= 0;
            snapshot_car_min_x <= 0; snapshot_car_min_y <= 0;
            snapshot_car_max_x <= 0; snapshot_car_max_y <= 0;
            snapshot_obstacle_valid <= 0;
            snapshot_obstacle_x0 <= 0; snapshot_obstacle_y0 <= 0;
            snapshot_obstacle_x1 <= 0; snapshot_obstacle_y1 <= 0;
            obstacle_valid_saved <= 0;
            obstacle_x0_saved <= 0; obstacle_y0_saved <= 0;
            obstacle_x1_saved <= 0; obstacle_y1_saved <= 0;
            actual_start_x <= 0; actual_start_y <= 0;
            actual_goal_x <= 0; actual_goal_y <= 0;
            c_x0 <= 0; c_y0 <= 0; c_x1 <= 0; c_y1 <= 0;
            obstacle_map <= 0;
        end else begin
            // Leaving All immediately hides and disarms every path mode.
            if (!all_mode) begin
                path_mode <= PATH_OFF;
                route_active <= 0;
                snapshot_pending <= 0;
                pending_replan <= 0;
                bank_swap_pending <= 0;
            end else if (snapshot_pulse) begin
                path_mode <= PATH_SNAPSHOT;
                pending_replan <= 0;
                bank_swap_pending <= 0;
                if (start_valid && goal_valid) begin
                    // Capture the published ROI at the UART command edge, even
                    // if a previous route is still being calculated.
                    snapshot_pending <= 1;
                    snapshot_start_x <= start_x; snapshot_start_y <= start_y;
                    snapshot_goal_x <= goal_x; snapshot_goal_y <= goal_y;
                    snapshot_car_min_x <= car_min_x; snapshot_car_min_y <= car_min_y;
                    snapshot_car_max_x <= car_max_x; snapshot_car_max_y <= car_max_y;
                    snapshot_obstacle_valid <= obstacle_valid;
                    snapshot_obstacle_x0 <= obstacle_x0; snapshot_obstacle_y0 <= obstacle_y0;
                    snapshot_obstacle_x1 <= obstacle_x1; snapshot_obstacle_y1 <= obstacle_y1;
                end else begin
                    // A requested scan without both endpoints clears the old route.
                    snapshot_pending <= 0;
                    route_active <= 0;
                end
            end else if (live_pulse) begin
                path_mode <= PATH_LIVE;
                snapshot_pending <= 0;
                pending_replan <= 1;
                bank_swap_pending <= 0;
            end else if (clear_pulse && path_mode == PATH_SNAPSHOT) begin
                path_mode <= PATH_OFF;
                route_active <= 0;
                snapshot_pending <= 0;
                pending_replan <= 0;
                bank_swap_pending <= 0;
            end else if (path_mode == PATH_LIVE && frame_pulse && state != IDLE) begin
                pending_replan <= 1;
            end

            if (path_mode == PATH_LIVE && (!start_valid || !goal_valid))
                route_active <= 0;

            // Commit a completed route only at a display-frame boundary. Switching
            // active_bank in the middle of an HDMI scan can expose part of the old
            // route and part of the new route in the same displayed frame.
            if (bank_swap_pending && frame_pulse &&
                !snapshot_pulse && !live_pulse && !clear_pulse &&
                all_mode && (job_mode == path_mode)) begin
                bank_swap_pending <= 0;
                active_bank <= build_bank;
                build_bank <= ~build_bank;
                active_source <= source;
                active_target <= target;
                active_start_x <= actual_start_x;
                active_start_y <= actual_start_y;
                active_goal_x <= actual_goal_x;
                active_goal_y <= actual_goal_y;
                route_active <= 1;
            end

            case (state)
                IDLE: if (all_mode && !bank_swap_pending &&
                          !snapshot_pulse && !live_pulse && !clear_pulse) begin
                    if (snapshot_pending) begin
                        snapshot_pending <= 0;
                        job_mode <= PATH_SNAPSHOT;
                        source <= {snapshot_start_y[9:4], snapshot_start_x[9:4]};
                        target <= {snapshot_goal_y[9:4], snapshot_goal_x[9:4]};
                        actual_start_x <= snapshot_start_x;
                        actual_start_y <= snapshot_start_y;
                        actual_goal_x <= snapshot_goal_x;
                        actual_goal_y <= snapshot_goal_y;
                        c_x0 <= snapshot_car_min_x; c_y0 <= snapshot_car_min_y;
                        c_x1 <= snapshot_car_max_x; c_y1 <= snapshot_car_max_y;
                        obstacle_valid_saved <= snapshot_obstacle_valid;
                        obstacle_x0_saved <= snapshot_obstacle_x0;
                        obstacle_y0_saved <= snapshot_obstacle_y0;
                        obstacle_x1_saved <= snapshot_obstacle_x1;
                        obstacle_y1_saved <= snapshot_obstacle_y1;
                        clear_idx <= 0;
                        state <= CLEAR;
                    end else if (path_mode == PATH_LIVE &&
                                 (frame_pulse || pending_replan) &&
                                 start_valid && goal_valid) begin
                        pending_replan <= 0;
                        job_mode <= PATH_LIVE;
                        source <= {start_y[9:4],start_x[9:4]};
                        target <= {goal_y[9:4],goal_x[9:4]};
                        actual_start_x <= start_x; actual_start_y <= start_y;
                        actual_goal_x <= goal_x; actual_goal_y <= goal_y;
                        c_x0 <= car_min_x; c_y0 <= car_min_y;
                        c_x1 <= car_max_x; c_y1 <= car_max_y;
                        obstacle_valid_saved <= obstacle_valid;
                        obstacle_x0_saved <= obstacle_x0; obstacle_y0_saved <= obstacle_y0;
                        obstacle_x1_saved <= obstacle_x1; obstacle_y1_saved <= obstacle_y1;
                        clear_idx <= 0;
                        state <= CLEAR;
                    end
                end
                CLEAR: begin
                    obstacle_map[clear_idx] <= |obstacle_hit;
                    if (clear_idx == 12'd3071) state <= FIRE;
                    else clear_idx <= clear_idx + 1'b1;
                end
                FIRE: begin
                    previous_valid <= 0;
                    previous_in_arm <= 0;
                    state <= COLLECT;
                end
                COLLECT: begin
                    if (planner_valid) begin
                        if (previous_valid) previous_in_arm <= new_arm;
                        previous_idx <= point_idx;
                        previous_valid <= 1;
                        if (planner_last) begin
                            final_arm <= previous_valid ? new_arm : 8'd0;
                            state <= FINAL;
                        end
                    end
                    if (planner_done) begin
                        if (!planner_found && all_mode && job_mode == path_mode &&
                            !snapshot_pending && !snapshot_pulse && !live_pulse &&
                            !clear_pulse) route_active <= 0;
                        state <= IDLE;
                    end
                end
                FINAL: begin
                    if (planner_found && all_mode && job_mode == path_mode &&
                        !snapshot_pending && !snapshot_pulse && !live_pulse &&
                        !clear_pulse &&
                        (job_mode == PATH_SNAPSHOT || (start_valid && goal_valid))) begin
                        bank_swap_pending <= 1;
                    end
                    state <= IDLE;
                end
            endcase
        end
    end

    logic [7:0] arms;
    logic [11:0] cell_idx;
    integer lx, ly, d1, d2;
    logic horizontal_hit, vertical_hit, diagonal_hit;
    logic endpoint_hit;
    logic path_hit_raw;
    logic [10:0] start_grid_x,start_grid_y,goal_grid_x,goal_grid_y;
    assign start_grid_x = {1'b0,active_source[5:0],4'b1000};
    assign start_grid_y = {1'b0,active_source[11:6],4'b1000};
    assign goal_grid_x  = {1'b0,active_target[5:0],4'b1000};
    assign goal_grid_y  = {1'b0,active_target[11:6],4'b1000};
    always @* begin
        cell_idx = {pixel_y[9:4],pixel_x[9:4]};
        arms = 0;
        lx = pixel_x[3:0]; ly = pixel_y[3:0];
        d1 = lx - ly; if (d1 < 0) d1 = -d1;
        d2 = lx + ly - 16; if (d2 < 0) d2 = -d2;
        horizontal_hit = 0; vertical_hit = 0; diagonal_hit = 0;
        endpoint_hit = 0;
        if (pixel_x < 1024 && pixel_y < 768) arms = connections[{active_bank,cell_idx}];
        if (ly >= 7 && ly <= 9 && !pixel_x[2])
            horizontal_hit = (arms[0] && lx <= 8) || (arms[1] && lx >= 8);
        if (lx >= 7 && lx <= 9 && !pixel_y[2])
            vertical_hit = (arms[2] && ly <= 8) || (arms[3] && ly >= 8);
        if (d1 <= 2 && !pixel_x[2])
            diagonal_hit = (arms[4] && lx <= 8 && ly <= 8) ||
                           (arms[7] && lx >= 8 && ly >= 8);
        if (d2 <= 2 && !pixel_x[2])
            diagonal_hit = diagonal_hit ||
                           (arms[5] && lx >= 8 && ly <= 8) ||
                           (arms[6] && lx <= 8 && ly >= 8);
        if (cell_idx == active_source)
            endpoint_hit = on_seg(pixel_x,pixel_y,active_start_x,active_start_y,
                                  start_grid_x,start_grid_y);
        if (cell_idx == active_target)
            endpoint_hit = endpoint_hit ||
                on_seg(pixel_x,pixel_y,goal_grid_x,goal_grid_y,
                       active_goal_x,active_goal_y);
        path_hit_raw = path_valid &&
                       (horizontal_hit || vertical_hit || diagonal_hit || endpoint_hit);
    end
    // Match the one-cycle video data delay at the HDMI output mux.
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) path_hit <= 1'b0;
        else path_hit <= path_hit_raw;
    end
endmodule
