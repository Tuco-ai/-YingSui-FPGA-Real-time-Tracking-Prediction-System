// osd_text.v : top-left corner OSD text overlay (2 lines, green, 8x16 font)
module osd_text (
    input  wire [10:0] pixel_xpos,
    input  wire [10:0] pixel_ypos,
    input  wire [5:0]  time_sec,    // 0~30 current recording seconds
    input  wire [1:0]  color_mode,  // 0=Blue, 1=Red, 2=Green
    output wire        osd_hit      // 1 = current pixel belongs to OSD text
);

    // ---- split seconds into tens / ones ----
    wire [3:0] sec_tens = time_sec / 10;
    wire [3:0] sec_ones = time_sec % 10;

    // ---- color name (5 chars, padded with space) ----
    reg [7:0] c0, c1, c2, c3, c4, c5;
    always @(*) begin
        c0 = " "; c1 = " "; c2 = " ";
        c3 = " "; c4 = " "; c5 = " ";
        case (color_mode)
            2'd0: begin c0="B"; c1="l"; c2="u"; c3="e"; end
            2'd1: begin c0="R"; c1="e"; c2="d"; end
            2'd2: begin c0="G"; c1="r"; c2="e"; c3="e"; c4="n"; c5=" "; end
            2'd3: begin c0="a"; c1="l"; c2="l"; end
            default: begin end
        endcase
    end


    // ---- current pixel: which line / char / col / row ----
    wire line1 = (pixel_ypos < 11'd16);                  // line 1 at y = 0~15
    wire line2 = (pixel_ypos >= 11'd16) && (pixel_ypos < 11'd32);

    wire [7:0] char_idx = pixel_xpos[10:3];   // char index 0..127 (x >> 3)
    wire [2:0] col = pixel_xpos[2:0];         // 0..7 inside char
    wire [3:0] row = pixel_ypos[3:0];         // 0..15 inside glyph

    // ---- select ASCII char for current position ----
    reg [7:0] ascii;
    always @(*) begin
        ascii = 8'h20;  // default space
        if (line1) begin
            case (char_idx)
                8'd0:  ascii = "T";
                8'd1:  ascii = "i";
                8'd2:  ascii = "m";
                8'd3:  ascii = "e";
                8'd4:  ascii = ":";
                8'd5:  ascii = " ";
                8'd6:  ascii = 8'h30 + sec_tens;
                8'd7:  ascii = 8'h30 + sec_ones;
                8'd8:  ascii = "/";
                8'd9:  ascii = "3";
                8'd10: ascii = "0";
                default: ascii = " ";
            endcase
        end else if (line2) begin
            case (char_idx)
                8'd0:  ascii = "C";
                8'd1:  ascii = "o";
                8'd2:  ascii = "l";
                8'd3:  ascii = "o";
                8'd4:  ascii = "r";
                8'd5:  ascii = ":";
                8'd6:  ascii = " ";
                8'd7:  ascii = c0;
                8'd8:  ascii = c1;
                8'd9:  ascii = c2;
                8'd10: ascii = c3;
                8'd11: ascii = c4;
                8'd12: ascii = c5;
                default: ascii = " ";
            endcase
        end
    end

    // ---- look up glyph row ----
    wire [7:0] font_row;
    font_rom u_font (
        .ascii    (ascii),
        .row      (row),
        .font_row (font_row)
    );

    // ---- hit test: bit for current column ----
    wire [7:0] col_mask = 8'b10000000 >> col;  // col0 -> bit7 (leftmost)
    wire bit_hit = |(font_row & col_mask);

    assign osd_hit = (line1 || line2) && bit_hit;

endmodule
