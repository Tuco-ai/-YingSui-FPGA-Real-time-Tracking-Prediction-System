module traj_bitmap (
    input  wire        clk,
    input  wire        wen,          // 写使能
    input  wire [19:0] waddr,        // 写地址 = {y[9:0], x[9:0]}
    input  wire        wdata,        // 写数据（1=轨迹）
    input  wire [19:0] raddr,        // 读地址
    output wire        rdata         // 读数据（同步读，延迟1拍）
);
    (* ram_style = "block" *) reg [0:0] mem [0:786431];   // Exactly 1024*768 valid image bits; out-of-image addresses are ignored.

    reg [19:0] raddr_reg;
    always @(posedge clk) begin
        if (wen && waddr < 20'd786432)
            mem[waddr] <= wdata;
        raddr_reg <= raddr;
    end

    assign rdata = (raddr_reg < 20'd786432) ? mem[raddr_reg] : 1'b0;   // 同步读
endmodule