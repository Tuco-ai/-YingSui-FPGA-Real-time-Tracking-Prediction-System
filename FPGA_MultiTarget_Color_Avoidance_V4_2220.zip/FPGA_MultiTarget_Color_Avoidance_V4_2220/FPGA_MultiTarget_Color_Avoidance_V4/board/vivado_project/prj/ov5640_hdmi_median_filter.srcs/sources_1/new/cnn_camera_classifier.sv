// Up to sixteen color-qualified ROIs share one captured frame; repeated colors
// occupy independent CNN lanes. Every color mode uses the CNN car/block result.
// No absent-object hold. Cached labels survive isolated contradictory results.
module cnn_camera_classifier #(parameter H_ACTIVE=1024,V_ACTIVE=768)(
 input wire cam_clk,clk,rst_n,frame_vsync,frame_href,frame_de,
 input wire [15:0] frame_rgb,candidate_frame_id,
 input wire [1:0] color_mode,
 input wire candidate_update,
 input wire [15:0] candidate_observed,candidate_estimated,
 input wire [47:0] candidate_color,
 input wire [175:0] x0,x1,y0,y1,
 output wire [15:0] class_valid,
 output wire [31:0] classes
);
 wire reset_n;
 reset_release_sync pr(.clk(clk),.arst_n(rst_n),.srst_n(reset_n));
 wire [15:0] load_we,start,busy,loaded_mask;
 wire [9:0] load_addr;wire signed [7:0] load_data;
 wire loaded;wire [127:0] generations,loaded_generations;
 wire [15:0] loaded_frame_id;
 reg update_d;
 always @(posedge clk or negedge reset_n)if(!reset_n)update_d<=0;else update_d<=candidate_update;
 wire [15:0] loader_busy=busy|{16{candidate_update||update_d}};
 cnn_frame_roi_loader #(.H_ACTIVE(H_ACTIVE),.V_ACTIVE(V_ACTIVE)) frames(
  .cam_clk(cam_clk),.clk(clk),.rst_n(rst_n),.frame_vsync(frame_vsync),.frame_href(frame_href),.frame_de(frame_de),.frame_rgb(frame_rgb),
  .candidate_frame_id(candidate_frame_id),.candidate_observed(candidate_observed),.cnn_busy(loader_busy),.x0(x0),.x1(x1),.y0(y0),.y1(y1),
  .generations(generations),.load_we(load_we),.start(start),.load_addr(load_addr),.load_data(load_data),
  .loaded(loaded),.loaded_mask(loaded_mask),.loaded_generations(loaded_generations),.loaded_frame_id(loaded_frame_id)
 );
 genvar slot;
 generate for(slot=0;slot<16;slot=slot+1)begin: channel
  reg [7:0] generation,inflight_generation;
  reg was_present,class_known;
  reg [1:0] cached_class,class_rejects,pending_class,class_agrees;
  reg [2:0] prev_color;
  reg [10:0] prev_cx,prev_cy;
  wire [11:0] cx_sum={1'b0,x0[slot*11+:11]}+x1[slot*11+:11];
  wire [11:0] cy_sum={1'b0,y0[slot*11+:11]}+y1[slot*11+:11];
  wire [10:0] cx=cx_sum[11:1],cy=cy_sum[11:1];
  wire [10:0] dx=cx>prev_cx?cx-prev_cx:prev_cx-cx;
  wire [10:0] dy=cy>prev_cy?cy-prev_cy:prev_cy-cy;
  wire [11:0] w={1'b0,x1[slot*11+:11]}-{1'b0,x0[slot*11+:11]}+12'd1;
  wire [11:0] h={1'b0,y1[slot*11+:11]}-{1'b0,y0[slot*11+:11]}+12'd1;
  wire jump=was_present&&candidate_observed[slot]&&((dx>(w<48?48:w))||(dy>(h<48?48:h)));
  wire [2:0] this_color=candidate_color[slot*3+:3];
  wire invalidate=candidate_update&&(!candidate_observed[slot]||!was_present||jump||
                                      (prev_color!=this_color));
  reg [21:0] watchdog;reg [3:0] recover;
  wire lane_reset_n=reset_n&&!recover[3];
  wire done;wire [1:0] class_id;
  wire signed [31:0] score_car,score_block,score_other;
  assign generations[slot*8+:8]=generation;
  assign class_valid[slot]=class_known&&candidate_observed[slot];
  assign classes[slot*2+:2]=class_known?cached_class:2'd2;
  always @(posedge clk or negedge reset_n)begin
   if(!reset_n)begin watchdog<=0;recover<=0;end
   else begin
    recover<={recover[2:0],1'b0};
    if(watchdog[21])begin recover<=4'b1111;watchdog<=0;end
    else if(!lane_reset_n)watchdog<=0;
    else if(start[slot]||busy[slot])watchdog<=watchdog+1'b1;
    else watchdog<=0;
   end
  end
  always @(posedge clk or negedge reset_n)begin
    if(!reset_n)begin generation<=0;inflight_generation<=0;was_present<=0;prev_cx<=0;prev_cy<=0;prev_color<=0;end
   else begin
    if(candidate_update)begin
     was_present<=candidate_observed[slot];prev_cx<=cx;prev_cy<=cy;prev_color<=this_color;
     if(candidate_observed[slot]!=was_present||jump||prev_color!=this_color)generation<=generation+1'b1;
    end
    if(loaded&&loaded_mask[slot])inflight_generation<=loaded_generations[slot*8+:8];
   end
  end
  always @(posedge clk or negedge reset_n)begin
   if(!reset_n)begin class_known<=0;cached_class<=2;class_rejects<=0;pending_class<=2;class_agrees<=0;end
   else if(invalidate||!lane_reset_n||watchdog[21])begin
    class_known<=0;cached_class<=2;class_rejects<=0;pending_class<=2;class_agrees<=0;
   end else if(done&&candidate_observed[slot]&&(inflight_generation==generation))begin
    if(class_id<2)begin
      class_rejects<=0;
      if(!class_known||class_id==cached_class)begin
       class_known<=1;cached_class<=class_id;class_agrees<=0;pending_class<=2;
      end else if(pending_class==class_id&&class_agrees==2)begin
       cached_class<=class_id;class_agrees<=0;pending_class<=2;
     end else begin
       pending_class<=class_id;
       class_agrees<=(pending_class==class_id)?class_agrees+1'b1:2'd1;
     end
    end else begin
      class_agrees<=0;pending_class<=2;
      if(class_rejects==2)begin class_known<=0;cached_class<=2;class_rejects<=0;end
      else class_rejects<=class_rejects+1'b1;
    end
   end
  end
  tiny_object_cnn_int8 cnn(.clk(clk),.rst_n(lane_reset_n),.load_we(load_we[slot]),.load_addr(load_addr),.load_data(load_data),
   .start(start[slot]),.busy(busy[slot]),.done(done),.class_id(class_id),.score_car(score_car),.score_block(score_block),.score_other(score_other));
 end endgenerate
endmodule
