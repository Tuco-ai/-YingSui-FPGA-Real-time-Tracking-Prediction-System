`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/10/25 18:14:19
// Design Name: 
// Module Name: goal_box_selector
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module goal_box_selector (
    input  wire [15:0] roi_valid,
    input  wire [15:0] roi_block_valid,
    input  wire [47:0] roi_color,
    input  wire [175:0] roi_x0, roi_x1, roi_y0, roi_y1,
    output reg         goal_valid,
    output reg  [3:0]  goal_index,
    output wire [10:0] goal_cx, goal_cy,
    output wire [10:0] goal_min_x, goal_min_y,
    output wire [10:0] goal_max_x, goal_max_y
);
    integer k;
    always @* begin
        goal_valid=0;
        goal_index=0;
        // Only a green component classified by the CNN as BLOCK can be the goal.
        // The first qualifying candidate has priority.
        for(k=15;k>=0;k=k-1)
            if(roi_valid[k] && roi_block_valid[k] && roi_color[k*3+:3]==3'd4) begin
                goal_valid=1;
                goal_index=k;
            end
    end

    wire [10:0] min_x = roi_x0[goal_index*11 +: 11];
    wire [10:0] max_x = roi_x1[goal_index*11 +: 11];
    wire [10:0] min_y = roi_y0[goal_index*11 +: 11];
    wire [10:0] max_y = roi_y1[goal_index*11 +: 11];

    wire [11:0] cx_sum = {1'b0, min_x} + {1'b0, max_x};
    wire [11:0] cy_sum = {1'b0, min_y} + {1'b0, max_y};

    assign goal_cx = cx_sum[11:1];
    assign goal_cy = cy_sum[11:1];
    assign goal_min_x = min_x;
    assign goal_min_y = min_y;
    assign goal_max_x = max_x;
    assign goal_max_y = max_y;
endmodule
