`timescale 1ns/1ps

module host_control_link #(
    parameter integer CLK_FREQ = 65_000_000,
    parameter integer UART_BPS = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       uart_rxd,
    output wire       uart_txd,
    input  wire [1:0] traj_state,
    input  wire [5:0] time_sec,
    input  wire [1:0] color_mode,
    input  wire       car_valid,
    input  wire       goal_valid,
    input  wire       path_valid,
    input  wire       planning_busy,
    input  wire [1:0] path_mode,
    output reg        short_pulse,
    output reg        clear_pulse,
    output reg        path_snapshot_pulse,
    output reg        path_clear_pulse,
    output reg        path_live_pulse,
    output reg        mode_stb,
    output reg  [1:0] mode_value
);
    localparam [7:0] HEADER0 = 8'hA5;
    localparam [7:0] HEADER1 = 8'h5A;
    localparam [7:0] CMD_ACK = 8'h80;
    localparam [7:0] TYPE_STATUS = 8'h90;

    localparam [7:0] CMD_START  = 8'h01;
    localparam [7:0] CMD_PAUSE  = 8'h02;
    localparam [7:0] CMD_RESUME = 8'h03;
    localparam [7:0] CMD_CLEAR  = 8'h04;
    localparam [7:0] CMD_MODE   = 8'h05;
    localparam [7:0] CMD_QUERY  = 8'h10;
    localparam [7:0] CMD_PING   = 8'h11;
    localparam [7:0] CMD_PATH_SNAPSHOT = 8'h20;
    localparam [7:0] CMD_PATH_CLEAR    = 8'h21;
    localparam [7:0] CMD_PATH_LIVE     = 8'h22;
    localparam integer BAUD_DIV = CLK_FREQ / UART_BPS;

    localparam [1:0] TRAJ_IDLE = 2'd0;
    localparam [1:0] TRAJ_REC  = 2'd1;
    localparam [1:0] TRAJ_PAUSE= 2'd2;

    localparam [2:0] RX_HEAD0 = 3'd0;
    localparam [2:0] RX_HEAD1 = 3'd1;
    localparam [2:0] RX_CMD   = 3'd2;
    localparam [2:0] RX_ARG   = 3'd3;
    localparam [2:0] RX_CRC   = 3'd4;

    localparam [1:0] TX_IDLE       = 2'd0;
    localparam [1:0] TX_WAIT_BUSY  = 2'd1;
    localparam [1:0] TX_WAIT_DONE  = 2'd2;

    reg [2:0] rx_state;
    reg [7:0] rx_cmd;
    reg [7:0] rx_arg;
    reg [7:0] rx_crc;

    wire       rx_done;
    wire [7:0] rx_data;

    reg        tx_start;
    reg [7:0]  tx_byte;
    wire       tx_busy;
    reg [1:0]  tx_state;

    reg [7:0]  response_buf [0:8];
    reg [4:0]  response_len;
    reg [4:0]  response_pos;
    reg        send_active;
    reg        queued_status;
    reg [15:0] tx_gap;

    wire [7:0] status_flags = {
        4'b0000, planning_busy, path_valid, goal_valid, car_valid
    };

    function automatic [7:0] crc8_step(input [7:0] crc, input [7:0] data);
        integer i;
        reg [7:0] c;
        begin
            c = crc ^ data;
            for (i = 0; i < 8; i = i + 1)
                c = c[7] ? ((c << 1) ^ 8'h07) : (c << 1);
            crc8_step = c;
        end
    endfunction

    wire [7:0] status_crc_1 = crc8_step(8'h00, traj_state);
    wire [7:0] status_crc_2 = crc8_step(status_crc_1, color_mode);
    wire [7:0] status_crc_3 = crc8_step(status_crc_2, time_sec);
    wire [7:0] status_crc_4 = crc8_step(status_crc_3, status_flags);
    wire [7:0] status_crc   = crc8_step(status_crc_4, {6'd0, path_mode});

    uart_rx #(
        .CLK_FREQ(CLK_FREQ),
        .UART_BPS(UART_BPS)
    ) u_uart_rx (
        .clk(clk),
        .rst_n(rst_n),
        .uart_rxd(uart_rxd),
        .uart_rx_done(rx_done),
        .uart_rx_data(rx_data)
    );

    uart_tx #(
        .CLK_FREQ(CLK_FREQ),
        .UART_BPS(UART_BPS)
    ) u_uart_tx (
        .clk(clk),
        .rst_n(rst_n),
        .uart_tx_en(tx_start),
        .uart_tx_data(tx_byte),
        .uart_txd(uart_txd),
        .uart_tx_busy(tx_busy)
    );

    task automatic start_ack(input [7:0] result);
        begin
            if (!send_active) begin
                response_buf[0] <= HEADER0;
                response_buf[1] <= HEADER1;
                response_buf[2] <= rx_cmd | CMD_ACK;
                response_buf[3] <= result;
                response_buf[4] <= crc8_step(
                    crc8_step(8'h00, rx_cmd | CMD_ACK), result);
                response_len <= 5'd5;
                response_pos <= 5'd0;
                send_active  <= 1'b1;
                tx_gap       <= BAUD_DIV * 2;
            end else begin
                queued_status <= 1'b1;
            end
        end
    endtask

    task automatic start_status;
        begin
            if (!send_active) begin
                response_buf[0] <= HEADER0;
                response_buf[1] <= HEADER1;
                response_buf[2] <= TYPE_STATUS;
                response_buf[3] <= {6'd0, traj_state};
                response_buf[4] <= {6'd0, color_mode};
                response_buf[5] <= {2'd0, time_sec};
                response_buf[6] <= status_flags;
                response_buf[7] <= {6'd0, path_mode};
                response_buf[8] <= status_crc;
                response_len <= 5'd9;
                response_pos <= 5'd0;
                send_active  <= 1'b1;
                tx_gap       <= BAUD_DIV * 2;
            end else begin
                queued_status <= 1'b1;
            end
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_state      <= RX_HEAD0;
            rx_cmd        <= 8'd0;
            rx_arg        <= 8'd0;
            rx_crc        <= 8'd0;
            short_pulse   <= 1'b0;
            clear_pulse   <= 1'b0;
            path_snapshot_pulse <= 1'b0;
            path_clear_pulse <= 1'b0;
            path_live_pulse <= 1'b0;
            mode_stb      <= 1'b0;
            mode_value    <= 2'd0;
            tx_start      <= 1'b0;
            tx_byte       <= 8'd0;
            tx_state      <= TX_IDLE;
            response_len  <= 5'd0;
            response_pos  <= 5'd0;
            send_active   <= 1'b0;
            queued_status <= 1'b0;
            tx_gap        <= 16'd0;
        end else begin
            short_pulse <= 1'b0;
            clear_pulse <= 1'b0;
            path_snapshot_pulse <= 1'b0;
            path_clear_pulse <= 1'b0;
            path_live_pulse <= 1'b0;
            mode_stb    <= 1'b0;
            tx_start    <= 1'b0;

            if (rx_done) begin
                case (rx_state)
                    RX_HEAD0: if (rx_data == HEADER0) rx_state <= RX_HEAD1;
                    RX_HEAD1: if (rx_data == HEADER1) rx_state <= RX_CMD;
                              else rx_state <= RX_HEAD0;
                    RX_CMD: begin
                        rx_cmd <= rx_data;
                        rx_state <= RX_ARG;
                    end
                    RX_ARG: begin
                        rx_arg <= rx_data;
                        rx_state <= RX_CRC;
                    end
                    RX_CRC: begin
                        rx_crc <= rx_data;
                        rx_state <= RX_HEAD0;
                        if (crc8_step(crc8_step(8'h00, rx_cmd), rx_arg) == rx_data) begin
                            case (rx_cmd)
                                CMD_START: begin
                                    if (traj_state == TRAJ_IDLE) begin
                                        short_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else begin
                                        start_ack(8'h01);
                                    end
                                end
                                CMD_PAUSE: begin
                                    if (traj_state == TRAJ_REC) begin
                                        short_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else begin
                                        start_ack(8'h01);
                                    end
                                end
                                CMD_RESUME: begin
                                    if (traj_state == TRAJ_PAUSE) begin
                                        short_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else begin
                                        start_ack(8'h01);
                                    end
                                end
                                CMD_CLEAR: begin
                                    if (traj_state != TRAJ_IDLE) begin
                                        clear_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else begin
                                        start_ack(8'h01);
                                    end
                                end
                                CMD_MODE: begin
                                    if (rx_arg < 8'd4) begin
                                        mode_stb   <= 1'b1;
                                        mode_value <= rx_arg[1:0];
                                        start_ack(8'h00);
                                    end else begin
                                        start_ack(8'h02);
                                    end
                                end
                                CMD_PATH_SNAPSHOT: begin
                                    if (color_mode == 2'd3) begin
                                        path_snapshot_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else start_ack(8'h01);
                                end
                                CMD_PATH_CLEAR: begin
                                    if (color_mode == 2'd3 && path_mode == 2'd1) begin
                                        path_clear_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else start_ack(8'h01);
                                end
                                CMD_PATH_LIVE: begin
                                    if (color_mode == 2'd3) begin
                                        path_live_pulse <= 1'b1;
                                        start_ack(8'h00);
                                    end else start_ack(8'h01);
                                end
                                CMD_QUERY: start_status();
                                CMD_PING:  start_ack(8'h00);
                                default:   start_ack(8'h03);
                            endcase
                        end else begin
                            start_ack(8'h04);
                        end
                    end
                    default: rx_state <= RX_HEAD0;
                endcase
            end

            case (tx_state)
                TX_IDLE: begin
                    if (send_active) begin
                        if (tx_gap != 0) begin
                            tx_gap <= tx_gap - 1'b1;
                        end else begin
                            tx_byte  <= response_buf[response_pos];
                            tx_start <= 1'b1;
                            tx_state <= TX_WAIT_BUSY;
                        end
                    end
                end
                TX_WAIT_BUSY: begin
                    if (tx_busy) tx_state <= TX_WAIT_DONE;
                end
                TX_WAIT_DONE: begin
                    if (!tx_busy) begin
                        if (response_pos + 1'b1 == response_len) begin
                            send_active <= 1'b0;
                            tx_state    <= TX_IDLE;
                            if (queued_status) begin
                                queued_status <= 1'b0;
                                response_buf[0] <= HEADER0;
                                response_buf[1] <= HEADER1;
                                response_buf[2] <= TYPE_STATUS;
                                response_buf[3] <= {6'd0, traj_state};
                                response_buf[4] <= {6'd0, color_mode};
                                response_buf[5] <= {2'd0, time_sec};
                                response_buf[6] <= status_flags;
                                response_buf[7] <= {6'd0, path_mode};
                                response_buf[8] <= status_crc;
                                response_len <= 5'd9;
                                response_pos <= 5'd0;
                                send_active  <= 1'b1;
                                tx_gap       <= BAUD_DIV * 2;
                            end
                        end else begin
                            response_pos <= response_pos + 1'b1;
                            tx_gap       <= BAUD_DIV;
                            tx_state     <= TX_IDLE;
                        end
                    end
                end
                default: tx_state <= TX_IDLE;
            endcase
        end
    end
endmodule
