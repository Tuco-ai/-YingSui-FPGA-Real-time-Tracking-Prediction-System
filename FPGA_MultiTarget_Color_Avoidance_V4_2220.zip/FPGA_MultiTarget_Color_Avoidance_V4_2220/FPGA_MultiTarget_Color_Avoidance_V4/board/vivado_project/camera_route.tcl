set camera_clock_nets [get_nets -hier -filter {NAME == cam_pclk_IBUF}]
if {[llength $camera_clock_nets]!=1} {error "Expected exactly one cam_pclk_IBUF net, got: $camera_clock_nets"}
set_property CLOCK_DEDICATED_ROUTE FALSE $camera_clock_nets

# R4 is MRCC, but clockplacer selects an MMCM in another clock region.
# Use the dedicated backbone as recommended by Place 30-575, not fabric routing.
set sys_clock_nets [get_nets -hier -filter {NAME == u_clk_wiz_0/inst/clk_in1_clk_wiz_0}]
if {[llength $sys_clock_nets]!=1} {error "Expected exactly one system MMCM input net, got: $sys_clock_nets"}
set_property CLOCK_DEDICATED_ROUTE BACKBONE $sys_clock_nets
