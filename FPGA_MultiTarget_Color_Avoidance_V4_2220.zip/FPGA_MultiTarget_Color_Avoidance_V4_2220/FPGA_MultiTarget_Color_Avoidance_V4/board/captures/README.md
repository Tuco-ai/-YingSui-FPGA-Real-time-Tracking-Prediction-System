# Board Captures

建议至少保存以下英文命名素材：

```text
all_mode_detection.jpg
car_and_destination_labels.png
snapshot_route.png
snapshot_after_target_move.png
live_route.png
blue_mode.png
green_mode.png
trajectory_recording.png
host_gui_connected.png
```

图片应保留完整的 HDMI 画面，避免裁掉目标框、标签和路径。
