"""A* FPGA host-control UART protocol."""

from __future__ import annotations

from dataclasses import dataclass

HEADER = b"\xA5\x5A"
STATUS_TYPE = 0x90
ACK_MASK = 0x80

CMD_START = 0x01
CMD_PAUSE = 0x02
CMD_RESUME = 0x03
CMD_CLEAR = 0x04
CMD_SET_MODE = 0x05
CMD_QUERY = 0x10
CMD_PING = 0x11
CMD_PATH_SNAPSHOT = 0x20
CMD_PATH_CLEAR = 0x21
CMD_PATH_LIVE = 0x22

MODE_NAMES = ("Blue", "Red", "Green", "All")
STATE_NAMES = ("Idle", "Recording", "Paused", "Done")
PATH_MODE_NAMES = ("Off", "Snapshot", "Live")


def crc8_step(crc: int, value: int) -> int:
    value &= 0xFF
    crc = (crc ^ value) & 0xFF
    for _ in range(8):
        crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def crc8(data: bytes) -> int:
    result = 0
    for value in data:
        result = crc8_step(result, value)
    return result


def build_command(command: int, argument: int = 0) -> bytes:
    body = bytes((command & 0xFF, argument & 0xFF))
    return HEADER + body + bytes((crc8(body),))


@dataclass(frozen=True)
class Ack:
    command: int
    result: int


@dataclass(frozen=True)
class DeviceStatus:
    traj_state: int
    mode: int
    time_sec: int
    flags: int
    path_mode: int

    @property
    def car_valid(self) -> bool:
        return bool(self.flags & 0x01)

    @property
    def goal_valid(self) -> bool:
        return bool(self.flags & 0x02)

    @property
    def path_valid(self) -> bool:
        return bool(self.flags & 0x04)

    @property
    def planning_busy(self) -> bool:
        return bool(self.flags & 0x08)


class FrameParser:
    """Incrementally parse fixed-length UART responses."""

    def __init__(self) -> None:
        self.buffer = bytearray()

    def reset(self) -> None:
        self.buffer.clear()

    def feed(self, data: bytes) -> list[Ack | DeviceStatus]:
        self.buffer.extend(data)
        frames: list[Ack | DeviceStatus] = []

        while True:
            start = self.buffer.find(HEADER)
            if start < 0:
                if self.buffer[-1:] == HEADER[:1]:
                    self.buffer[:] = self.buffer[-1:]
                else:
                    self.buffer.clear()
                return frames
            if start:
                del self.buffer[:start]
            if len(self.buffer) < 3:
                return frames

            frame_type = self.buffer[2]
            frame_len = 9 if frame_type == STATUS_TYPE else 5
            if len(self.buffer) < frame_len:
                return frames

            raw = bytes(self.buffer[:frame_len])
            checksum_ok = (
                crc8(raw[3:8]) == raw[8]
                if frame_type == STATUS_TYPE
                else crc8(raw[2:4]) == raw[4]
            )

            if not checksum_ok:
                del self.buffer[0]
                continue

            del self.buffer[:frame_len]
            if frame_type == STATUS_TYPE:
                frames.append(
                    DeviceStatus(
                        traj_state=raw[3],
                        mode=raw[4],
                        time_sec=raw[5],
                        flags=raw[6],
                        path_mode=raw[7],
                    )
                )
            else:
                frames.append(Ack(command=frame_type & ~ACK_MASK, result=raw[3]))
