from __future__ import annotations

import queue
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

vendor_dir = Path(__file__).resolve().parent / "vendor"
if vendor_dir.is_dir():
    sys.path.insert(0, str(vendor_dir))

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None

from protocol import (
    CMD_CLEAR,
    CMD_PAUSE,
    CMD_PATH_CLEAR,
    CMD_PATH_LIVE,
    CMD_PATH_SNAPSHOT,
    CMD_PING,
    CMD_QUERY,
    CMD_RESUME,
    CMD_SET_MODE,
    CMD_START,
    MODE_NAMES,
    PATH_MODE_NAMES,
    STATE_NAMES,
    Ack,
    DeviceStatus,
    FrameParser,
    build_command,
)


BG = "#0B3B30"
PANEL = "#10483B"
CARD = "#175346"
LOG = "#082E25"
TEXT = "#F7EFEA"
MUTED = "#AFC5BA"
DISABLED = "#6F8B7E"
PRIMARY = "#E56B8A"
PRIMARY_HOVER = "#F07F9B"
PRIMARY_DARK = "#A94B65"
LINE = "#2E6858"
DANGER = "#D95B64"
INK = "#2A1720"


class SerialWorker:
    def __init__(self, port: str, incoming: queue.Queue, errors: queue.Queue) -> None:
        if serial is None:
            raise RuntimeError("pyserial 未安装")
        self.ser = serial.Serial(port=port, baudrate=115200, timeout=0.1, write_timeout=0.3)
        self.incoming = incoming
        self.errors = errors
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._reader, daemon=True)
        self.thread.start()

    def _reader(self) -> None:
        try:
            while not self.stop_event.is_set():
                data = self.ser.read(max(1, self.ser.in_waiting))
                if data:
                    self.incoming.put(data)
        except Exception as exc:
            if not self.stop_event.is_set():
                self.errors.put(f"读取串口失败：{exc}")

    def write(self, data: bytes) -> None:
        with self.lock:
            self.ser.write(data)
            self.ser.flush()

    def close(self) -> None:
        self.stop_event.set()
        try:
            self.ser.close()
        finally:
            self.thread.join(timeout=0.5)


class HostWindow:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("FPGA 视觉避障控制台")
        self.root.geometry("1200x820")
        self.root.minsize(1080, 740)
        self.root.configure(bg=BG)

        self.worker: SerialWorker | None = None
        self.parser = FrameParser()
        self.incoming: queue.Queue[bytes] = queue.Queue()
        self.errors: queue.Queue[str] = queue.Queue()
        self.traj_state = -1
        self.mode = -1
        self.time_sec = 0
        self.flags = 0
        self.path_mode = -1
        self.last_status_at = 0.0

        self.port_var = tk.StringVar()
        self.connection_var = tk.StringVar(value="未连接")
        self.state_var = tk.StringVar(value="--")
        self.time_var = tk.StringVar(value="00 / 30")
        self.mode_var = tk.StringVar(value="--")
        self.car_var = tk.StringVar(value="等待数据")
        self.goal_var = tk.StringVar(value="等待数据")
        self.path_var = tk.StringVar(value="等待数据")
        self.path_mode_var = tk.StringVar(value="--")

        self.mode_buttons: list[tk.Button] = []
        self.control_buttons: dict[str, tk.Button] = {}
        self.path_buttons: dict[str, tk.Button] = {}
        self._build_style()
        self._build_layout()
        self.refresh_ports()
        self.root.after(50, self._drain_queues)
        self.root.after(250, self._poll_status)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(
            "App.TCombobox",
            fieldbackground=CARD,
            background=CARD,
            foreground=TEXT,
            arrowcolor=PRIMARY,
            bordercolor=LINE,
            lightcolor=LINE,
            darkcolor=LINE,
            padding=8,
        )
        style.map(
            "App.TCombobox",
            fieldbackground=[("readonly", CARD)],
            foreground=[("readonly", TEXT)],
            bordercolor=[("focus", PRIMARY)],
        )
        self.root.option_add("*TCombobox*Listbox.background", CARD)
        self.root.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", PRIMARY)
        self.root.option_add("*TCombobox*Listbox.selectForeground", INK)

    def _section_head(
        self,
        parent: tk.Misc,
        title: str,
        note: str = "",
    ) -> tk.Frame:
        background = parent.cget("bg")
        row = tk.Frame(parent, bg=background)
        tk.Frame(row, bg=PRIMARY, width=4, height=18).pack(
            side="left", padx=(0, 9)
        )
        tk.Label(
            row,
            text=title,
            bg=background,
            fg=TEXT,
            font=("Microsoft YaHei UI", 11, "bold"),
        ).pack(side="left")
        if note:
            tk.Label(
                row,
                text=note,
                bg=background,
                fg=MUTED,
                font=("Microsoft YaHei UI", 9),
            ).pack(side="right")
        return row

    def _make_button(
        self,
        parent: tk.Misc,
        text: str,
        command,
        variant: str = "ghost",
        padx: int = 16,
        pady: int = 12,
    ) -> tk.Button:
        variants = {
            "primary": (PRIMARY, INK, PRIMARY_HOVER, INK),
            "ghost": (CARD, TEXT, LINE, TEXT),
            "danger": (CARD, TEXT, DANGER, TEXT),
        }
        background, foreground, active_background, active_foreground = variants[variant]
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=background,
            fg=foreground,
            activebackground=active_background,
            activeforeground=active_foreground,
            disabledforeground=DISABLED,
            font=("Microsoft YaHei UI", 10, "bold"),
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=LINE,
            highlightcolor=PRIMARY_HOVER,
            cursor="hand2",
            padx=padx,
            pady=pady,
        )

    def _build_layout(self) -> None:
        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True, padx=26, pady=20)
        shell.grid_columnconfigure(0, weight=1)
        shell.grid_rowconfigure(2, weight=1)

        header = tk.Frame(shell, bg=BG)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        tk.Frame(header, bg=PRIMARY, width=5, height=48).grid(
            row=0, column=0, rowspan=2, sticky="ns", padx=(0, 14)
        )
        tk.Label(
            header,
            text="FPGA 视觉避障控制台",
            bg=BG,
            fg=TEXT,
            font=("Microsoft YaHei UI", 20, "bold"),
        ).grid(row=0, column=1, sticky="sw")
        tk.Label(
            header,
            text="16 ROI · CNN 分类 · A* 路径规划",
            bg=BG,
            fg=MUTED,
            font=("Microsoft YaHei UI", 9),
        ).grid(row=1, column=1, sticky="nw", pady=(3, 0))

        link_area = tk.Frame(
            header,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        link_area.grid(row=0, column=2, rowspan=2, sticky="e")

        link_row = tk.Frame(link_area, bg=PANEL)
        link_row.pack(fill="x", padx=12, pady=(9, 5))
        self.port_combo = ttk.Combobox(
            link_row,
            textvariable=self.port_var,
            state="readonly",
            style="App.TCombobox",
            width=20,
        )
        self.port_combo.pack(side="left", fill="x", expand=True)

        tk.Button(
            link_row,
            text="刷新",
            command=self.refresh_ports,
            bg=CARD,
            fg=MUTED,
            activebackground=LINE,
            activeforeground=TEXT,
            relief="flat",
            bd=0,
            cursor="hand2",
            padx=10,
        ).pack(side="left", padx=(6, 0))

        self.connect_button = self._make_button(
            link_row,
            "连接",
            self.toggle_connection,
            variant="primary",
            padx=14,
            pady=7,
        )
        self.connect_button.pack(side="left", padx=(6, 0))

        tk.Label(
            link_area,
            textvariable=self.connection_var,
            bg=PANEL,
            fg=MUTED,
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=14, pady=(0, 8))

        tk.Frame(shell, bg=LINE, height=1).grid(
            row=1, column=0, sticky="ew", pady=(14, 0)
        )

        workspace = tk.Frame(shell, bg=BG)
        workspace.grid(row=2, column=0, sticky="nsew", pady=(16, 0))
        workspace.grid_columnconfigure(0, weight=3)
        workspace.grid_columnconfigure(1, weight=2)
        workspace.grid_rowconfigure(2, weight=1)

        status_panel = tk.Frame(
            workspace,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        status_panel.grid(
            row=0, column=0, columnspan=2, sticky="ew", pady=(0, 12)
        )
        self._section_head(
            status_panel,
            "运行概览",
            "状态每 250 ms 刷新",
        ).pack(fill="x", padx=18, pady=(14, 10))

        metrics = tk.Frame(status_panel, bg=PANEL)
        metrics.pack(fill="x", padx=18, pady=(0, 14))
        for index, (title, variable) in enumerate((
            ("记录状态", self.state_var),
            ("记录时间", self.time_var),
            ("颜色模式", self.mode_var),
            ("路径模式", self.path_mode_var),
        )):
            column = index * 2
            metrics.grid_columnconfigure(column, weight=1)
            if index:
                tk.Frame(metrics, bg=LINE, width=1).grid(
                    row=0, column=column - 1, sticky="ns", padx=12
                )
            block = tk.Frame(metrics, bg=PANEL)
            block.grid(row=0, column=column, sticky="ew")
            tk.Label(
                block,
                text=title,
                bg=PANEL,
                fg=MUTED,
                font=("Microsoft YaHei UI", 9),
            ).pack(anchor="w")
            tk.Label(
                block,
                textvariable=variable,
                bg=PANEL,
                fg=TEXT,
                font=("Microsoft YaHei UI", 15, "bold"),
            ).pack(anchor="w", pady=(2, 0))

        path_box = tk.Frame(
            workspace,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        path_box.grid(
            row=1, column=0, sticky="nsew", padx=(0, 6), pady=(0, 12)
        )
        self._section_head(
            path_box,
            "路径生成",
            "当前画面锁定或逐帧跟随",
        ).pack(fill="x", padx=18, pady=(14, 12))

        path_grid = tk.Frame(path_box, bg=PANEL)
        path_grid.pack(fill="x", padx=18)
        for index, (label, key, command) in enumerate((
            ("生成当前路径", "snapshot", CMD_PATH_SNAPSHOT),
            ("实时路径", "live", CMD_PATH_LIVE),
            ("清除当前路径", "clear_path", CMD_PATH_CLEAR),
        )):
            path_grid.grid_columnconfigure(index, weight=1)
            variant = "primary" if key == "snapshot" else "ghost"
            if key == "clear_path":
                variant = "danger"
            button = self._make_button(
                path_grid,
                label,
                lambda c=command: self.send_action(c),
                variant=variant,
                padx=10,
                pady=15,
            )
            button.grid(
                row=0,
                column=index,
                sticky="ew",
                padx=(0 if index == 0 else 6, 0),
            )
            self.path_buttons[key] = button

        tk.Label(
            path_box,
            text="生成后保留当前路径；切换到其他模式时自动隐藏。",
            bg=PANEL,
            fg=MUTED,
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=18, pady=(12, 14))

        vision_box = tk.Frame(
            workspace,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        vision_box.grid(
            row=1, column=1, sticky="nsew", padx=(6, 0), pady=(0, 12)
        )
        self._section_head(vision_box, "视觉对象").pack(
            fill="x", padx=18, pady=(14, 10)
        )
        for title, variable in (
            ("CAR 起点", self.car_var),
            ("绿色终点", self.goal_var),
            ("A* 路径", self.path_var),
        ):
            row = tk.Frame(vision_box, bg=PANEL)
            row.pack(fill="x", padx=18, pady=(5, 8))
            tk.Label(
                row,
                text=title,
                bg=PANEL,
                fg=MUTED,
                font=("Microsoft YaHei UI", 9),
            ).pack(side="left")
            tk.Label(
                row,
                textvariable=variable,
                bg=PANEL,
                fg=TEXT,
                font=("Microsoft YaHei UI", 10, "bold"),
            ).pack(side="right")

        lower = tk.Frame(workspace, bg=BG)
        lower.grid(row=2, column=0, sticky="nsew", padx=(0, 6))
        lower.grid_columnconfigure(0, weight=1)
        lower.grid_columnconfigure(1, weight=1)
        lower.grid_rowconfigure(0, weight=1)

        mode_box = tk.Frame(
            lower,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        mode_box.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self._section_head(mode_box, "显示模式").pack(
            fill="x", padx=16, pady=(14, 10)
        )
        mode_grid = tk.Frame(mode_box, bg=PANEL)
        mode_grid.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        for index, name in enumerate(MODE_NAMES):
            mode_grid.grid_columnconfigure(index % 2, weight=1)
            button = self._make_button(
                mode_grid,
                name,
                lambda i=index: self.set_mode(i),
                padx=10,
                pady=11,
            )
            button.grid(
                row=index // 2,
                column=index % 2,
                sticky="ew",
                padx=4,
                pady=4,
            )
            self.mode_buttons.append(button)

        control_box = tk.Frame(
            lower,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        control_box.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        self._section_head(control_box, "轨迹记录").pack(
            fill="x", padx=16, pady=(14, 10)
        )
        control_grid = tk.Frame(control_box, bg=PANEL)
        control_grid.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        for index, (label, key, command) in enumerate((
            ("开始记录", "start", CMD_START),
            ("暂停", "pause", CMD_PAUSE),
            ("继续", "resume", CMD_RESUME),
            ("清空轨迹", "clear", CMD_CLEAR),
        )):
            control_grid.grid_columnconfigure(index % 2, weight=1)
            button = self._make_button(
                control_grid,
                label,
                lambda c=command: self.send_action(c),
                variant="danger" if key == "clear" else "ghost",
                padx=10,
                pady=11,
            )
            button.grid(
                row=index // 2,
                column=index % 2,
                sticky="ew",
                padx=4,
                pady=4,
            )
            self.control_buttons[key] = button

        log_box = tk.Frame(
            workspace,
            bg=PANEL,
            highlightthickness=1,
            highlightbackground=LINE,
        )
        log_box.grid(row=2, column=1, sticky="nsew", padx=(6, 0))
        self._section_head(log_box, "设备日志").pack(
            fill="x", padx=16, pady=(14, 10)
        )
        self.log_text = tk.Text(
            log_box,
            height=10,
            bg=LOG,
            fg=MUTED,
            insertbackground=PRIMARY,
            selectbackground=PRIMARY_DARK,
            selectforeground=TEXT,
            relief="flat",
            bd=0,
            padx=10,
            pady=8,
            font=("Consolas", 9),
            state="disabled",
        )
        self.log_text.pack(fill="both", expand=True, padx=12, pady=(0, 8))
        tk.Label(
            log_box,
            text=(
                "F1 开始  F2 暂停  F3 继续  F4 清空\n"
                "F5 生成路径  F6 清除路径  F7 实时路径\n"
                "1-4 切换颜色模式"
            ),
            bg=PANEL,
            fg=MUTED,
            justify="left",
            font=("Microsoft YaHei UI", 9),
        ).pack(anchor="w", padx=16, pady=(0, 12))

        self.root.bind("<F1>", lambda _event: self.send_action(CMD_START))
        self.root.bind("<F2>", lambda _event: self.send_action(CMD_PAUSE))
        self.root.bind("<F3>", lambda _event: self.send_action(CMD_RESUME))
        self.root.bind("<F4>", lambda _event: self.send_action(CMD_CLEAR))
        self.root.bind("<F5>", lambda _event: self.send_action(CMD_PATH_SNAPSHOT))
        self.root.bind("<F6>", lambda _event: self.send_action(CMD_PATH_CLEAR))
        self.root.bind("<F7>", lambda _event: self.send_action(CMD_PATH_LIVE))
        for index in range(4):
            self.root.bind(str(index + 1), lambda _event, i=index: self.set_mode(i))

        self._refresh_controls()

    def log(self, text: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", f"{text}\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def refresh_ports(self) -> None:
        if list_ports is None:
            self.port_combo["values"] = ()
            self.connection_var.set("缺少 pyserial")
            return
        values = []
        for port in list_ports.comports():
            label = f"{port.device} · {port.description}"
            values.append(label)
        self.port_combo["values"] = values
        if values and not self.port_var.get():
            self.port_var.set(values[0])
        elif not values:
            self.port_var.set("")
            self.connection_var.set("未发现串口")

    def _selected_port(self) -> str:
        return self.port_var.get().split(" · ", 1)[0].strip()

    def toggle_connection(self) -> None:
        if self.worker is not None:
            self.disconnect()
        else:
            self.connect()

    def connect(self) -> None:
        if serial is None:
            messagebox.showerror("缺少依赖", "请先运行：python -m pip install pyserial")
            return
        port = self._selected_port()
        if not port:
            messagebox.showwarning("未选择串口", "请选择 CH340 对应的 COM 口。")
            return
        try:
            self.worker = SerialWorker(port, self.incoming, self.errors)
            self.parser.reset()
            self.connection_var.set(f"已连接 {port}")
            self.connect_button.configure(text="断开连接", bg=CARD, fg=TEXT)
            self.log(f"串口已连接：{port}，115200 8N1")
            self.worker.write(build_command(CMD_PING))
        except Exception as exc:
            self.worker = None
            messagebox.showerror("连接失败", str(exc))

    def disconnect(self) -> None:
        if self.worker is not None:
            self.worker.close()
            self.worker = None
        self.connection_var.set("未连接")
        self.connect_button.configure(text="连接", bg=PRIMARY, fg=INK)
        self.traj_state = -1
        self.mode = -1
        self.path_mode = -1
        self.flags = 0
        self.path_mode_var.set("--")
        self._refresh_controls()
        self.log("串口已断开")

    def set_mode(self, mode: int) -> None:
        self._send(CMD_SET_MODE, mode)

    def send_action(self, command: int) -> None:
        self._send(command, 0)

    def _send(self, command: int, argument: int) -> None:
        if self.worker is None:
            self.log("命令未发送：开发板未连接")
            return
        try:
            self.worker.write(build_command(command, argument))
        except Exception as exc:
            self.log(f"串口写入失败：{exc}")
            self.disconnect()

    def _poll_status(self) -> None:
        if self.worker is not None:
            self._send(CMD_QUERY, 0)
        self.root.after(250, self._poll_status)

    def _drain_queues(self) -> None:
        while True:
            try:
                self._handle_frames(self.parser.feed(self.incoming.get_nowait()))
            except queue.Empty:
                break
        while True:
            try:
                self.log(self.errors.get_nowait())
                self.disconnect()
            except queue.Empty:
                break
        self.root.after(50, self._drain_queues)

    def _handle_frames(self, frames: list[Ack | DeviceStatus]) -> None:
        for frame in frames:
            if isinstance(frame, DeviceStatus):
                self.traj_state = frame.traj_state
                self.mode = frame.mode
                self.time_sec = frame.time_sec
                self.flags = frame.flags
                self.path_mode = frame.path_mode
                self.state_var.set(
                    STATE_NAMES[frame.traj_state]
                    if 0 <= frame.traj_state < len(STATE_NAMES) else "--"
                )
                self.time_var.set(f"{frame.time_sec:02d} / 30")
                self.mode_var.set(
                    MODE_NAMES[frame.mode] if 0 <= frame.mode < len(MODE_NAMES) else "--"
                )
                self.path_mode_var.set(
                    PATH_MODE_NAMES[frame.path_mode]
                    if 0 <= frame.path_mode < len(PATH_MODE_NAMES) else "--"
                )
                self.car_var.set("已识别" if frame.car_valid else "未识别")
                self.goal_var.set("已识别" if frame.goal_valid else "未识别")
                if frame.path_mode == 0:
                    self.path_var.set("未启用")
                elif frame.planning_busy:
                    self.path_var.set("规划中…")
                else:
                    self.path_var.set("路径有效" if frame.path_valid else "暂无路径")
                self.connection_var.set(f"在线 · {self._selected_port()}")
                self._refresh_controls()
            else:
                result_text = "成功" if frame.result == 0 else f"拒绝/错误({frame.result})"
                if frame.command == CMD_PATH_CLEAR and frame.result == 1 and self.path_mode == 2:
                    result_text = "当前 FPGA 不支持在实时模式清除路径"
                elif frame.command in (CMD_PATH_SNAPSHOT, CMD_PATH_CLEAR, CMD_PATH_LIVE) and frame.result == 3:
                    result_text = "当前 FPGA 位流不支持路径模式命令"
                self.log(f"命令 0x{frame.command:02X}：{result_text}")

    def _refresh_controls(self) -> None:
        connected = self.worker is not None
        states = {
            "start": connected and self.traj_state == 0,
            "pause": connected and self.traj_state == 1,
            "resume": connected and self.traj_state == 2,
            "clear": connected and self.traj_state in (1, 2, 3),
        }
        for key, button in self.control_buttons.items():
            active_clear = key == "clear" and states[key]
            button.configure(
                state="normal" if states[key] else "disabled",
                bg=DANGER if active_clear else CARD,
                fg=TEXT,
                disabledforeground=DISABLED,
            )
        for index, button in enumerate(self.mode_buttons):
            selected = connected and self.mode == index
            button.configure(
                bg=PRIMARY if selected else CARD,
                fg=INK if selected else TEXT,
                state="normal" if connected else "disabled",
                disabledforeground=DISABLED,
            )
        in_all = connected and self.mode == 3
        path_states = {
            "snapshot": in_all and (self.flags & 0x03) == 0x03,
            "clear_path": in_all and self.path_mode in (1, 2),
            "live": in_all,
        }
        for key, button in self.path_buttons.items():
            selected = (
                (key == "snapshot" and self.path_mode == 1) or
                (key == "live" and self.path_mode == 2)
            )
            button.configure(
                state="normal" if path_states[key] else "disabled",
                bg=PRIMARY if selected else CARD,
                fg=INK if selected else TEXT,
                disabledforeground=DISABLED,
            )

    def _on_close(self) -> None:
        if self.worker is not None:
            self.worker.close()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    HostWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
