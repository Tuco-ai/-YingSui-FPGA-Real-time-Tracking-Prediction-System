# FPGA Vision Console - Route Modes

## 运行

```powershell
python host_gui.py
```

本目录已包含 `vendor/pyserial`，无需额外安装依赖。`requirements.txt` 仅用于重新生成依赖。

Windows 下也可以直接双击 `启动上位机.bat`。

选择正点原子底板 USB 串口对应的 `CH340` COM 口，然后连接开发板。

## 按钮

- `开始记录`：仅空闲状态可用。
- `暂停`：仅记录状态可用。
- `继续`：仅暂停状态可用。
- `清空轨迹`：记录、暂停或结束状态可用。
- `Blue/Red/Green/All`：直接设置颜色模式。

硬件 KEY0/KEY1 仍保持原功能。上位机命令执行后，以 FPGA 回传的真实状态为准。

## 路径模式

- `生成当前路径`：仅使用当前已锁存的 ROI 规划一次，完成后冻结路径；
- `清除当前路径`：关闭路径显示，但不移除实时规划能力；
- `实时路径`：保持当前逐帧重新规划功能；
- 非 All 模式下三个路径按钮禁用，并自动回到 Off 模式。

## 协议

固定命令帧：`A5 5A CMD ARG CRC8`。

固定状态帧：`A5 5A 90 STATE MODE TIME FLAGS PATH_MODE CRC8`。

`FLAGS`：

- bit0：CNN 已识别 CAR；
- bit1：绿色终点有效；
- bit2：A* 路径有效；
- bit3：A* 正在规划。

串口参数：`115200 8N1`，无流控。

## 当前工程的 FPGA 限制

本次只移植上位机。当前工程的 FPGA 路径控制源码在实时模式会拒绝 `清除当前路径` 命令（ACK=1），界面仍按参考版显示该按钮；收到拒绝时路径不会消失。当前 `cnn_weights` 未修改。
