import unittest

from protocol import (
    CMD_QUERY,
    CMD_START,
    CMD_PATH_SNAPSHOT,
    CMD_PATH_CLEAR,
    CMD_PATH_LIVE,
    Ack,
    DeviceStatus,
    FrameParser,
    build_command,
    crc8,
)


class ProtocolTest(unittest.TestCase):
    def test_command_frame(self) -> None:
        self.assertEqual(build_command(CMD_START), b"\xA5\x5A\x01\x00\x15")
        self.assertEqual(build_command(CMD_QUERY), b"\xA5\x5A\x10\x00\x57")
        for command in (CMD_PATH_SNAPSHOT, CMD_PATH_CLEAR, CMD_PATH_LIVE):
            self.assertEqual(build_command(command)[2:4], bytes((command, 0)))

    def test_ack_parser(self) -> None:
        body = bytes((CMD_START | 0x80, 0))
        frame = b"\xA5\x5A" + body + bytes((crc8(body),))
        self.assertEqual(FrameParser().feed(frame), [Ack(CMD_START, 0)])

    def test_status_parser_with_noise(self) -> None:
        body = bytes((0x00, 0x03, 7, 0x07, 0x01))
        frame = b"\xA5\x5A\x90" + body + bytes((crc8(body),))
        parsed = FrameParser().feed(b"noise" + frame[:4])
        self.assertEqual(parsed, [])

        parser = FrameParser()
        parsed = parser.feed(b"noise" + frame[:4])
        parsed += parser.feed(frame[4:])
        self.assertEqual(len(parsed), 1)
        status = parsed[0]
        self.assertIsInstance(status, DeviceStatus)
        self.assertEqual(status.traj_state, 0)
        self.assertEqual(status.mode, 3)
        self.assertEqual(status.time_sec, 7)
        self.assertTrue(status.car_valid)
        self.assertTrue(status.goal_valid)
        self.assertTrue(status.path_valid)
        self.assertFalse(status.planning_busy)
        self.assertEqual(status.path_mode, 1)


if __name__ == "__main__":
    unittest.main()
