@echo off
cd /d "%~dp0"
python host_gui.py
if errorlevel 1 pause
